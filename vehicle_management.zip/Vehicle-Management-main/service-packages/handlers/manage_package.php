<?php
/**
 * Manage Package Handler
 * Functions to fetch packages and their included services.
 */

require_once __DIR__ . '/../../config/db.php';

/**
 * Fetch all packages with their included services.
 * 
 * @param bool $activeOnly If true, fetch only active packages (for customers). If false, fetch all (for admin).
 * @return array Array of packages, each containing an array of 'services'.
 */
function getAllPackagesWithServices($activeOnly = true) {
    try {
        $pdo = Database::getInstance()->getConnection();
        
        // Base query - using LEFT JOIN to get services even if a package has none (though that shouldn't happen)
        $sql = "
            SELECT 
                p.package_id as package_id, 
                p.package_name as package_name, 
                p.description as package_description, 
                p.total_price as package_price,
                s.service_id as service_id,
                s.service_name as service_name,
                s.description as service_description
            FROM service_packages p
            LEFT JOIN package_services ps ON p.package_id = ps.package_id
            LEFT JOIN services s ON ps.service_id = s.service_id
        ";
        
        if ($activeOnly) {
            $sql .= " WHERE p.is_active = 1";
        }
        
        $sql .= " ORDER BY p.package_name ASC, s.service_name ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group the flat results into a structured array
        $packages = [];
        
        foreach ($results as $row) {
            $pid = $row['package_id'];
            
            if (!isset($packages[$pid])) {
                $packages[$pid] = [
                    'id' => $pid,
                    'name' => $row['package_name'],
                    'description' => $row['package_description'],
                    'price' => $row['package_price'],
                    'services' => []
                ];
            }
            
            if (!empty($row['service_id'])) {
                $packages[$pid]['services'][] = [
                    'id' => $row['service_id'],
                    'name' => $row['service_name'],
                    'description' => $row['service_description']
                ];
            }
        }
        
        // Return values sequentially (re-indexing array)
        return array_values($packages);
        
    } catch (\PDOException $e) {
        error_log("Error fetching packages with services: " . $e->getMessage());
        return [];
    }
}

/**
 * Fetch a single package by ID with its included services.
 * 
 * @param int $packageId
 * @return array|null The structured package data or null if not found.
 */
function getPackageWithServicesById($packageId) {
    try {
        $pdo = Database::getInstance()->getConnection();
        
        $sql = "
            SELECT 
                p.package_id as package_id, 
                p.package_name as package_name, 
                p.description as package_description, 
                p.total_price as package_price,
                s.service_id as service_id,
                s.service_name as service_name,
                s.description as service_description
            FROM service_packages p
            LEFT JOIN package_services ps ON p.package_id = ps.package_id
            LEFT JOIN services s ON ps.service_id = s.service_id
            WHERE p.package_id = :package_id
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':package_id' => $packageId]);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($results)) {
            return null;
        }
        
        $package = [
            'id' => $results[0]['package_id'],
            'name' => $results[0]['package_name'],
            'description' => $results[0]['package_description'],
            'price' => $results[0]['package_price'],
            'services' => []
        ];
        
        foreach ($results as $row) {
            if (!empty($row['service_id'])) {
                $package['services'][] = [
                    'id' => $row['service_id'],
                    'name' => $row['service_name'],
                    'description' => $row['service_description']
                ];
            }
        }
        
        return $package;
        
    } catch (\PDOException $e) {
        error_log("Error fetching package ID {$packageId}: " . $e->getMessage());
        return null;
    }
}
