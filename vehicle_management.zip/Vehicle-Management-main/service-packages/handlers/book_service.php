<?php
/**
 * Book Service Handler
 * Handles a customer POST request to book a package or individual services.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

// 1. Authorization Check (Customer Only)
if (!isset($_SESSION['customer_id']) && !isset($_SESSION['user_id'])) {
    $_SESSION['error_msg'] = 'You must be logged in to book a service.';
    header('Location: ../../login.php');
    exit;
}
$customerId = $_SESSION['customer_id'] ?? $_SESSION['user_id'];

// 2. Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/select_service.php');
    exit;
}

// 3. Input Validation
$packageId = filter_input(INPUT_POST, 'package_id', FILTER_VALIDATE_INT);
$bookingDate = filter_input(INPUT_POST, 'booking_date', FILTER_SANITIZE_SPECIAL_CHARS); 
$bookingTime = filter_input(INPUT_POST, 'booking_time', FILTER_SANITIZE_SPECIAL_CHARS); 
$vehicleId = filter_input(INPUT_POST, 'vehicle_id', FILTER_SANITIZE_SPECIAL_CHARS);
$additionalNotes = filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_SPECIAL_CHARS);

// Individual services (if package is not selected)
$serviceIds = isset($_POST['service_ids']) && is_array($_POST['service_ids']) 
    ? array_map('intval', $_POST['service_ids']) 
    : [];

$errors = [];

// Date/Time validation
if (empty($bookingDate) || empty($bookingTime)) {
    $errors[] = 'Booking date and time are required.';
}

// Vehicle validation
if (empty($vehicleId)) {
    $errors[] = 'Please select a vehicle.';
}

// Ensure either a package OR individual services are selected
if (empty($packageId) && empty($serviceIds)) {
    $errors[] = 'You must select at least one service.';
}

if (!empty($errors)) {
    $_SESSION['error_msg'] = implode(' ', $errors);
    header('Location: ../views/select_service.php');
    exit;
}

// 4. Calculate Total & Prepare Items
try {
    $pdo = Database::getInstance()->getConnection();
    
    $totalAmount = 0;
    $itemsToInsert = [];

    if (!empty($packageId)) {
        $stmtPkg = $pdo->prepare("SELECT package_id, package_name, total_price FROM service_packages WHERE package_id = ?");
        $stmtPkg->execute([$packageId]);
        $pkg = $stmtPkg->fetch();
        if ($pkg) {
            $totalAmount += $pkg['total_price'];
            $itemsToInsert[] = [
                'type' => 'package',
                'id' => $pkg['package_id'],
                'name' => $pkg['package_name'],
                'price' => $pkg['total_price']
            ];
        } else {
            $errors[] = 'Selected package not found.';
        }
    } else if (!empty($serviceIds)) {
        $placeholders = implode(',', array_fill(0, count($serviceIds), '?'));
        $stmtSrv = $pdo->prepare("SELECT service_id, service_name, price FROM services WHERE service_id IN ($placeholders)");
        $stmtSrv->execute($serviceIds);
        $srvs = $stmtSrv->fetchAll();
        foreach ($srvs as $srv) {
            $totalAmount += $srv['price'];
            $itemsToInsert[] = [
                'type' => 'service',
                'id' => $srv['service_id'],
                'name' => $srv['service_name'],
                'price' => $srv['price']
            ];
        }
    }

    if (!empty($errors) || empty($itemsToInsert)) {
        $_SESSION['error_msg'] = implode(' ', $errors) ?: 'Invalid selection.';
        header('Location: ../views/select_service.php');
        exit;
    }

    // 🛒 ADD TO CART (Instead of immediate booking)
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    
    $notes = "Booking for: $bookingDate at $bookingTime";
    if (!empty($additionalNotes)) {
        $notes .= " | Notes: " . $additionalNotes;
    }
    
    foreach ($itemsToInsert as $item) {
        $key = strtoupper($item['type'][0]) . "_" . $item['id'];
        $_SESSION['cart'][$key] = [
            'id' => $item['id'],
            'product_id' => $item['id'],
            'name' => $item['name'],
            'price' => (float)$item['price'],
            'quantity' => 1,
            'image' => ($item['type'] === 'package' ? '📦' : '🛠️'),
            'type' => $item['type'],
            'vehicle_id' => $vehicleId,
            'notes' => $notes
        ];

        // 🔔 IMMEDIATE ACTIONS
        // 1. Create Service Request
        $reqStmt = $pdo->prepare("INSERT INTO service_requests (vehicle_id, service_type, complaint_text, priority, status) VALUES (?, ?, ?, 'Medium', 'Pending')");
        $reqStmt->execute([$vehicleId, $item['name'], $notes]);

        // 2. Notify Admin
        $admin_q = $pdo->query("SELECT id FROM admins LIMIT 1");
        if ($admin_data = $admin_q->fetch()) {
            $admin_id = $admin_data['id'];
            $msg = "New Service Request: " . $item['name'] . " for vehicle $vehicleId";
            $pdo->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'admin', ?)")->execute([$admin_id, $msg]);
        }
    }

    $_SESSION['success_msg'] = "Services added to your cart!";
    header("Location: ../../products/views/cart.php");
    exit;
    
} catch (\PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Booking Error: " . $e->getMessage());
    $_SESSION['error_msg'] = 'An error occurred while processing your booking.';
    header('Location: ../views/select_service.php');
    exit;
}
