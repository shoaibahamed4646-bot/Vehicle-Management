<?php
/**
 * Customer View: Package Detail
 * Detailed view of a single package with a booking form (date/time).
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../handlers/manage_package.php';

$packageId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$packageId) {
    // Graceful fallback if no ID is passed
    header("Location: package_list.php");
    exit;
}

$package = getPackageWithServicesById($packageId);

if (!$package) {
    die("<div style='color:white; background:#13141f; padding:50px; text-align:center; font-family:sans-serif;'><h2>Package not found.</h2><a href='package_list.php' style='color:#3b82f6;'>Go back</a></div>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($package['name']) ?> | Vehicle Management</title>
    <style>
        :root {
            --bg-main: #13141f;
            --bg-card: #1f2133;
            --bg-input: #151623;
            --text-main: #ffffff;
            --text-muted: #8b95a5;
            --accent: #3b82f6; 
            --accent-hover: #2563eb;
            --card-border: rgba(255, 255, 255, 0.05);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        body {
            margin: 0;
            padding: 0;
            background-color: var(--bg-main);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
        }

        /* 70/30 Asymmetric Layout */
        .layout-wrapper {
            max-width: 1300px;
            margin: 0 auto;
            padding: 60px 20px;
            display: grid;
            grid-template-columns: 1fr 380px;
            gap: 40px;
            align-items: start;
        }

        /* LEFT SIDE: Content */
        .content-section {
            padding-right: 20px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 30px;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--text-main);
            transform: translateX(-5px);
        }

        .back-link svg {
            width: 20px;
            height: 20px;
            margin-right: 8px;
        }

        .package-title {
            font-size: 3.5rem;
            font-weight: 800;
            margin: 0 0 20px 0;
            line-height: 1.1;
            letter-spacing: -0.03em;
        }

        .package-desc {
            font-size: 1.25rem;
            color: var(--text-muted);
            line-height: 1.6;
            margin: 0 0 50px 0;
            max-width: 800px;
        }

        .section-header {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0 0 20px 0;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--card-border);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }

        .service-item {
            background-color: var(--bg-card);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: flex-start;
            transition: var(--transition);
        }

        .service-item:hover {
            transform: translateY(-4px);
            border-color: rgba(59, 130, 246, 0.3);
        }

        .check-icon {
            color: var(--accent);
            width: 24px;
            height: 24px;
            margin-right: 15px;
            flex-shrink: 0;
            margin-top: 2px;
        }

        .service-details h4 {
            margin: 0 0 5px 0;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .service-details p {
            margin: 0;
            color: var(--text-muted);
            font-size: 0.9rem;
            line-height: 1.5;
        }

        /* RIGHT SIDE: Sticky Booking Console */
        .booking-console {
            background-color: var(--bg-card);
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 30px;
            position: sticky;
            top: 40px;
            box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.5);
        }

        /* Subtle top glow */
        .booking-console::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
        }

        .price-tag {
            font-size: 3rem;
            font-weight: 800;
            margin: 0 0 5px 0;
            display: flex;
            align-items: baseline;
        }

        .price-tag span {
            font-size: 1.2rem;
            font-weight: 400;
            color: var(--text-muted);
            margin-left: 10px;
        }

        .price-label {
            color: var(--text-muted);
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 30px;
            display: block;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            color: #e2e8f0;
        }

        .form-control {
            width: 100%;
            background-color: var(--bg-input);
            border: 1px solid var(--card-border);
            color: var(--text-main);
            padding: 15px;
            border-radius: 8px;
            font-size: 1rem;
            box-sizing: border-box;
            font-family: inherit;
            color-scheme: dark; /* Helps native date picker fit dark mode */
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .btn-submit {
            width: 100%;
            background-color: var(--accent);
            color: white;
            border: none;
            padding: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
        }

        .btn-submit:hover {
            background-color: var(--accent-hover);
            transform: scale(1.02);
            box-shadow: 0 10px 20px -5px rgba(59, 130, 246, 0.4);
        }

        .guarantee {
            margin-top: 20px;
            text-align: center;
            font-size: 0.85rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .guarantee svg {
            width: 16px; height: 16px; margin-right: 6px;
        }

        @media (max-width: 992px) {
            .layout-wrapper {
                grid-template-columns: 1fr;
            }
            .booking-console {
                position: relative;
                top: 0;
                margin-top: 20px;
            }
            .package-title { font-size: 2.5rem; }
        }
    </style>
</head>
<body>

    <div class="layout-wrapper">
        <!-- LEFT: Content -->
        <main class="content-section">
            <a href="package_list.php" class="back-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                Back to Packages
            </a>

            <h1 class="package-title"><?= htmlspecialchars($package['name']) ?></h1>
            <p class="package-desc"><?= nl2br(htmlspecialchars($package['description'] ?? 'Comprehensive care designed specifically for your vehicle\'s needs.')) ?></p>

            <h3 class="section-header">What's Included in this Package</h3>
            
            <?php if (empty($package['services'])): ?>
                <p style="color: var(--text-muted);">No specific services mapped to this package yet.</p>
            <?php else: ?>
                <div class="services-grid">
                    <?php foreach ($package['services'] as $srv): ?>
                        <div class="service-item">
                            <svg class="check-icon" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                            </svg>
                            <div class="service-details">
                                <h4><?= htmlspecialchars($srv['name']) ?></h4>
                                <?php if (!empty($srv['description'])): ?>
                                    <p><?= htmlspecialchars($srv['description']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>

        <!-- RIGHT: Sticky Booking Console -->
        <aside class="booking-console">
            <span class="price-label">Total Package Price</span>
            <div class="price-tag">
                $<?= number_format($package['price'], 2) ?> <span>USD</span>
            </div>

            <!-- Booking Form -->
            <form action="../handlers/book_service.php" method="POST" style="margin-top: 30px;">
                <input type="hidden" name="package_id" value="<?= htmlspecialchars($package['id']) ?>">
                
                <div class="form-group">
                    <label for="booking_date">Preferred Date</label>
                    <!-- min attribute limits past dates -->
                    <input type="date" id="booking_date" name="booking_date" class="form-control" 
                           min="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="booking_time">Preferred Time</label>
                    <input type="time" id="booking_time" name="booking_time" class="form-control" required>
                </div>

                <button type="submit" class="btn-submit">Confirm Booking</button>
            </form>
            
            <div class="guarantee">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                </svg>
                Secure Booking Guarantee
            </div>
        </aside>
    </div>

</body>
</html>
