<?php
/**
 * Customer View: Package List
 * Displays available service packages in a responsive, dark-themed grid.
 */

require_once __DIR__ . '/../../config/session.php';
// Use the handler we created earlier to fetch all packages
require_once __DIR__ . '/../handlers/manage_package.php';

// Fetch only active packages for the customer view
$packages = getAllPackagesWithServices(true);
$currentPage = 'services';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Packages | Vehicle Management System</title>
    <style>
        :root {
            /* Base Colors matching reference UI (shifted from purple to pure blue to follow strict design rules) */
            --bg-main: #13141f;
            --bg-card: #1f2133;
            --text-main: #ffffff;
            --text-muted: #8b95a5;
            --accent: #3b82f6; 
            --accent-hover: #2563eb;
            --card-border: rgba(255, 255, 255, 0.04);
            --card-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        body {
            margin: 0;
            padding: 0;
            background-color: var(--bg-main);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
        }

        header {
            text-align: center;
            padding: 60px 20px 40px;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            box-sizing: border-box;
        }

        .car-icon {
            color: var(--accent);
            width: 48px;
            height: 48px;
            margin-bottom: 20px;
        }

        h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0 0 15px 0;
            letter-spacing: -0.02em;
        }

        .subtitle {
            color: var(--text-muted);
            font-size: 1.125rem;
            margin: 0;
        }

        .packages-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 30px;
            padding: 0 20px 80px;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            box-sizing: border-box;
        }

        .package-card {
            background-color: var(--bg-card);
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 32px;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
        }

        /* Subtle top highlight to give a "glass/premium" edge without full glassmorphism */
        .package-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
            opacity: 0;
            transition: var(--transition);
        }

        .package-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.7);
            border-color: rgba(59, 130, 246, 0.3);
        }

        .package-card:hover::before {
            opacity: 1;
        }

        .pkg-name {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0 0 10px 0;
        }

        .pkg-desc {
            color: var(--text-muted);
            font-size: 0.95rem;
            line-height: 1.5;
            margin: 0 0 24px 0;
            flex-grow: 1;
        }

        .pkg-price {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 30px;
            display: flex;
            align-items:baseline;
        }

        .pkg-price span {
            font-size: 1rem;
            font-weight: 400;
            color: var(--text-muted);
            margin-left: 8px;
        }

        .services-list {
            list-style: none;
            padding: 0;
            margin: 0 0 32px 0;
            border-top: 1px solid rgba(255,255,255,0.05);
            padding-top: 24px;
        }

        .services-list li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 16px;
            color: #d1d5db;
            font-size: 0.95rem;
        }

        .check-icon {
            color: var(--accent);
            width: 20px;
            height: 20px;
            margin-right: 12px;
            flex-shrink: 0;
        }

        .btn-book {
            display: block;
            width: 100%;
            text-align: center;
            background-color: rgba(59, 130, 246, 0.1);
            color: var(--accent);
            border: 1px solid var(--accent);
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            margin-top: auto;
        }

        .btn-book:hover {
            background-color: var(--accent);
            color: #ffffff;
            transform: scale(1.02);
        }

        /* Empty State */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px;
            background-color: var(--bg-card);
            border-radius: 16px;
            color: var(--text-muted);
        }

        @media (max-width: 768px) {
            h1 { font-size: 2rem; }
            .packages-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../includes/header.php'; ?>

    <header>
        <!-- Custom Car Icon matching reference UI style -->
        <svg class="car-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16C5.67 16 5 15.33 5 14.5S5.67 13 6.5 13 8 13.67 8 14.5 7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
        </svg>
        <h1>Vehicle Service Packages</h1>
        <p class="subtitle">Choose the right maintenance plan for your vehicle</p>
    </header>

    <main class="packages-grid">
        <?php if (empty($packages)): ?>
            <div class="empty-state">
                <h2>No packages available right now</h2>
                <p>Please check back later or contact support for individual services.</p>
            </div>
        <?php else: ?>
            <?php foreach ($packages as $pkg): ?>
                <div class="package-card">
                    <h3 class="pkg-name"><?= htmlspecialchars($pkg['name']) ?></h3>
                    <p class="pkg-desc"><?= htmlspecialchars($pkg['description'] ?? 'Comprehensive vehicle care.') ?></p>
                    
                    <div class="pkg-price">
                        $<?= number_format($pkg['price'], 2) ?> <span>/ service</span>
                    </div>

                    <ul class="services-list">
                        <?php if (empty($pkg['services'])): ?>
                            <li><em>No specific services listed.</em></li>
                        <?php else: ?>
                            <?php foreach ($pkg['services'] as $srv): ?>
                                <li>
                                    <svg class="check-icon" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                    </svg>
                                    <?= htmlspecialchars($srv['name']) ?>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>

                    <!-- Links to a generic booking screen where the user can pick a date -->
                    <a href="select_service.php?package_id=<?= htmlspecialchars($pkg['id']) ?>" class="btn-book">Book Now</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
