<?php
/**
 * Customer View: Select Individual Services (A la Carte)
 * Displays a list of services with interactive toggles and live price calculation.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

try {
    $pdo = Database::getInstance()->getConnection();
    // Fetch all active/available services
    $stmt = $pdo->prepare("SELECT service_id AS id, service_name AS name, description, price FROM services WHERE is_active = 1 ORDER BY service_name ASC");
    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch customer vehicles
    $customerId = $_SESSION['customer_id'] ?? $_SESSION['user_id'] ?? null;
    $vehicles = [];
    if ($customerId) {
        $stmtVehicles = $pdo->prepare("SELECT registration_no, brand, model FROM vehicles WHERE customer_id = ?");
        $stmtVehicles->execute([$customerId]);
        $vehicles = $stmtVehicles->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (\PDOException $e) {
    die("<div style='color:white; background:#13141f; padding:50px; text-align:center;'><h2>Error loading services. Please try again later.</h2></div>");
}
$currentPage = 'services';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Services | Vehicle Management</title>
    <style>
        :root {
            --bg-main: #13141f;
            --bg-card: #1f2133;
            --bg-input: #151623;
            --text-main: #ffffff;
            --text-muted: #8b95a5;
            --accent: #3b82f6; 
            --accent-hover: #2563eb;
            --card-border: rgba(255, 255, 255, 0.08);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        body {
            margin: 0;
            padding: 0;
            background-color: var(--bg-main);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
        }

        /* 70/30 Asymmetric Split (Continuous Stream Left) */
        .layout-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
            display: grid;
            grid-template-columns: 1fr 380px;
            gap: 40px;
            align-items: start;
        }

        .header-title {
            font-size: 3rem;
            font-weight: 800;
            margin: 0 0 10px 0;
            letter-spacing: -0.03em;
        }

        .header-subtitle {
            color: var(--text-muted);
            font-size: 1.1rem;
            margin: 0 0 40px 0;
        }

        /* Service Toggles */
        .services-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .service-toggle {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: var(--bg-card);
            border: 2px solid var(--card-border);
            border-radius: 12px;
            padding: 25px 30px;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .service-toggle:hover {
            border-color: rgba(59, 130, 246, 0.4);
            transform: translateX(5px);
        }

        /* Hide native checkbox */
        .service-toggle input[type="checkbox"] {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            height: 0;
            width: 0;
        }

        /* Active State logic */
        .service-toggle.active {
            border-color: var(--accent);
            background-color: rgba(59, 130, 246, 0.05);
            box-shadow: 0 10px 30px -10px rgba(59, 130, 246, 0.2);
        }

        /* Custom radio/check visual indicator */
        .indicator {
            width: 24px;
            height: 24px;
            border: 2px solid var(--text-muted);
            border-radius: 6px;
            margin-right: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
            flex-shrink: 0;
        }

        .service-toggle.active .indicator {
            border-color: var(--accent);
            background-color: var(--accent);
        }

        .indicator svg {
            width: 14px;
            height: 14px;
            color: white;
            opacity: 0;
            transition: var(--transition);
        }

        .service-toggle.active .indicator svg {
            opacity: 1;
            transform: scale(1.1);
        }

        .service-info {
            flex-grow: 1;
        }

        .service-name {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0 0 5px 0;
        }

        .service-desc {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin: 0;
            line-height: 1.4;
        }

        .service-price {
            font-size: 1.5rem;
            font-weight: 700;
            margin-left: 20px;
            white-space: nowrap;
        }

        /* RIGHT: Sticky Booking Console */
        .booking-console {
            background-color: var(--bg-card);
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 30px;
            position: sticky;
            top: 40px;
            box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.5);
        }

        .total-label {
            color: var(--text-muted);
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            display: block;
            margin-bottom: 5px;
        }

        .total-price {
            font-size: 3.5rem;
            font-weight: 800;
            margin: 0 0 30px 0;
            color: var(--text-main);
            transition: var(--transition);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            color: #e2e8f0;
        }

        .form-control {
            width: 100%;
            background-color: var(--bg-input);
            border: 1px solid var(--card-border);
            color: var(--text-main);
            padding: 15px;
            border-radius: 8px;
            font-size: 1rem;
            box-sizing: border-box;
            font-family: inherit;
            color-scheme: dark; 
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .btn-submit {
            width: 100%;
            background-color: var(--accent);
            color: white;
            border: none;
            padding: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
            opacity: 0.5;
            pointer-events: none;
        }

        .btn-submit.ready {
            opacity: 1;
            pointer-events: auto;
        }

        .btn-submit.ready:hover {
            background-color: var(--accent-hover);
            transform: scale(1.02);
            box-shadow: 0 10px 20px -5px rgba(59, 130, 246, 0.4);
        }

        @media (max-width: 992px) {
            .layout-wrapper {
                grid-template-columns: 1fr;
            }
            .booking-console {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                top: auto;
                border-radius: 20px 20px 0 0;
                z-index: 100;
                padding: 20px;
                border-bottom: none;
                border-left: none;
                border-right: none;
            }
            .services-list {
                padding-bottom: 300px; /* space for fixed console */
            }
            .total-price {
                font-size: 2.5rem;
                margin-bottom: 15px;
            }
            .header-title { font-size: 2.5rem; }
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../includes/header.php'; ?>

    <form action="../handlers/book_service.php" method="POST" id="bookingForm" class="layout-wrapper">
        
        <!-- LEFT: Continuous Stream List -->
        <main class="content-section">
            <?php if (isset($_SESSION['success_msg'])): ?>
                <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid #22c55e; color: #22c55e; padding: 15px; border-radius: 12px; margin-bottom: 24px;">
                    <i class="fas fa-check-circle" style="margin-right: 10px;"></i> <?= htmlspecialchars($_SESSION['success_msg']) ?>
                    <?php unset($_SESSION['success_msg']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_msg'])): ?>
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444; color: #ef4444; padding: 15px; border-radius: 12px; margin-bottom: 24px;">
                    <i class="fas fa-exclamation-circle" style="margin-right: 10px;"></i> <?= htmlspecialchars($_SESSION['error_msg']) ?>
                    <?php unset($_SESSION['error_msg']); ?>
                </div>
            <?php endif; ?>

            <h1 class="header-title">Customize Your Service</h1>
            <p class="header-subtitle">Select individual services below to build your custom package.</p>

            <div class="services-list">
                <?php if (empty($services)): ?>
                    <p style="color: var(--text-muted);">No services available at the moment.</p>
                <?php else: ?>
                    <?php foreach ($services as $srv): ?>
                        <label class="service-toggle" id="toggle-<?= $srv['id'] ?>">
                            <div class="indicator">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>
                                </svg>
                            </div>
                            
                            <input type="checkbox" name="service_ids[]" value="<?= $srv['id'] ?>" 
                                   data-price="<?= $srv['price'] ?>" onchange="handleToggle(this)">
                            
                            <div class="service-info">
                                <h3 class="service-name"><?= htmlspecialchars($srv['name']) ?></h3>
                                <?php if (!empty($srv['description'])): ?>
                                    <p class="service-desc"><?= htmlspecialchars($srv['description']) ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="service-price">
                                $<?= number_format($srv['price'], 2) ?>
                            </div>
                        </label>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>

        <!-- RIGHT: Sticky Booking Console -->
        <aside class="booking-console">
            <span class="total-label">Estimated Total</span>
            <div class="total-price" id="priceDisplay">$0.00</div>

            <div class="form-group">
                <label for="vehicle_id">Select Vehicle</label>
                <select id="vehicle_id" name="vehicle_id" class="form-control" required onchange="validateForm()">
                    <option value="">-- Choose your vehicle --</option>
                    <?php if (!empty($vehicles)): ?>
                        <?php foreach ($vehicles as $v): ?>
                            <option value="<?= htmlspecialchars($v['registration_no']) ?>">
                                <?= htmlspecialchars($v['brand'] . ' ' . $v['model'] . ' (' . $v['registration_no'] . ')') ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <?php if (empty($vehicles)): ?>
                    <small style="color: #ef4444; margin-top: 5px; display: block;">No vehicles found. <a href="../../register_vehicle.php" style="color: var(--accent);">Register one first</a>.</small>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="booking_date">Preferred Date</label>
                <input type="date" id="booking_date" name="booking_date" class="form-control" 
                       min="<?= date('Y-m-d') ?>" required onchange="validateForm()">
            </div>
            
            <div class="form-group">
                <label for="booking_time">Preferred Time</label>
                <input type="time" id="booking_time" name="booking_time" class="form-control" required onchange="validateForm()">
            </div>

            <div class="form-group">
                <label for="notes">Additional Notes (Optional)</label>
                <textarea id="notes" name="notes" class="form-control" rows="2" placeholder="Describe any specific issues..."></textarea>
            </div>

            <button type="submit" id="submitBtn" class="btn-submit">Select Services First</button>
        </aside>

    </form>

    <script>
        let currentTotal = 0;
        let selectedCount = 0;

        function handleToggle(checkbox) {
            const toggleWrapper = document.getElementById('toggle-' + checkbox.value);
            const price = parseFloat(checkbox.getAttribute('data-price'));

            if (checkbox.checked) {
                toggleWrapper.classList.add('active');
                currentTotal += price;
                selectedCount++;
            } else {
                toggleWrapper.classList.remove('active');
                currentTotal -= price;
                selectedCount--;
            }

            // Prevent negative zero issues
            if (currentTotal < 0) currentTotal = 0;

            // Animate number change simply
            const display = document.getElementById('priceDisplay');
            display.style.transform = 'scale(1.05)';
            display.style.color = 'var(--accent)';
            
            setTimeout(() => {
                display.innerText = '$' + currentTotal.toFixed(2);
                display.style.transform = 'scale(1)';
                display.style.color = 'var(--text-main)';
            }, 150);

            validateForm();
        }

        function validateForm() {
            const dateInput = document.getElementById('booking_date').value;
            const timeInput = document.getElementById('booking_time').value;
            const vehicleInput = document.getElementById('vehicle_id').value;
            const btn = document.getElementById('submitBtn');

            if (selectedCount > 0) {
                btn.classList.add('ready');
                if (dateInput && timeInput && vehicleInput) {
                    btn.innerText = 'Add to Cart';
                } else {
                    btn.innerText = 'Complete Form Details';
                }
            } else {
                btn.classList.remove('ready');
                btn.innerText = 'Select Services First';
            }
        }
    </script>
    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
