<?php
/**
 * Admin Form & Handler: Delete Service Package
 * Displays a confirmation prompt and handles the deletion (soft or hard)
 * of a service package.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
// require_once __DIR__ . '/../../includes/auth.php'; 

// 1. Authorization Check (Admin Only)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access. Admin privileges required.");
}

$pdo = Database::getInstance()->getConnection();
$message = '';
$error = '';

$packageId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$packageId) {
    die("Invalid Package ID.");
}

// Configuration: Prefer soft delete for historical consistency
$useSoftDelete = true; 

// 2. Handle Form Submission (POST Deletion)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $confirm = filter_input(INPUT_POST, 'confirm', FILTER_SANITIZE_STRING);
    
    if ($confirm === 'yes') {
        try {
            $pdo->beginTransaction();

            if ($useSoftDelete) {
                // Check if 'is_deleted' or 'is_active' column exists.
                // Assuming 'is_active' where 0 = deleted/inactive.
                // If schema uses 'deleted_at', use: UPDATE packages SET deleted_at = NOW() WHERE id = :id
                // We'll assume a standard 'is_active' boolean flag for soft deletes.
                $stmtDelete = $pdo->prepare("UPDATE service_packages SET is_active = 0 WHERE id = :id");
                $stmtDelete->execute([':id' => $packageId]);
            } else {
                // Hard delete: Remove from junction table first, then from packages
                $stmtSync = $pdo->prepare("DELETE FROM package_services WHERE package_id = :package_id");
                $stmtSync->execute([':package_id' => $packageId]);

                $stmtDelete = $pdo->prepare("DELETE FROM service_packages WHERE id = :id");
                $stmtDelete->execute([':id' => $packageId]);
            }

            $pdo->commit();
            $message = "Package successfully deleted.";
            
        } catch (\PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            // Depending on constraints (e.g. existing bookings attached), hard deletes might fail.
            error_log("Delete Package Error: " . $e->getMessage());
            $error = "An error occurred while deleting the package. It may be in use by existing bookings. Consider using soft delete.";
        }
    } else {
        // User canceled
        header("Location: package_list.php"); // Adjust redirection as needed
        exit;
    }
} else {
    // 3. Fetch Data for Confirmation View (GET Request)
    try {
        $stmtPackage = $pdo->prepare("SELECT name FROM service_packages WHERE id = :id");
        $stmtPackage->execute([':id' => $packageId]);
        $package = $stmtPackage->fetch(PDO::FETCH_ASSOC);

        if (!$package) {
            die("Package not found.");
        }
    } catch (\PDOException $e) {
        die("Database error: " . htmlspecialchars($e->getMessage()));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Package - Admin Panel</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f4f7f6; color: #333; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; }
        h2 { margin-top: 0; color: #c0392b; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; text-align: left; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .btn { border: none; padding: 10px 20px; font-size: 16px; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
        .btn-danger { background-color: #e74c3c; color: white; }
        .btn-danger:hover { background-color: #c0392b; }
        .btn-secondary { background-color: #95a5a6; color: white; }
        .btn-secondary:hover { background-color: #7f8c8d; }
        .package-name { font-weight: bold; font-size: 1.2em; margin: 15px 0; color: #2c3e50; }
    </style>
</head>
<body>

<div class="container">
    <?php if ($message): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($message) ?>
            <div style="margin-top: 15px;">
                <a href="package_list.php" class="btn btn-secondary">Return to Packages</a>
            </div>
        </div>
    <?php elseif ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <a href="package_list.php" class="btn btn-secondary">Back</a>
    <?php else: ?>
        <h2>Confirm Deletion</h2>
        <p>Are you sure you want to delete the following package?</p>
        
        <div class="package-name">
            <?= htmlspecialchars($package['name']) ?>
        </div>
        
        <p style="color: #e74c3c; font-size: 0.9em;">
            <?php if ($useSoftDelete): ?>
                Note: This will mark the package as inactive. Existing bookings will not be affected.
            <?php else: ?>
                Warning: This action is permanent and cannot be undone!
            <?php endif; ?>
        </p>

        <form method="POST" action="delete_package.php?id=<?= htmlspecialchars($packageId) ?>">
            <input type="hidden" name="id" value="<?= htmlspecialchars($packageId) ?>">
            <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes, Delete It</button>
            <a href="package_list.php" class="btn btn-secondary">Cancel</a>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
