<?php
/**
 * Admin Form Handler: Add Service Package
 * Handles the creation of a new service package and its associated services.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php'; // Assuming auth helpers are here

// 1. Authorization Check (Admin Only)
// Assuming a function like isAdmin() exists in auth.php or session
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit;
}

// 2. Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// 3. Input Validation & Sanitization
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
$price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);

// Service IDs should be an array of integers
$serviceIds = isset($_POST['service_ids']) && is_array($_POST['service_ids']) 
    ? array_map('intval', $_POST['service_ids']) 
    : [];

$errors = [];
if (empty($name)) {
    $errors[] = 'Package name is required.';
}
if ($price === false || $price < 0) {
    $errors[] = 'A valid positive price is required.';
}
if (empty($serviceIds)) {
    $errors[] = 'At least one service must be included in the package.';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// 4. Database Insertion with Transactions
try {
    $pdo = Database::getInstance()->getConnection();
    
    // Start Transaction: Ensures both package and package_services are inserted safely
    $pdo->beginTransaction();

    // Insert the main package record
    $stmtPackage = $pdo->prepare("
        INSERT INTO service_packages (name, description, price, created_at) 
        VALUES (:name, :description, :price, NOW())
    ");
    
    $stmtPackage->execute([
        ':name' => $name,
        ':description' => $description,
        ':price' => $price
    ]);

    // Get the newly created package ID
    $packageId = $pdo->lastInsertId();

    // Insert the included service IDs into the junction table
    $stmtService = $pdo->prepare("
        INSERT INTO package_services (package_id, service_id) 
        VALUES (:package_id, :service_id)
    ");

    foreach ($serviceIds as $serviceId) {
        // Validate serviceId exists (optional but recommended depending on constraints)
        // Here we assume foreign key constraints will catch invalid service_ids
        $stmtService->execute([
            ':package_id' => $packageId,
            ':service_id' => $serviceId
        ]);
    }

    // Commit the transaction
    $pdo->commit();

    // Return success response
    http_response_code(201);
    echo json_encode([
        'success' => true, 
        'message' => 'Service package created successfully.',
        'data' => [
            'package_id' => $packageId
        ]
    ]);

} catch (\PDOException $e) {
    // Rollback if anything fails
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Log error securely
    error_log("Add Package Error: " . $e->getMessage());
    
    // Return generic server error
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An internal error occurred while saving the package.']);
}
