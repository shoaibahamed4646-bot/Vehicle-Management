<?php
/**
 * Admin Form & Handler: Edit Service Package
 * Fetches an existing package by ID, displays a pre-filled form, 
 * and handles the update logic (POST) to the database.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
// require_once __DIR__ . '/../../includes/auth.php'; 

// 1. Authorization Check (Admin Only)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access. Admin privileges required.");
}

$pdo = Database::getInstance()->getConnection();
$message = '';
$error = '';

// Determine package ID from GET (viewing) or POST (updating)
$packageId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$packageId) {
    die("Invalid Package ID.");
}

// 2. Handle Form Submission (POST Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    
    $serviceIds = isset($_POST['service_ids']) && is_array($_POST['service_ids']) 
        ? array_map('intval', $_POST['service_ids']) 
        : [];

    if (empty($name) || $price === false || $price < 0 || empty($serviceIds)) {
        $error = "Please fill in all required fields correctly and select at least one service.";
    } else {
        try {
            $pdo->beginTransaction();

            // Update main package details
            $stmtUpdate = $pdo->prepare("
                UPDATE service_packages 
                SET name = :name, description = :description, price = :price, updated_at = NOW() 
                WHERE id = :id
            ");
            $stmtUpdate->execute([
                ':name' => $name,
                ':description' => $description,
                ':price' => $price,
                ':id' => $packageId
            ]);

            // Sync junction table: Remove old services, insert new ones
            $stmtDeleteOld = $pdo->prepare("DELETE FROM package_services WHERE package_id = :package_id");
            $stmtDeleteOld->execute([':package_id' => $packageId]);

            $stmtInsertNew = $pdo->prepare("INSERT INTO package_services (package_id, service_id) VALUES (:package_id, :service_id)");
            foreach ($serviceIds as $serviceId) {
                $stmtInsertNew->execute([
                    ':package_id' => $packageId,
                    ':service_id' => $serviceId
                ]);
            }

            $pdo->commit();
            $message = "Package updated successfully!";
            
        } catch (\PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Edit Package Error: " . $e->getMessage());
            $error = "An error occurred while updating the package. Please try again.";
        }
    }
}

// 3. Fetch Existing Data for the Form
try {
    // Fetch package details
    $stmtPackage = $pdo->prepare("SELECT * FROM service_packages WHERE id = :id");
    $stmtPackage->execute([':id' => $packageId]);
    $package = $stmtPackage->fetch(PDO::FETCH_ASSOC);

    if (!$package) {
        die("Package not found.");
    }

    // Fetch associated service IDs
    $stmtPkgServices = $pdo->prepare("SELECT service_id FROM package_services WHERE package_id = :package_id");
    $stmtPkgServices->execute([':package_id' => $packageId]);
    $currentServiceIds = $stmtPkgServices->fetchAll(PDO::FETCH_COLUMN);

    // Fetch all available services for the multi-select dropdown
    $stmtAllServices = $pdo->prepare("SELECT id, name, price FROM services ORDER BY name ASC");
    $stmtAllServices->execute();
    $allServices = $stmtAllServices->fetchAll(PDO::FETCH_ASSOC);

} catch (\PDOException $e) {
    die("Database error while loading package data: " . htmlspecialchars($e->getMessage()));
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Package - Admin Panel</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f4f7f6; color: #333; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; color: #2c3e50; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; color: #555; }
        input[type="text"], input[type="number"], textarea, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        textarea { resize: vertical; height: 100px; }
        select[multiple] { height: 150px; }
        .btn { background-color: #3498db; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 4px; cursor: pointer; }
        .btn:hover { background-color: #2980b9; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .help-text { font-size: 12px; color: #777; margin-top: 4px; }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Service Package</h2>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="edit_package.php?id=<?= htmlspecialchars($packageId) ?>">
        <input type="hidden" name="id" value="<?= htmlspecialchars($package['id']) ?>">

        <div class="form-group">
            <label for="name">Package Name <span style="color:red;">*</span></label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($package['name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description"><?= htmlspecialchars($package['description'] ?? '') ?></textarea>
        </div>

        <div class="form-group">
            <label for="price">Package Price ($) <span style="color:red;">*</span></label>
            <input type="number" step="0.01" min="0" id="price" name="price" value="<?= htmlspecialchars($package['price']) ?>" required>
        </div>

        <div class="form-group">
            <label for="service_ids">Included Services <span style="color:red;">*</span></label>
            <select id="service_ids" name="service_ids[]" multiple required>
                <?php foreach ($allServices as $service): ?>
                    <?php $selected = in_array($service['id'], $currentServiceIds) ? 'selected' : ''; ?>
                    <option value="<?= htmlspecialchars($service['id']) ?>" <?= $selected ?>>
                        <?= htmlspecialchars($service['name']) ?> ($<?= htmlspecialchars($service['price']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <div class="help-text">Hold Ctrl (Windows) or Cmd (Mac) to select multiple services.</div>
        </div>

        <button type="submit" class="btn">Update Package</button>
    </form>
</div>

</body>
</html>
