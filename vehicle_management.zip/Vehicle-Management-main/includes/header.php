<?php

/**
 * Global Header — Responsive Navigation Bar
 *
 * Usage (from any view file):
 *   $currentPage = 'products';          // 'home'|'services'|'products'|'account'
 *   require_once __DIR__ . '/../includes/header.php';
 *
 * Depends on: config/session.php (auto-loaded if missing).
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    require_once __DIR__ . '/../config/session.php';
}
require_once __DIR__ . '/../config/paths.php';
if (!function_exists('isLoggedIn')) {
    require_once __DIR__ . '/auth.php';
}

// Cart badge count
$_navCartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $_ci) {
        $_navCartCount += (int) $_ci['quantity'];
    }
}

$_isLoggedIn = isLoggedIn();
$_isAdmin    = $_isLoggedIn && hasRole(ROLE_ADMIN);
$_isEmployee = $_isLoggedIn && (($_SESSION['role'] ?? '') === 'employee');
$currentPage = $currentPage ?? '';
?>

<nav class="site-nav" id="siteNav">
    <div class="nav-container">

        <!-- Logo -->
        <a href="<?= BASE_URL ?>/index.php" class="nav-logo">
            <svg class="nav-logo-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M13 6h5l3 5v4h-2m-6 0H9m4 0h-1M5 15H3V9l2-3h5l2 3" />
            </svg>
            <span>Vehicle<strong>MS</strong></span>
        </a>

        <!-- Desktop Links -->
        <ul class="nav-links" id="navLinks">
            <li><a href="<?= BASE_URL ?>/index.php" class="<?= $currentPage === 'home' ? 'is-active' : '' ?>">Home</a></li>
            <li><a href="<?= BASE_URL ?>/service-packages/views/package_list.php" class="<?= $currentPage === 'services' ? 'is-active' : '' ?>">Services</a></li>
            <li><a href="<?= BASE_URL ?>/products/views/product_list.php" class="<?= $currentPage === 'products' ? 'is-active' : '' ?>">Products</a></li>

            <?php if ($_isAdmin): ?>
                <li class="nav-dropdown" id="adminDrop">
                    <a href="#" onclick="toggleDrop(event)" class="<?= $currentPage === 'admin' ? 'is-active' : '' ?>">
                        Admin
                        <svg class="chevron" viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
                            <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd" />
                        </svg>
                    </a>
                    <ul class="drop-menu">
                        <li><a href="<?= BASE_URL ?>/products/admin/add_product.php">Add Product</a></li>
                        <li><a href="<?= BASE_URL ?>/products/inventory/stock_management.php">Stock Management</a></li>
                        <li><a href="<?= BASE_URL ?>/products/inventory/low_stock_alert.php">Low Stock Alerts</a></li>
                        <li><a href="<?= BASE_URL ?>/service-packages/admin/add_package.php">Add Package</a></li>
                    </ul>
                </li>
            <?php endif; ?>

        </ul>

        <!-- Right Actions -->
        <div class="nav-actions">

            <!-- Cart -->
            <a href="<?= BASE_URL ?>/products/views/cart.php" class="nav-cart" aria-label="Cart">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293
                          2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0
                          100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
                </svg>
                <?php if ($_navCartCount > 0): ?>
                    <span class="cart-count"><?= $_navCartCount ?></span>
                <?php endif; ?>
            </a>

         
            <!-- Account / Sign In -->
            <?php if ($_isLoggedIn): ?>

                <?php
                if ($_isAdmin) {
                    $dashboardLink = BASE_URL . '/admin_dashboard.php';
                } elseif ($_isEmployee) {
                    $dashboardLink = BASE_URL . '/employee_dashboard.php';
                } else {
                    $dashboardLink = BASE_URL . '/customer_dashboard.php';
                }
                ?>

                <a href="<?= $dashboardLink ?>" class="nav-account <?= $currentPage === 'account' ? 'is-active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0
                  4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0
                  016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </a>

            <?php else: ?>

                <a href="<?= BASE_URL ?>/login.php" class="nav-signin">Sign In</a>

            <?php endif; ?>

            <!-- Hamburger -->
            <button class="hamburger" id="hamburger" aria-label="Menu" onclick="toggleNav()">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</nav>
<div class="nav-overlay" id="navOverlay" onclick="toggleNav()"></div>

<!-- ============ STYLES ============ -->
<style>
    /* ---- Design Tokens ---- */
    .site-nav {
        --nav-bg: #0d1020;
        --nav-border: rgba(59, 130, 246, .07);
        --nav-text: #7a84a0;
        --nav-text-hover: #e8ecf4;
        --nav-active: #60a5fa;
        --nav-accent: #3b82f6;
        --nav-glow: rgba(59, 130, 246, .12);
        --nav-h: 60px;
        --nav-radius: 8px;
        --nav-font: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        --transition: all .25s cubic-bezier(.25, .8, .25, 1);
    }

    /* ---- Base ---- */
    .site-nav {
        position: sticky;
        top: 0;
        z-index: 1000;
        background: var(--nav-bg);
        border-bottom: 1px solid var(--nav-border);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        font-family: var(--nav-font);
    }

    .nav-container {
        max-width: 1400px;
        margin: 0 auto;
        height: var(--nav-h);
        padding: 0 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    /* ---- Logo ---- */
    .nav-logo {
        display: flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        color: var(--nav-active);
        font-size: 1.2rem;
        letter-spacing: -.02em;
        transition: var(--transition);
    }

    .nav-logo:hover {
        color: #93c5fd;
    }

    .nav-logo strong {
        font-weight: 800;
    }

    .nav-logo-icon {
        width: 22px;
        height: 22px;
        flex-shrink: 0;
    }

    /* ---- Links ---- */
    .nav-links {
        list-style: none;
        display: flex;
        align-items: center;
        gap: 4px;
        margin: 0;
        padding: 0;
    }

    .nav-links>li>a {
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 7px 14px;
        border-radius: var(--nav-radius);
        color: var(--nav-text);
        text-decoration: none;
        font-size: .88rem;
        font-weight: 600;
        transition: var(--transition);
    }

    .nav-links>li>a:hover {
        color: var(--nav-text-hover);
        background: var(--nav-glow);
    }

    .nav-links>li>a.is-active {
        color: var(--nav-active);
        background: rgba(59, 130, 246, .1);
    }

    /* ---- Dropdown ---- */
    .nav-dropdown {
        position: relative;
    }

    .chevron {
        transition: transform .2s;
    }

    .nav-dropdown.open .chevron {
        transform: rotate(180deg);
    }

    .drop-menu {
        display: none;
        position: absolute;
        top: calc(100% + 8px);
        left: 0;
        list-style: none;
        margin: 0;
        padding: 6px 0;
        min-width: 200px;
        background: #141627;
        border: 1px solid rgba(59, 130, 246, .1);
        border-radius: 10px;
        box-shadow: 0 16px 32px -8px rgba(0, 0, 0, .6);
        z-index: 100;
    }

    .nav-dropdown.open .drop-menu {
        display: block;
    }

    .drop-menu li a {
        display: block;
        padding: 9px 16px;
        color: var(--nav-text);
        text-decoration: none;
        font-size: .86rem;
        font-weight: 500;
        transition: var(--transition);
    }

    .drop-menu li a:hover {
        color: var(--nav-text-hover);
        background: var(--nav-glow);
    }

    /* ---- Actions ---- */
    .nav-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    /* Cart */
    .nav-cart {
        position: relative;
        display: flex;
        align-items: center;
        color: var(--nav-text);
        transition: var(--transition);
    }

    .nav-cart:hover {
        color: var(--nav-text-hover);
    }

    .nav-cart svg {
        width: 21px;
        height: 21px;
    }

    .cart-count {
        position: absolute;
        top: -7px;
        right: -10px;
        background: var(--nav-accent);
        color: #fff;
        font-size: .6rem;
        font-weight: 700;
        min-width: 17px;
        height: 17px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
        box-shadow: 0 0 8px rgba(59, 130, 246, .45);
    }

    /* Account */
    .nav-account {
        display: flex;
        align-items: center;
        color: var(--nav-text);
        transition: var(--transition);
    }

    .nav-account:hover,
    .nav-account.is-active {
        color: var(--nav-active);
    }

    .nav-account svg {
        width: 21px;
        height: 21px;
    }

    .nav-signin {
        padding: 7px 16px;
        border-radius: var(--nav-radius);
        background: var(--nav-accent);
        color: #fff;
        text-decoration: none;
        font-size: .85rem;
        font-weight: 700;
        transition: var(--transition);
    }

    .nav-signin:hover {
        background: #2563eb;
        transform: scale(1.04);
    }

    /* ---- Hamburger ---- */
    .hamburger {
        display: none;
        flex-direction: column;
        justify-content: center;
        gap: 5px;
        background: none;
        border: none;
        cursor: pointer;
        padding: 4px;
        width: 34px;
        height: 34px;
    }

    .hamburger span {
        display: block;
        height: 2px;
        width: 20px;
        background: var(--nav-text);
        border-radius: 2px;
        transition: var(--transition);
    }

    .hamburger.open span:nth-child(1) {
        transform: translateY(7px) rotate(45deg);
        background: var(--nav-active);
    }

    .hamburger.open span:nth-child(2) {
        opacity: 0;
    }

    .hamburger.open span:nth-child(3) {
        transform: translateY(-7px) rotate(-45deg);
        background: var(--nav-active);
    }

    /* Overlay */
    .nav-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, .5);
        z-index: 999;
    }

    .nav-overlay.show {
        display: block;
    }

    /* ---- Mobile ---- */
    @media (max-width: 768px) {
        .hamburger {
            display: flex;
        }

        .nav-links {
            position: fixed;
            top: 0;
            right: -280px;
            width: 270px;
            height: 100vh;
            background: var(--nav-bg);
            border-left: 1px solid var(--nav-border);
            flex-direction: column;
            align-items: stretch;
            padding: 76px 16px 30px;
            gap: 2px;
            z-index: 1001;
            transition: right .3s ease;
            overflow-y: auto;
        }

        .nav-links.open {
            right: 0;
        }

        .nav-links>li>a {
            padding: 12px 14px;
            font-size: .95rem;
            border-radius: 10px;
        }

        .drop-menu {
            position: static;
            box-shadow: none;
            border: none;
            background: rgba(59, 130, 246, .04);
            border-radius: 8px;
            margin-top: 4px;
        }
    }
</style>

<!-- ============ SCRIPT ============ -->
<script>
    function toggleNav() {
        document.getElementById('navLinks').classList.toggle('open');
        document.getElementById('hamburger').classList.toggle('open');
        document.getElementById('navOverlay').classList.toggle('show');
    }

    function toggleDrop(e) {
        e.preventDefault();
        e.target.closest('.nav-dropdown').classList.toggle('open');
    }

    document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-dropdown')) {
            document.querySelectorAll('.nav-dropdown').forEach(d => d.classList.remove('open'));
        }
    });
</script>