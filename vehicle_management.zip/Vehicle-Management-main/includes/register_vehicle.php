<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli('localhost', 'root', '', 'vehicle management');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$brand = $_POST['brand'];
$model = $_POST['model'];
$registration_no = $_POST['registration_no'];
$registration_date = $_POST['registration_date'];
$mileage = $_POST['mileage'];
$priority = $_POST['priority'];

// Calculate vehicle age
$reg_date_timestamp = strtotime($registration_date);
$current_timestamp = time();
$vehicle_age = floor(($current_timestamp - $reg_date_timestamp) / (60 * 60 * 24 * 365));

// Check if customer exists
$stmt = $conn->prepare("SELECT customer_id FROM customers WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $customer_id = $row['customer_id'];
} else {
    // Insert customer
    $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $phone, $address);
    if ($stmt->execute()) {
        $customer_id = $conn->insert_id;
    } else {
        $_SESSION['error'] = "Error inserting customer: " . $stmt->error;
        header("Location: ../register_vehicle.php");
        exit;
    }
}
$stmt->close();

// Check if registration_no exists
$stmt = $conn->prepare("SELECT registration_no FROM vehicles WHERE registration_no = ?");
$stmt->bind_param("s", $registration_no);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $_SESSION['error'] = "Error: Registration number already exists.";
    header("Location: ../register_vehicle.php");
    exit;
}
$stmt->close();

// Insert vehicle
$stmt = $conn->prepare("INSERT INTO vehicles (customer_id, brand, model, registration_no, registration_date, mileage, vehicle_age) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssii", $customer_id, $brand, $model, $registration_no, $registration_date, $mileage, $vehicle_age);

if ($stmt->execute()) {
    $success_msg = "Vehicle registered successfully!";

    // 🔔 Notify Admin of new registration
    $admin_res = $conn->query("SELECT id FROM admins LIMIT 1");
    if ($admin_res && $admin_res->num_rows > 0) {
        $admin_data = $admin_res->fetch_assoc();
        $target_admin_id = $admin_data['id'];
        $admin_msg = "New vehicle registered: $registration_no ($brand $model)";
        $notif = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'admin', ?)");
        $notif->bind_param("is", $target_admin_id, $admin_msg);
        $notif->execute();
        $notif->close();
    }
    
    $_SESSION['success'] = "Vehicle registered successfully!";
    // 🛒 AUTO-ADD TO CART (Registration Fee)
    header("Location: ../products/handlers/add_to_cart.php?action=add&type=registration");
} else {
    $_SESSION['error'] = "Error registering vehicle: " . $stmt->error;
    header("Location: ../register_vehicle.php");
}

$conn->close();
exit();
?>
