<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (empty($_POST['service_request_id']) || empty($_POST['employee_id'])) {
        $_SESSION['error'] = "All fields are required";
        header("Location: ../assign_employee_form.php");
        exit();
    }

    // ✅ sanitize input
    $service_request_id = (int) $_POST['service_request_id'];
    $employee_id = (int) $_POST['employee_id'];


    // ✅ CHECK IF REQUEST IS ALREADY COMPLETED
    $statusCheck = $conn->prepare("SELECT status FROM service_requests WHERE id = ?");
    $statusCheck->bind_param("i", $service_request_id);
    $statusCheck->execute();
    $res = $statusCheck->get_result()->fetch_assoc();
    $statusCheck->close();

    if (!$res) {
    $_SESSION['error'] = "Service request not found!";
    header("Location: ../assign_employee_form.php");
    exit();
}

if ($res['status'] === 'Completed') {
    $_SESSION['error'] = "Cannot assign completed request!";
    header("Location: ../assign_employee_form.php");
    exit();
}

    // 🔍 Check duplicate assignment
    $check = $conn->prepare("SELECT id FROM employee_assignments WHERE service_request_id = ?");
    $check->bind_param("i", $service_request_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = "This request is already assigned!";
        header("Location: ../assign_employee_form.php");
        exit();
    }
    $check->close();

    // ✅ Insert assignment
    $stmt = $conn->prepare("INSERT INTO employee_assignments (service_request_id, employee_id) VALUES (?, ?)");

    if (!$stmt) {
        $_SESSION['error'] = "Prepare failed: " . $conn->error;
        header("Location: ../assign_employee_form.php");
        exit();
    }

    $stmt->bind_param("ii", $service_request_id, $employee_id);

    if ($stmt->execute()) {

        // 🔄 Update status safely
        $update = $conn->prepare("UPDATE service_requests SET status = 'In Progress' WHERE id = ?");
        $update->bind_param("i", $service_request_id);
        $update->execute();
        $update->close();

        // 🔔 Add notification for employee
        $notif_msg = "New task assigned: Request #" . $service_request_id;
        $notif = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'employee', ?)");
        $notif->bind_param("is", $employee_id, $notif_msg);
        $notif->execute();
        $notif->close();

        // 🔔 Add notification for customer
        $cust_query = $conn->prepare("SELECT v.customer_id, v.registration_no FROM vehicles v JOIN service_requests sr ON v.registration_no = sr.vehicle_id WHERE sr.id = ?");
        $cust_query->bind_param("i", $service_request_id);
        $cust_query->execute();
        $cust_res = $cust_query->get_result()->fetch_assoc();
        
        if ($cust_res) {
            $cust_id = $cust_res['customer_id'];
            $reg_no = $cust_res['registration_no'];
            $cust_msg = "A technician has been assigned to your vehicle ($reg_no). Work is now 'In Progress'.";
            $notif_cust = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'customer', ?)");
            $notif_cust->bind_param("is", $cust_id, $cust_msg);
            $notif_cust->execute();
            $notif_cust->close();
        }
        $cust_query->close();

        $_SESSION['success'] = "Employee assigned successfully!";
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    // ✅ redirect back
    header("Location: ../assign_employee_form.php");
    exit();
}
?>