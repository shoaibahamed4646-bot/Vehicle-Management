<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (empty($_POST['vehicle_id']) || empty($_POST['complaint']) || empty($_POST['priority'])) {
        die("All fields required");
    }

    $vehicle_id = $_POST['vehicle_id'];
    $complaint = $_POST['complaint'];
    $priority = $_POST['priority'];

    $sql = "INSERT INTO service_requests (vehicle_id, complaint_text, priority, status) 
            VALUES ('$vehicle_id', '$complaint', '$priority', 'Pending')";

    if ($conn->query($sql) === TRUE) {
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>