<?php

/**
 * Authentication & Authorization Middleware
 * Provides functions to check user login status, enforce role-based access, 
 * and fetch the current user's profile.
 */

// Ensure session and DB are available
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/db.php';

/**
 * Check if the current user is authenticated.
 *
 * @return bool
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if the authenticated user has a specific role or one of multiple roles.
 *
 * @param string|array $roles A single role string or an array of roles.
 * @return bool
 */
function hasRole($roles): bool {
    if (!isset($_SESSION['role'])) {
        return false;
    }
    
    if (is_array($roles)) {
        return in_array($_SESSION['role'], $roles, true);
    }
    
    return $_SESSION['role'] === $roles;
}

/**
 * Require a specific role to access the current page.
 * Redirects to an unauthorized or login page if the requirement is not met.
 *
 * @param string|array $requiredRole A single role string or an array of allowed roles.
 * @param string $redirectUrl URL to redirect to if authorization fails.
 * @return void
 */
function requireRole($requiredRole, string $redirectUrl = '/unauthorized.php'): void {
    // If not logged in at all, redirect to login page
    if (!isLoggedIn()) {
        header("Location: /login.php");
        exit();
    }

    // If logged in but lacks the required role, redirect to unauthorized page
    if (!hasRole($requiredRole)) {
        header("Location: " . $redirectUrl);
        exit();
    }
}

/**
 * Require the user to be logged in to access the current page.
 *
 * @param string $redirectUrl URL to redirect to if unauthenticated.
 * @return void
 */
function requireLogin(string $redirectUrl = '/login.php'): void {
    if (!isLoggedIn()) {
        header("Location: " . $redirectUrl);
        exit();
    }
}

/**
 * Fetch the current authenticated user's data from the database.
 * Uses a prepared statement to prevent SQL injection.
 * Returns null if the user is not logged in or doesn't exist.
 *
 * @return array|null
 */
function getCurrentUser(): ?array {
    if (!isLoggedIn()) {
        return null;
    }

    try {
        $db = Database::getInstance()->getConnection();
        
        // Select only necessary fields (avoid selecting passwords/hashes)
        $stmt = $db->prepare("SELECT id, username, email, role, created_at FROM users WHERE id = :id LIMIT 1");
        $stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        $user = $stmt->fetch();
        return $user ?: null;
    } catch (\PDOException $e) {
        // Log the internal error securely, avoiding exposure to the user
        error_log("Failed to fetch current user profile: " . $e->getMessage());
        return null;
    }
}
