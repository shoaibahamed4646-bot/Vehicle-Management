<?php
/**
 * Admin Inventory: Stock Management Dashboard
 *
 * GET  → renders a table of all products with current stock levels.
 *        Low-stock rows (≤ threshold) are highlighted.
 *        Each row has an inline quantity input for rapid updates.
 *
 * POST → accepts inline stock updates (single product at a time via AJAX
 *        or traditional form POST). Returns JSON for AJAX callers.
 *
 * Config:
 *   LOW_STOCK_THRESHOLD — products with stock ≤ this value are flagged.
 */

require_once __DIR__ . '/../../includes/auth.php';

requireRole(ROLE_ADMIN);

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
define('LOW_STOCK_THRESHOLD', 5);

$pdo = Database::getInstance()->getConnection();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function isAjax(): bool
{
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

// ===========================================================================
// POST → Inline stock update
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $newStock   = filter_input(INPUT_POST, 'stock_quantity', FILTER_VALIDATE_INT);

    if (!$productId || $productId < 1) {
        if (isAjax()) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid product ID.']);
            exit;
        }
        $_SESSION['error_msg'] = 'Invalid product ID.';
        header('Location: stock_management.php');
        exit;
    }

    if ($newStock === false || $newStock < 0) {
        if (isAjax()) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Stock must be 0 or a positive integer.']);
            exit;
        }
        $_SESSION['error_msg'] = 'Stock must be 0 or a positive integer.';
        header('Location: stock_management.php');
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE products SET stock_quantity = :stock WHERE product_id = :id");
        $stmt->execute([':stock' => $newStock, ':id' => $productId]);

        if ($stmt->rowCount() === 0) {
            if (isAjax()) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Product not found.']);
                exit;
            }
            $_SESSION['error_msg'] = 'Product not found.';
        } else {
            $isLow = $newStock <= LOW_STOCK_THRESHOLD;
            if (isAjax()) {
                http_response_code(200);
                echo json_encode([
                    'success'  => true,
                    'message'  => 'Stock updated.',
                    'product_id' => $productId,
                    'new_stock'  => $newStock,
                    'is_low'     => $isLow,
                ]);
                exit;
            }
            $_SESSION['success_msg'] = 'Stock updated successfully.';
        }
    } catch (\PDOException $e) {
        error_log("Stock update error (product $productId): " . $e->getMessage());
        if (isAjax()) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database error.']);
            exit;
        }
        $_SESSION['error_msg'] = 'A database error occurred.';
    }

    header('Location: stock_management.php');
    exit;
}

// ===========================================================================
// GET → Render dashboard
// ===========================================================================

// Fetch all products ordered by stock ascending (low stock first)
$products = $pdo->query(
    "SELECT product_id AS id, product_name AS name, category, unit_price AS price, stock_quantity, NULL AS image
     FROM products
     ORDER BY stock_quantity ASC, product_name ASC"
)->fetchAll();

$totalProducts = count($products);
$lowStockCount = 0;
$outOfStock    = 0;
foreach ($products as $p) {
    if ((int) $p['stock_quantity'] === 0) { $outOfStock++; }
    elseif ((int) $p['stock_quantity'] <= LOW_STOCK_THRESHOLD) { $lowStockCount++; }
}

$successMsg = $_SESSION['success_msg'] ?? null;
$errorMsg   = $_SESSION['error_msg'] ?? null;
unset($_SESSION['success_msg'], $_SESSION['error_msg']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Management | Admin</title>
    <style>
        :root {
            --bg-main:#0f1017;--bg-card:#1a1b2e;--bg-row:#1f2133;--bg-input:#151623;
            --text-main:#fff;--text-muted:#8b95a5;
            --accent:#3b82f6;--accent-hover:#2563eb;
            --danger:#ef4444;--danger-bg:rgba(239,68,68,.08);--danger-border:rgba(239,68,68,.25);
            --warning:#f59e0b;--warning-bg:rgba(245,158,11,.08);--warning-border:rgba(245,158,11,.25);
            --success:#22c55e;--success-bg:rgba(34,197,94,.08);--success-border:rgba(34,197,94,.25);
            --card-border:rgba(255,255,255,0.06);
            --transition:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        body {
            margin:0;padding:0;background:var(--bg-main);color:var(--text-main);
            font-family:-apple-system,BlinkMacSystemFont,"Inter","Segoe UI",Roboto,sans-serif;
            -webkit-font-smoothing:antialiased;min-height:100vh;
        }
        .container { max-width:1200px;margin:0 auto;padding:50px 20px; }

        /* Header */
        .page-header { margin-bottom:35px; }
        .page-header h1 { font-size:2.5rem;font-weight:800;margin:0 0 8px;letter-spacing:-.03em; }
        .page-header p { color:var(--text-muted);margin:0;font-size:1.05rem; }

        /* Summary Cards */
        .summary-grid {
            display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:30px;
        }
        .summary-card {
            background:var(--bg-card);border:1px solid var(--card-border);border-radius:12px;
            padding:22px 25px;
        }
        .summary-card .label { font-size:.85rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px; }
        .summary-card .value { font-size:2rem;font-weight:800; }
        .summary-card.danger .value { color:var(--danger); }
        .summary-card.warning .value { color:var(--warning); }
        .summary-card.ok .value { color:var(--success); }

        /* Flash messages */
        .flash {
            border-radius:10px;padding:14px 18px;margin-bottom:20px;font-size:.92rem;
            display:flex;align-items:center;gap:10px;
        }
        .flash-success { background:var(--success-bg);border:1px solid var(--success-border);color:var(--success); }
        .flash-error   { background:var(--danger-bg);border:1px solid var(--danger-border);color:var(--danger); }

        /* Table */
        .table-wrapper {
            background:var(--bg-card);border:1px solid var(--card-border);border-radius:14px;
            overflow:hidden;
        }
        table { width:100%;border-collapse:collapse; }
        thead th {
            text-align:left;padding:16px 20px;font-size:.8rem;text-transform:uppercase;
            letter-spacing:.06em;color:var(--text-muted);border-bottom:1px solid var(--card-border);
            background:rgba(0,0,0,.15);
        }
        tbody tr {
            border-bottom:1px solid var(--card-border);transition:background .2s;
        }
        tbody tr:last-child { border-bottom:none; }
        tbody tr:hover { background:rgba(255,255,255,.02); }
        tbody td { padding:14px 20px;vertical-align:middle; }

        /* Row status classes */
        tr.row-out-of-stock {
            background:var(--danger-bg) !important;
        }
        tr.row-out-of-stock td { color:#fca5a5; }

        tr.row-low-stock {
            background:var(--warning-bg) !important;
        }
        tr.row-low-stock td { color:#fde68a; }

        /* Product cell with image */
        .product-cell { display:flex;align-items:center;gap:12px; }
        .product-cell img {
            width:40px;height:40px;border-radius:8px;object-fit:cover;
            border:1px solid var(--card-border);flex-shrink:0;
        }
        .product-cell .placeholder-img {
            width:40px;height:40px;border-radius:8px;background:var(--bg-input);
            display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;
        }
        .product-cell .p-name { font-weight:600; }

        .category-badge {
            display:inline-block;background:rgba(255,255,255,.05);border:1px solid var(--card-border);
            border-radius:6px;padding:3px 10px;font-size:.8rem;color:var(--text-muted);
        }

        /* Stock status badge */
        .stock-badge {
            display:inline-block;padding:4px 10px;border-radius:20px;font-size:.8rem;font-weight:700;
            letter-spacing:.02em;
        }
        .badge-ok      { background:var(--success-bg);color:var(--success);border:1px solid var(--success-border); }
        .badge-low     { background:var(--warning-bg);color:var(--warning);border:1px solid var(--warning-border); }
        .badge-out     { background:var(--danger-bg);color:var(--danger);border:1px solid var(--danger-border); }

        /* Inline edit form */
        .inline-form { display:flex;align-items:center;gap:8px; }
        .inline-input {
            width:80px;background:var(--bg-input);border:1px solid var(--card-border);
            color:var(--text-main);padding:8px 10px;border-radius:6px;font-size:.95rem;
            text-align:center;font-family:inherit;transition:var(--transition);
        }
        .inline-input:focus { outline:none;border-color:var(--accent);box-shadow:0 0 0 2px rgba(59,130,246,.2); }
        .btn-save {
            background:var(--accent);color:#fff;border:none;padding:8px 14px;border-radius:6px;
            font-weight:600;font-size:.85rem;cursor:pointer;transition:var(--transition);
            white-space:nowrap;
        }
        .btn-save:hover { background:var(--accent-hover); }
        .btn-save:disabled { opacity:.4;cursor:not-allowed; }

        /* Feedback indicator */
        .save-feedback {
            font-size:.8rem;font-weight:600;opacity:0;transition:opacity .3s;margin-left:4px;
        }
        .save-feedback.show { opacity:1; }
        .save-feedback.ok   { color:var(--success); }
        .save-feedback.err  { color:var(--danger); }

        @media(max-width:768px){
            .summary-grid { grid-template-columns:1fr; }
            thead th:nth-child(3),tbody td:nth-child(3){ display:none; } /* hide category on mobile */
            .page-header h1 { font-size:2rem; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="page-header">
        <h1>Stock Management</h1>
        <p>Monitor inventory levels and update stock quantities in real-time.</p>
    </div>

    <!-- Summary Cards -->
    <div class="summary-grid">
        <div class="summary-card ok">
            <div class="label">Total Products</div>
            <div class="value"><?= $totalProducts ?></div>
        </div>
        <div class="summary-card warning">
            <div class="label">Low Stock (≤ <?= LOW_STOCK_THRESHOLD ?>)</div>
            <div class="value" id="lowCount"><?= $lowStockCount ?></div>
        </div>
        <div class="summary-card danger">
            <div class="label">Out of Stock</div>
            <div class="value" id="outCount"><?= $outOfStock ?></div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if ($successMsg): ?>
        <div class="flash flash-success">✓ <?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
        <div class="flash flash-error">✗ <?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <!-- Product Table -->
    <div class="table-wrapper">
        <?php if (empty($products)): ?>
            <div style="padding:40px;text-align:center;color:var(--text-muted);">No products found.</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Stock Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $p):
                    $stock = (int) $p['stock_quantity'];
                    if ($stock === 0) {
                        $rowClass   = 'row-out-of-stock';
                        $badgeClass = 'badge-out';
                        $badgeText  = 'OUT OF STOCK';
                    } elseif ($stock <= LOW_STOCK_THRESHOLD) {
                        $rowClass   = 'row-low-stock';
                        $badgeClass = 'badge-low';
                        $badgeText  = 'LOW STOCK';
                    } else {
                        $rowClass   = '';
                        $badgeClass = 'badge-ok';
                        $badgeText  = 'IN STOCK';
                    }
                ?>
                <tr class="<?= $rowClass ?>" id="row-<?= $p['id'] ?>" data-stock="<?= $stock ?>">
                    <td>
                        <div class="product-cell">
                            <?php if (!empty($p['image'])): ?>
                                <img src="/<?= htmlspecialchars($p['image']) ?>" alt="">
                            <?php else: ?>
                                <div class="placeholder-img">📦</div>
                            <?php endif; ?>
                            <span class="p-name"><?= htmlspecialchars($p['name']) ?></span>
                        </div>
                    </td>
                    <td>$<?= number_format($p['price'], 2) ?></td>
                    <td><span class="category-badge"><?= htmlspecialchars($p['category'] ?? '—') ?></span></td>
                    <td><span class="stock-badge <?= $badgeClass ?>" id="badge-<?= $p['id'] ?>"><?= $badgeText ?></span></td>
                    <td>
                        <div class="inline-form">
                            <input type="number" class="inline-input" id="input-<?= $p['id'] ?>"
                                   value="<?= $stock ?>" min="0" step="1"
                                   data-original="<?= $stock ?>"
                                   onchange="enableSave(<?= $p['id'] ?>)"
                                   oninput="enableSave(<?= $p['id'] ?>)">
                            <button class="btn-save" id="btn-<?= $p['id'] ?>"
                                    onclick="saveStock(<?= $p['id'] ?>)" disabled>Save</button>
                            <span class="save-feedback" id="fb-<?= $p['id'] ?>"></span>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<script>
    const LOW = <?= LOW_STOCK_THRESHOLD ?>;

    function enableSave(id) {
        const input = document.getElementById('input-' + id);
        const btn   = document.getElementById('btn-' + id);
        const orig  = parseInt(input.dataset.original, 10);
        const cur   = parseInt(input.value, 10);
        btn.disabled = (isNaN(cur) || cur < 0 || cur === orig);
    }

    function saveStock(id) {
        const input = document.getElementById('input-' + id);
        const btn   = document.getElementById('btn-' + id);
        const fb    = document.getElementById('fb-' + id);
        const qty   = parseInt(input.value, 10);

        if (isNaN(qty) || qty < 0) return;

        btn.disabled = true;
        btn.textContent = '...';
        fb.className = 'save-feedback';

        const body = new URLSearchParams();
        body.append('product_id', id);
        body.append('stock_quantity', qty);

        fetch('stock_management.php', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: body.toString(),
        })
        .then(r => r.json())
        .then(data => {
            btn.textContent = 'Save';
            if (data.success) {
                input.dataset.original = qty;
                fb.textContent = '✓ Saved';
                fb.className = 'save-feedback show ok';
                updateRowVisual(id, qty);
            } else {
                fb.textContent = '✗ ' + (data.message || 'Error');
                fb.className = 'save-feedback show err';
                btn.disabled = false;
            }
            setTimeout(() => { fb.className = 'save-feedback'; }, 2500);
        })
        .catch(() => {
            btn.textContent = 'Save';
            btn.disabled = false;
            fb.textContent = '✗ Network error';
            fb.className = 'save-feedback show err';
            setTimeout(() => { fb.className = 'save-feedback'; }, 2500);
        });
    }

    function updateRowVisual(id, qty) {
        const row   = document.getElementById('row-' + id);
        const badge = document.getElementById('badge-' + id);

        row.className = '';
        if (qty === 0) {
            row.classList.add('row-out-of-stock');
            badge.className = 'stock-badge badge-out';
            badge.textContent = 'OUT OF STOCK';
        } else if (qty <= LOW) {
            row.classList.add('row-low-stock');
            badge.className = 'stock-badge badge-low';
            badge.textContent = 'LOW STOCK';
        } else {
            badge.className = 'stock-badge badge-ok';
            badge.textContent = 'IN STOCK';
        }
        row.dataset.stock = qty;
        recalcSummary();
    }

    function recalcSummary() {
        let low = 0, out = 0;
        document.querySelectorAll('tbody tr').forEach(row => {
            const s = parseInt(row.dataset.stock, 10);
            if (s === 0) out++;
            else if (s <= LOW) low++;
        });
        document.getElementById('lowCount').textContent = low;
        document.getElementById('outCount').textContent = out;
    }
</script>

</body>
</html>
