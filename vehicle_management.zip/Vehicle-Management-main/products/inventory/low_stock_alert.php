<?php
/**
 * Admin Inventory: Low Stock Alerts
 *
 * Displays products whose stock_quantity falls at or below a configurable
 * threshold. Thresholds can be overridden per product category.
 *
 * GET params (optional):
 *   default_threshold — int, global fallback (default: 5)
 *
 * POST → saves per-category threshold overrides to a JSON config file.
 *
 * Threshold resolution order:
 *   1. Per-category override (from config file)
 *   2. ?default_threshold query param
 *   3. Hardcoded fallback (5)
 */

require_once __DIR__ . '/../../includes/auth.php';

requireRole(ROLE_ADMIN);

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
$configFile       = __DIR__ . '/threshold_config.json';
$fallbackDefault  = 5;

$defaultThreshold = filter_input(INPUT_GET, 'default_threshold', FILTER_VALIDATE_INT)
                  ?? $fallbackDefault;
if ($defaultThreshold < 0) {
    $defaultThreshold = $fallbackDefault;
}

// Load per-category overrides
$categoryThresholds = [];
if (file_exists($configFile)) {
    $raw = json_decode(file_get_contents($configFile), true);
    if (is_array($raw)) {
        $categoryThresholds = $raw;
    }
}

// ===========================================================================
// POST → Save threshold overrides
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_SPECIAL_CHARS);

    if ($action === 'save_thresholds') {
        $categories  = $_POST['categories'] ?? [];
        $thresholds  = $_POST['thresholds'] ?? [];
        $newConfig   = [];

        for ($i = 0; $i < count($categories); $i++) {
            $cat = trim($categories[$i] ?? '');
            $thr = filter_var($thresholds[$i] ?? '', FILTER_VALIDATE_INT);
            if ($cat !== '' && $thr !== false && $thr >= 0) {
                $newConfig[$cat] = $thr;
            }
        }

        if (file_put_contents($configFile, json_encode($newConfig, JSON_PRETTY_PRINT))) {
            $_SESSION['success_msg'] = 'Category thresholds saved.';
            $categoryThresholds = $newConfig;
        } else {
            $_SESSION['error_msg'] = 'Failed to write config file. Check folder permissions.';
        }
    }

    header('Location: low_stock_alert.php' . ($defaultThreshold !== $fallbackDefault ? "?default_threshold=$defaultThreshold" : ''));
    exit;
}

// ===========================================================================
// GET → Query low-stock products
// ===========================================================================
$pdo = Database::getInstance()->getConnection();

// Fetch ALL products (we filter in PHP because thresholds vary per category)
$products = $pdo->query(
    "SELECT product_id AS id, product_name AS name, category, unit_price AS price, stock_quantity, NULL AS image
     FROM products
     WHERE (is_active = 1 OR is_active IS NULL)
     ORDER BY stock_quantity ASC, category ASC, product_name ASC"
)->fetchAll();

// Resolve threshold per product and filter
$alerts = [];
$allCategories = [];

foreach ($products as $p) {
    $cat   = $p['category'] ?? 'Uncategorized';
    $stock = (int) $p['stock_quantity'];

    // Collect all categories for the config form
    if (!in_array($cat, $allCategories, true)) {
        $allCategories[] = $cat;
    }

    // Determine the effective threshold for this product's category
    $threshold = $categoryThresholds[$cat] ?? $defaultThreshold;

    if ($stock <= $threshold) {
        $p['effective_threshold'] = $threshold;
        $p['deficit'] = $threshold - $stock;
        $alerts[] = $p;
    }
}

// Group alerts by category for display
$grouped = [];
foreach ($alerts as $a) {
    $cat = $a['category'] ?? 'Uncategorized';
    $grouped[$cat][] = $a;
}

$successMsg = $_SESSION['success_msg'] ?? null;
$errorMsg   = $_SESSION['error_msg'] ?? null;
unset($_SESSION['success_msg'], $_SESSION['error_msg']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Low Stock Alerts | Admin</title>
    <style>
        :root {
            --bg-main:#0f1017;--bg-card:#1a1b2e;--bg-row:#1f2133;--bg-input:#151623;
            --text-main:#fff;--text-muted:#8b95a5;
            --accent:#3b82f6;--accent-hover:#2563eb;
            --danger:#ef4444;--danger-bg:rgba(239,68,68,.08);--danger-border:rgba(239,68,68,.25);
            --warning:#f59e0b;--warning-bg:rgba(245,158,11,.08);--warning-border:rgba(245,158,11,.25);
            --success:#22c55e;--success-bg:rgba(34,197,94,.08);--success-border:rgba(34,197,94,.25);
            --card-border:rgba(255,255,255,0.06);
            --transition:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        body{margin:0;padding:0;background:var(--bg-main);color:var(--text-main);
            font-family:-apple-system,BlinkMacSystemFont,"Inter","Segoe UI",Roboto,sans-serif;
            -webkit-font-smoothing:antialiased;min-height:100vh;}
        .container{max-width:1100px;margin:0 auto;padding:50px 20px;}

        /* Header */
        .page-header{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:15px;margin-bottom:35px;}
        .page-header h1{font-size:2.5rem;font-weight:800;margin:0;letter-spacing:-.03em;}
        .page-header p{color:var(--text-muted);margin:4px 0 0;font-size:1.05rem;}
        .header-actions{display:flex;gap:10px;align-items:center;}
        .btn-config{
            background:var(--bg-card);border:1px solid var(--card-border);color:var(--text-muted);
            padding:10px 18px;border-radius:8px;font-size:.9rem;font-weight:600;cursor:pointer;
            transition:var(--transition);display:flex;align-items:center;gap:6px;
        }
        .btn-config:hover{border-color:var(--accent);color:var(--text-main);}

        /* Summary Bar */
        .summary-bar{
            display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-bottom:30px;
        }
        .stat{background:var(--bg-card);border:1px solid var(--card-border);border-radius:12px;padding:20px 25px;}
        .stat .label{font-size:.8rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px;}
        .stat .value{font-size:2rem;font-weight:800;}
        .stat.red .value{color:var(--danger);}
        .stat.amber .value{color:var(--warning);}

        /* Flash */
        .flash{border-radius:10px;padding:14px 18px;margin-bottom:20px;font-size:.92rem;display:flex;align-items:center;gap:10px;}
        .flash-success{background:var(--success-bg);border:1px solid var(--success-border);color:var(--success);}
        .flash-error{background:var(--danger-bg);border:1px solid var(--danger-border);color:var(--danger);}

        /* Category Group */
        .category-group{margin-bottom:30px;}
        .category-header{
            display:flex;justify-content:space-between;align-items:center;
            padding:14px 0;border-bottom:1px solid var(--card-border);margin-bottom:15px;
        }
        .category-name{font-size:1.2rem;font-weight:700;}
        .threshold-badge{
            font-size:.8rem;padding:4px 12px;border-radius:20px;
            background:rgba(255,255,255,.05);border:1px solid var(--card-border);color:var(--text-muted);
        }

        /* Alert Row */
        .alert-row{
            display:flex;align-items:center;justify-content:space-between;
            background:var(--bg-card);border:1px solid var(--card-border);border-radius:10px;
            padding:16px 20px;margin-bottom:10px;transition:var(--transition);
        }
        .alert-row:hover{border-color:rgba(239,68,68,.3);transform:translateX(3px);}
        .alert-row.critical{border-left:3px solid var(--danger);}
        .alert-row.warning{border-left:3px solid var(--warning);}

        .alert-left{display:flex;align-items:center;gap:14px;flex:1;min-width:0;}
        .alert-left img{width:40px;height:40px;border-radius:8px;object-fit:cover;border:1px solid var(--card-border);flex-shrink:0;}
        .alert-left .placeholder-img{width:40px;height:40px;border-radius:8px;background:var(--bg-input);display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;}
        .alert-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}

        .alert-right{display:flex;align-items:center;gap:20px;flex-shrink:0;}
        .stock-num{font-size:1.5rem;font-weight:800;min-width:40px;text-align:right;}
        .stock-num.zero{color:var(--danger);}
        .stock-num.low{color:var(--warning);}
        .deficit-label{font-size:.8rem;color:var(--text-muted);line-height:1.3;}

        .btn-restock{
            background:var(--accent);color:#fff;border:none;padding:8px 16px;border-radius:6px;
            font-weight:600;font-size:.85rem;cursor:pointer;transition:var(--transition);
            text-decoration:none;white-space:nowrap;
        }
        .btn-restock:hover{background:var(--accent-hover);}

        /* Config Panel (collapsible) */
        .config-panel{
            background:var(--bg-card);border:1px solid var(--card-border);border-radius:14px;
            padding:0;margin-bottom:30px;overflow:hidden;max-height:0;
            transition:max-height .4s ease,padding .4s ease;
        }
        .config-panel.open{max-height:800px;padding:25px 30px;}
        .config-title{font-size:1.1rem;font-weight:700;margin:0 0 20px;}
        .config-row{display:flex;align-items:center;gap:12px;margin-bottom:12px;}
        .config-cat{
            flex:1;background:var(--bg-input);border:1px solid var(--card-border);
            color:var(--text-main);padding:10px 14px;border-radius:6px;font-size:.95rem;font-family:inherit;
        }
        .config-val{
            width:80px;background:var(--bg-input);border:1px solid var(--card-border);
            color:var(--text-main);padding:10px;border-radius:6px;font-size:.95rem;text-align:center;font-family:inherit;
        }
        .config-cat:focus,.config-val:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 2px rgba(59,130,246,.2);}
        .btn-row-config{display:flex;gap:10px;margin-top:15px;}
        .btn-add-row{
            background:transparent;border:1px dashed var(--card-border);color:var(--text-muted);
            padding:8px 16px;border-radius:6px;font-size:.85rem;cursor:pointer;transition:var(--transition);
        }
        .btn-add-row:hover{border-color:var(--accent);color:var(--accent);}
        .btn-save-config{
            background:var(--accent);color:#fff;border:none;padding:10px 20px;border-radius:6px;
            font-weight:600;font-size:.9rem;cursor:pointer;transition:var(--transition);
        }
        .btn-save-config:hover{background:var(--accent-hover);}
        .btn-remove-row{
            background:transparent;border:none;color:var(--danger);cursor:pointer;font-size:1.2rem;
            padding:4px 8px;transition:var(--transition);border-radius:4px;
        }
        .btn-remove-row:hover{background:var(--danger-bg);}

        /* Empty state */
        .empty-state{text-align:center;padding:60px 20px;color:var(--text-muted);}
        .empty-state .icon{font-size:3rem;margin-bottom:15px;}
        .empty-state h3{color:var(--success);margin:0 0 8px;}

        @media(max-width:768px){
            .summary-bar{grid-template-columns:1fr;}
            .page-header{flex-direction:column;}
            .alert-right{gap:12px;}
            .page-header h1{font-size:2rem;}
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <div class="page-header">
        <div>
            <h1>Low Stock Alerts</h1>
            <p>Products at or below their restock threshold. Default: ≤ <?= $defaultThreshold ?> units.</p>
        </div>
        <div class="header-actions">
            <button class="btn-config" onclick="toggleConfig()">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                Configure Thresholds
            </button>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if ($successMsg): ?>
        <div class="flash flash-success">✓ <?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
        <div class="flash flash-error">✗ <?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <!-- Collapsible Config Panel -->
    <div class="config-panel" id="configPanel">
        <div class="config-title">Category Threshold Overrides</div>
        <form method="POST" action="low_stock_alert.php<?= $defaultThreshold !== $fallbackDefault ? "?default_threshold=$defaultThreshold" : '' ?>">
            <input type="hidden" name="action" value="save_thresholds">
            <div id="configRows">
                <?php
                // Pre-populate with existing overrides, or show one empty row
                $rows = !empty($categoryThresholds) ? $categoryThresholds : [''=>$defaultThreshold];
                foreach ($rows as $cat => $thr): ?>
                <div class="config-row">
                    <input type="text" class="config-cat" name="categories[]"
                           value="<?= htmlspecialchars($cat) ?>" placeholder="Category name"
                           list="cat-suggestions">
                    <input type="number" class="config-val" name="thresholds[]"
                           value="<?= (int) $thr ?>" min="0" placeholder="Qty">
                    <button type="button" class="btn-remove-row" onclick="this.parentElement.remove()">✕</button>
                </div>
                <?php endforeach; ?>
            </div>
            <datalist id="cat-suggestions">
                <?php foreach ($allCategories as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>">
                <?php endforeach; ?>
            </datalist>
            <div class="btn-row-config">
                <button type="button" class="btn-add-row" onclick="addConfigRow()">+ Add Category</button>
                <button type="submit" class="btn-save-config">Save Thresholds</button>
            </div>
        </form>
    </div>

    <!-- Summary Bar -->
    <div class="summary-bar">
        <div class="stat red">
            <div class="label">Total Alerts</div>
            <div class="value"><?= count($alerts) ?></div>
        </div>
        <div class="stat red">
            <div class="label">Out of Stock</div>
            <div class="value"><?= count(array_filter($alerts, fn($a) => (int)$a['stock_quantity'] === 0)) ?></div>
        </div>
        <div class="stat amber">
            <div class="label">Categories Affected</div>
            <div class="value"><?= count($grouped) ?></div>
        </div>
    </div>

    <!-- Alert List, Grouped by Category -->
    <?php if (empty($alerts)): ?>
        <div class="empty-state">
            <div class="icon">✅</div>
            <h3>All Clear</h3>
            <p>No products are below their restock threshold right now.</p>
        </div>
    <?php else: ?>
        <?php foreach ($grouped as $catName => $items): ?>
            <div class="category-group">
                <div class="category-header">
                    <span class="category-name"><?= htmlspecialchars($catName) ?></span>
                    <span class="threshold-badge">Threshold: ≤ <?= $items[0]['effective_threshold'] ?></span>
                </div>
                <?php foreach ($items as $item):
                    $stock   = (int) $item['stock_quantity'];
                    $sevClass = $stock === 0 ? 'critical' : 'warning';
                    $numClass = $stock === 0 ? 'zero' : 'low';
                ?>
                <div class="alert-row <?= $sevClass ?>">
                    <div class="alert-left">
                        <?php if (!empty($item['image'])): ?>
                            <img src="/<?= htmlspecialchars($item['image']) ?>" alt="">
                        <?php else: ?>
                            <div class="placeholder-img">📦</div>
                        <?php endif; ?>
                        <span class="alert-name"><?= htmlspecialchars($item['name']) ?></span>
                    </div>
                    <div class="alert-right">
                        <div>
                            <div class="stock-num <?= $numClass ?>"><?= $stock ?></div>
                            <div class="deficit-label">need <?= $item['deficit'] ?> more</div>
                        </div>
                        <a href="/products/inventory/stock_management.php" class="btn-restock">Restock</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</div>

<script>
    function toggleConfig() {
        document.getElementById('configPanel').classList.toggle('open');
    }

    function addConfigRow() {
        const container = document.getElementById('configRows');
        const row = document.createElement('div');
        row.className = 'config-row';
        row.innerHTML = `
            <input type="text" class="config-cat" name="categories[]" placeholder="Category name" list="cat-suggestions">
            <input type="number" class="config-val" name="thresholds[]" value="<?= $defaultThreshold ?>" min="0" placeholder="Qty">
            <button type="button" class="btn-remove-row" onclick="this.parentElement.remove()">✕</button>
        `;
        container.appendChild(row);
        row.querySelector('.config-cat').focus();
    }
</script>

</body>
</html>
