<?php
/**
 * Checkout Handler: Process Order
 *
 * Accepts a POST from the cart/checkout page.
 * Within a single DB transaction it:
 *   1. Re-validates every cart item against current stock.
 *   2. Creates an `orders` row.
 *   3. Creates `order_items` rows for each product.
 *   4. Decrements `stock_quantity` on each `products` row.
 *   5. Clears the session cart.
 *   6. Redirects to the invoice/confirmation page.
 *
 * POST fields (optional enrichment from checkout form):
 *   payment_method — string (default: 'cash')
 *   notes          — string
 *
 * Requires: authenticated user session with user_id.
 */

require_once __DIR__ . '/../../includes/auth.php';

// User must be logged in to place an order
requireLogin();

// ---------------------------------------------------------------------------
// 1. Enforce POST
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_msg'] = 'Invalid request method.';
    header('Location: /products/views/cart.php');
    exit;
}

// ---------------------------------------------------------------------------
// 2. Validate cart is non-empty
// ---------------------------------------------------------------------------
if (empty($_SESSION['cart'])) {
    $_SESSION['error_msg'] = 'Your cart is empty. Add products before checking out.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ---------------------------------------------------------------------------
// 3. Sanitise optional checkout inputs
// ---------------------------------------------------------------------------
$paymentMethod = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'cash';
$notes         = trim(filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');

$allowedMethods = ['cash', 'credit_card', 'bank_transfer', 'paypal'];
if (!in_array($paymentMethod, $allowedMethods, true)) {
    $paymentMethod = 'cash';
}

$customerId = (int) $_SESSION['user_id'];

// ---------------------------------------------------------------------------
// 4. Begin atomic transaction
// ---------------------------------------------------------------------------
$pdo = Database::getInstance()->getConnection();

try {
    $cart = $_SESSION['cart'];
    $orderTotal = 0.0;
    $validItems = [];
    $hasService = false;

    foreach ($cart as $key => $item) {
        $qty = (int)$item['quantity'];
        $type = $item['type'] ?? 'product';
        $price = (float)$item['price'];
        
        // 4a. Validate Products Only
        if ($type === 'product') {
            $pid = (int)$item['id'];
            $stmt = $pdo->prepare("SELECT stock_quantity, product_name FROM products WHERE product_id = ? FOR UPDATE");
            $stmt->execute([$pid]);
            $dbRow = $stmt->fetch();
            
            if (!$dbRow || $dbRow['stock_quantity'] < $qty) {
                $pdo->rollBack();
                $_SESSION['error_msg'] = "Insufficient stock for " . ($dbRow['product_name'] ?? 'Product');
                header('Location: /products/views/cart.php');
                exit;
            }
        }

        $lineTotal = $price * $qty;
        $orderTotal += $lineTotal;
        $validItems[] = $item;
        if ($type === 'service' || $type === 'package') $hasService = true;
    }

    // 4b. Insert Invoice
    $inv_type = $hasService ? 'service' : 'product';
    $orderStmt = $pdo->prepare("INSERT INTO invoices (customer_id, invoice_type, subtotal, discount, total_amount, payment_status, notes, created_at) VALUES (?, ?, ?, 0, ?, 'unpaid', ?, NOW())");
    $orderStmt->execute([$customerId, $inv_type, $orderTotal, $orderTotal, $notes]);
    $invoiceId = $pdo->lastInsertId();

    // 4c. Process Items
    foreach ($validItems as $vi) {
        $type = $vi['type'] ?? 'product';
        
        // Insert Invoice Item
        $itemStmt = $pdo->prepare("INSERT INTO invoice_items (invoice_id, item_type, product_id, package_id, service_id, item_name, unit_price, quantity, line_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $itemStmt->execute([
            $invoiceId, 
            $type,
            ($type === 'product' ? $vi['id'] : null),
            ($type === 'package' ? $vi['id'] : null),
            ($type === 'service' ? $vi['id'] : null),
            $vi['name'],
            $vi['price'],
            $vi['quantity'],
            $vi['price'] * $vi['quantity']
        ]);

        // Action per type
        if ($type === 'product') {
            $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?")->execute([$vi['quantity'], $vi['id']]);
        } elseif ($type === 'service' || $type === 'package') {
            // Create Service Request for Employees
            $reqStmt = $pdo->prepare("INSERT INTO service_requests (vehicle_id, service_type, complaint_text, priority, status) VALUES (?, ?, ?, 'Medium', 'Pending')");
            $reqStmt->execute([
                $vi['vehicle_id'] ?? 'N/A', 
                $vi['name'], 
                $vi['notes'] ?? 'Order via Cart'
            ]);
        }
    }

    // 🔔 Notify Admin
    $admin_q = $pdo->query("SELECT id FROM admins LIMIT 1");
    if ($admin_data = $admin_q->fetch()) {
        $admin_id = $admin_data['id'];
        $msg = "New Order #$invoiceId placed by Customer #$customerId";
        $pdo->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'admin', ?)")->execute([$admin_id, $msg]);
    }

    $pdo->commit();

    $_SESSION['cart'] = [];
    $_SESSION['success_msg'] = "Order #$invoiceId placed successfully!";
    header("Location: /products/views/order_confirmation.php?invoice_id=$invoiceId");
    exit;

} catch (\PDOException $e) {
    // Attempt rollback (safe even if transaction already rolled back)
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("Order processing failed for customer $customerId: " . $e->getMessage());

    $_SESSION['error_msg'] = 'Something went wrong while placing your order. Please try again.';
    header('Location: /products/views/cart.php');
    exit;

} catch (\Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("Unexpected error during checkout: " . $e->getMessage());

    $_SESSION['error_msg'] = 'An unexpected error occurred. Please try again.';
    header('Location: /products/views/cart.php');
    exit;
}
