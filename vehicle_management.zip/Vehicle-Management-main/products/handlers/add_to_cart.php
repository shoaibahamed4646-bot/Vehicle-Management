<?php
/**
 * Cart Handler: Add / Update / Remove products in a session-based cart.
 *
 * Accepted via POST:
 *   action      — 'add' | 'update' | 'remove'  (default: 'add')
 *   product_id  — int, required
 *   quantity    — int, required for 'add'/'update' (ignored for 'remove')
 *
 * Accepted via GET:
 *   action=clear — empties the entire cart
 *
 * Cart structure in $_SESSION['cart']:
 *   [
 *     product_id => [
 *       'product_id' => int,
 *       'name'       => string,
 *       'price'      => float,
 *       'quantity'   => int,
 *       'image'      => string|null,
 *     ],
 *     ...
 *   ]
 *
 * Returns JSON for AJAX callers (detected via X-Requested-With header)
 * or redirects back for standard form submissions.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Send a JSON response and terminate.
 */
function jsonResponse($httpCode, $success, $message, $extra = [])
{
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message,
    ], $extra));
    exit;
}

/**
 * Redirect back to the referring page with a flash message.
 */
function redirectBack($message, $type = 'success')
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
    $referer = $_SERVER['HTTP_REFERER'] ?? '/products/views/product_list.php';
    header("Location: $referer");
    exit;
}

/**
 * Decide whether the caller expects JSON.
 */
function isAjax()
{
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Build a lightweight cart summary for JSON responses.
 */
function cartSummary()
{
    $cart = $_SESSION['cart'] ?? [];
    $totalItems = 0;
    $totalPrice = 0.0;

    foreach ($cart as $item) {
        $totalItems += $item['quantity'];
        $totalPrice += $item['price'] * $item['quantity'];
    }

    return [
        'cart_count'  => count($cart),
        'total_items' => $totalItems,
        'total_price' => round($totalPrice, 2),
    ];
}

/**
 * Fetch an item row from the database (Product, Service, or Package).
 */
function fetchItem($id, $type)
{
    $pdo = Database::getInstance()->getConnection();
    
    if ($type === 'package') {
        $stmt = $pdo->prepare("SELECT package_id AS id, package_name AS name, total_price AS price, 9999 AS stock_quantity, '📦' AS image FROM service_packages WHERE package_id = :id LIMIT 1");
    } elseif ($type === 'service') {
        $stmt = $pdo->prepare("SELECT service_id AS id, service_name AS name, price AS price, 9999 AS stock_quantity, '🛠️' AS image FROM services WHERE service_id = :id LIMIT 1");
    } elseif ($type === 'registration') {
        return ['id' => 0, 'name' => 'Vehicle Registration Fee', 'price' => 50.00, 'stock_quantity' => 9999, 'image' => '📝'];
    } else {
        $stmt = $pdo->prepare("SELECT product_id AS id, product_name AS name, unit_price AS price, stock_quantity, '📦' AS image FROM products WHERE product_id = :id LIMIT 1");
    }
    
    if (isset($stmt)) {
        $stmt->execute([':id' => $id]);
        $item = $stmt->fetch();
        return $item ?: null;
    }
    return null;
}

// ---------------------------------------------------------------------------
// Initialise cart if it doesn't exist yet
// ---------------------------------------------------------------------------
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ---------------------------------------------------------------------------
// Route: GET ?action=clear  →  empty the whole cart
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// 1. Extract Parameters
// ---------------------------------------------------------------------------
$action    = $_REQUEST['action'] ?? 'add';
$id        = (int)($_REQUEST['id'] ?? $_REQUEST['product_id'] ?? 0);
$quantity  = (int)($_REQUEST['quantity'] ?? 1);
$type      = $_REQUEST['type'] ?? 'product'; // 'product', 'package', 'service', 'registration'

// ---------------------------------------------------------------------------
// 2. Handle 'clear' action
// ---------------------------------------------------------------------------
if ($action === 'clear') {
    $_SESSION['cart'] = [];
    if (isAjax()) {
        jsonResponse(200, true, 'Cart cleared.', cartSummary());
    }
    redirectBack('Your cart has been cleared.');
}

// ---------------------------------------------------------------------------
// 3. Handle Registration Auto-Add
// ---------------------------------------------------------------------------
if ($type === 'registration' && $action === 'add') {
    $regItem = fetchItem(0, 'registration');
    $_SESSION['cart']['REG_0'] = [
        'id'         => 0,
        'product_id' => 0,
        'name'       => $regItem['name'],
        'price'      => $regItem['price'],
        'quantity'   => 1,
        'image'      => $regItem['image'],
        'type'       => 'registration'
    ];
    redirectBack('Registration fee added to cart.');
}

// ---------------------------------------------------------------------------
// Validate ID
// ---------------------------------------------------------------------------
if ($id < 1 && $type !== 'registration') {
    if (isAjax()) {
        jsonResponse(400, false, 'Invalid product ID.');
    }
    redirectBack('Invalid product ID.', 'error');
}

// ---------------------------------------------------------------------------
// ACTION: remove
// ---------------------------------------------------------------------------
if ($action === 'remove') {
    $cartKey = ($type === 'product') ? $id : ($type === 'registration' ? 'REG_0' : strtoupper($type[0]) . "_" . $id);
    if (isset($_SESSION['cart'][$cartKey])) {
        $removedName = $_SESSION['cart'][$cartKey]['name'];
        unset($_SESSION['cart'][$cartKey]);

        if (isAjax()) {
            jsonResponse(200, true, "$removedName removed from cart.", cartSummary());
        }
        redirectBack("$removedName removed from cart.");
    }

    if (isAjax()) {
        jsonResponse(404, false, 'Product not in cart.');
    }
    redirectBack('Product was not in your cart.', 'error');
}

// ---------------------------------------------------------------------------
// Validate quantity for add / update
// ---------------------------------------------------------------------------
if (!$quantity || $quantity < 1) {
    if (isAjax()) {
        jsonResponse(400, false, 'Quantity must be at least 1.');
    }
    redirectBack('Quantity must be at least 1.', 'error');
}

// ---------------------------------------------------------------------------
// Fetch product from DB (needed to verify stock + grab current price)
// ---------------------------------------------------------------------------
try {
    $foundItem = fetchItem($id, $type);
} catch (\Exception $e) {
    error_log("Cart: DB error fetching $type $id – " . $e->getMessage());
    if (isAjax()) {
        jsonResponse(500, false, 'A server error occurred. Please try again.');
    }
    redirectBack('A server error occurred.', 'error');
}

if (!$foundItem) {
    if (isAjax()) {
        jsonResponse(404, false, 'Item not found.');
    }
    redirectBack('Item not found.', 'error');
}

$availableStock = (int)$foundItem['stock_quantity'];

// ---------------------------------------------------------------------------
// ACTION: add  (default)
// ---------------------------------------------------------------------------
if ($action === 'add') {
    $cartKey = ($type === 'product') ? $id : ($type === 'registration' ? 'REG_0' : strtoupper($type[0]) . "_" . $id);
    $existingQty = isset($_SESSION['cart'][$cartKey])
        ? $_SESSION['cart'][$cartKey]['quantity']
        : 0;

    $newQty = $existingQty + $quantity;

    // Stock ceiling (mostly for products)
    if ($newQty > $availableStock) {
        $msg = "Insufficient stock/availability.";
        if (isAjax()) {
            jsonResponse(409, false, $msg, ['available_stock' => $availableStock]);
        }
        redirectBack($msg, 'error');
    }

    $_SESSION['cart'][$cartKey] = [
        'id'         => $id,
        'product_id' => $id, 
        'name'       => $foundItem['name'],
        'price'      => (float)$foundItem['price'],
        'quantity'   => $newQty,
        'image'      => $foundItem['image'] ?? null,
        'type'       => $type,
        'vehicle_id' => $_REQUEST['vehicle_id'] ?? null,
        'notes'      => $_REQUEST['notes'] ?? 'Added via portal'
    ];

    // 🔔 IMMEDIATE ACTIONS (Since no payment feature is required)
    $pdo = Database::getInstance()->getConnection();
    $customerId = $_SESSION['customer_id'] ?? $_SESSION['user_id'] ?? 0;

    if ($type === 'service' || $type === 'package') {
        // 1. Create Service Request
        $reqStmt = $pdo->prepare("INSERT INTO service_requests (vehicle_id, service_type, complaint_text, priority, status) VALUES (?, ?, ?, 'Medium', 'Pending')");
        $reqStmt->execute([
            $_REQUEST['vehicle_id'] ?? 'N/A', 
            $foundItem['name'], 
            $_REQUEST['notes'] ?? 'Order via Cart'
        ]);
    }

    // 2. Notify Admin
    $admin_q = $pdo->query("SELECT id FROM admins LIMIT 1");
    if ($admin_data = $admin_q->fetch()) {
        $admin_id = $admin_data['id'];
        $itemTypeLabel = ucfirst($type);
        $msg = "New $itemTypeLabel Request: " . $foundItem['name'] . " by Customer #$customerId";
        $pdo->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'admin', ?)")->execute([$admin_id, $msg]);
    }

    if (isAjax()) {
        jsonResponse(200, true, htmlspecialchars($foundItem['name']) . ' added and Admin notified.', cartSummary());
    }
    redirectBack(htmlspecialchars($foundItem['name']) . ' added and Admin notified.');
}

// ---------------------------------------------------------------------------
// ACTION: update  (set absolute quantity)
// ---------------------------------------------------------------------------
if ($action === 'update') {
    $cartKey = ($type === 'product') ? $id : ($type === 'registration' ? 'REG_0' : strtoupper($type[0]) . "_" . $id);
    if (!isset($_SESSION['cart'][$cartKey])) {
        if (isAjax()) {
            jsonResponse(404, false, 'Item not in cart. Add it first.');
        }
        redirectBack('Item is not in your cart.', 'error');
    }

    // Stock ceiling
    if ($quantity > $availableStock) {
        $msg = "Cannot set quantity to $quantity. Insufficient availability.";

        if (isAjax()) {
            jsonResponse(409, false, $msg, ['available_stock' => $availableStock]);
        }
        redirectBack($msg, 'error');
    }

    $_SESSION['cart'][$cartKey]['quantity'] = $quantity;
    // Refresh the price in case it changed since the item was first added
    $_SESSION['cart'][$cartKey]['price'] = (float)$foundItem['price'];

    if (isAjax()) {
        jsonResponse(200, true, 'Cart updated.', cartSummary());
    }
    redirectBack('Cart updated.');
}

// ---------------------------------------------------------------------------
// Fallback: unknown action
// ---------------------------------------------------------------------------
if (isAjax()) {
    jsonResponse(400, false, "Unknown action: $action");
}
redirectBack('Unknown action.', 'error');
