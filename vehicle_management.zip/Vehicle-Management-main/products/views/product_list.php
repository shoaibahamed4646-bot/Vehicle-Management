<?php
/**
 * Customer View: Product Catalog
 * Responsive grid of product cards with a category filter sidebar.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

$pdo = Database::getInstance()->getConnection();

// Fetch all active products
$products = $pdo->query(
    "SELECT product_id AS id, product_name AS name, category, description, unit_price AS price, stock_quantity, NULL AS image
     FROM products
     WHERE (is_active = 1 OR is_active IS NULL)
     ORDER BY product_name ASC"
)->fetchAll();

// Extract unique categories
$categories = [];
foreach ($products as $p) {
    $cat = $p['category'] ?? 'Other';
    if (!in_array($cat, $categories, true)) {
        $categories[] = $cat;
    }
}
sort($categories);

// Cart count for header badge
$cartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}

$flashSuccess = $_SESSION['success_msg'] ?? null;
$flashError   = $_SESSION['error_msg'] ?? null;
unset($_SESSION['success_msg'], $_SESSION['error_msg']);

$currentPage = 'products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Catalog | Vehicle Parts & Accessories</title>
    <meta name="description" content="Browse our complete catalog of vehicle parts, accessories, and maintenance supplies.">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

        :root {
            --bg-main: #0c0e1a;
            --bg-card: #141627;
            --bg-sidebar: #111325;
            --bg-input: #0e1020;
            --text-main: #e8ecf4;
            --text-muted: #7a84a0;
            --accent: #3b82f6;
            --accent-light: #60a5fa;
            --accent-hover: #2563eb;
            --accent-glow: rgba(59, 130, 246, 0.15);
            --accent-glow-strong: rgba(59, 130, 246, 0.25);
            --danger: #ef4444;
            --success: #22c55e;
            --warning: #f59e0b;
            --card-border: rgba(59, 130, 246, 0.08);
            --card-border-hover: rgba(59, 130, 246, 0.25);
            --radius: 14px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        *, *::before, *::after { box-sizing: border-box; }

        body {
            margin: 0; padding: 0;
            background: var(--bg-main);
            color: var(--text-main);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            -webkit-font-smoothing: antialiased;
            min-height: 100vh;
        }

        /* ========== TOP NAV ========== */
        .top-nav {
            background: var(--bg-sidebar);
            border-bottom: 1px solid var(--card-border);
            padding: 16px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky; top: 0; z-index: 50;
            backdrop-filter: blur(12px);
        }
        .nav-brand {
            font-size: 1.3rem; font-weight: 800; letter-spacing: -0.02em;
            color: var(--accent-light);
        }
        .cart-link {
            position: relative;
            color: var(--text-muted);
            text-decoration: none;
            display: flex; align-items: center; gap: 8px;
            font-weight: 600; font-size: 0.95rem;
            transition: var(--transition);
        }
        .cart-link:hover { color: var(--text-main); }
        .cart-link svg { width: 22px; height: 22px; }
        .cart-badge {
            position: absolute; top: -8px; right: -12px;
            background: var(--accent); color: #fff;
            font-size: 0.7rem; font-weight: 700;
            width: 20px; height: 20px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }

        /* ========== LAYOUT ========== */
        .page-layout {
            display: grid;
            grid-template-columns: 260px 1fr;
            max-width: 1400px;
            margin: 0 auto;
            gap: 0;
            min-height: calc(100vh - 60px);
        }

        /* ========== SIDEBAR ========== */
        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--card-border);
            padding: 30px 25px;
            position: sticky; top: 60px;
            height: calc(100vh - 60px);
            overflow-y: auto;
        }
        .sidebar-title {
            font-size: 0.75rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.08em;
            color: var(--text-muted); margin: 0 0 18px;
        }

        /* Search */
        .search-box {
            position: relative; margin-bottom: 25px;
        }
        .search-box input {
            width: 100%;
            background: var(--bg-input);
            border: 1px solid var(--card-border);
            color: var(--text-main);
            padding: 11px 14px 11px 38px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-family: inherit;
            transition: var(--transition);
        }
        .search-box input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-glow);
        }
        .search-box input::placeholder { color: var(--text-muted); }
        .search-box svg {
            position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
            width: 16px; height: 16px; color: var(--text-muted);
        }

        /* Category Filters */
        .filter-list { list-style: none; padding: 0; margin: 0; }
        .filter-item {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 12px; border-radius: 8px;
            cursor: pointer; transition: var(--transition);
            font-size: 0.92rem; color: var(--text-muted);
            margin-bottom: 4px; user-select: none;
        }
        .filter-item:hover { background: var(--accent-glow); color: var(--text-main); }
        .filter-item.active {
            background: var(--accent-glow-strong);
            color: var(--accent-light);
            font-weight: 600;
        }
        .filter-item .dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--card-border); flex-shrink: 0;
            transition: var(--transition);
        }
        .filter-item.active .dot { background: var(--accent); box-shadow: 0 0 6px var(--accent); }
        .filter-item .count {
            margin-left: auto; font-size: 0.8rem;
            background: rgba(255,255,255,0.04); padding: 2px 8px;
            border-radius: 10px;
        }

        /* ========== MAIN CONTENT ========== */
        .main-content { padding: 30px; }

        .content-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 28px; flex-wrap: wrap; gap: 12px;
        }
        .content-header h1 {
            font-size: 2rem; font-weight: 800; margin: 0;
            letter-spacing: -0.03em;
        }
        .result-count { color: var(--text-muted); font-size: 0.95rem; }

        /* Flash Messages */
        .flash {
            border-radius: 10px; padding: 14px 18px; margin-bottom: 20px;
            font-size: 0.92rem; display: flex; align-items: center; gap: 10px;
        }
        .flash-success { background: rgba(34,197,94,0.08); border: 1px solid rgba(34,197,94,0.25); color: var(--success); }
        .flash-error { background: rgba(239,68,68,0.08); border: 1px solid rgba(239,68,68,0.25); color: var(--danger); }

        /* ========== PRODUCT GRID ========== */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 22px;
        }

        .product-card {
            background: var(--bg-card);
            border: 1px solid var(--card-border);
            border-radius: var(--radius);
            overflow: hidden;
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            position: relative;
        }
        .product-card:hover {
            border-color: var(--card-border-hover);
            transform: translateY(-6px);
            box-shadow: 0 20px 40px -15px rgba(59, 130, 246, 0.15);
        }

        /* Image */
        .card-image {
            width: 100%; height: 200px; object-fit: cover;
            border-bottom: 1px solid var(--card-border);
            background: var(--bg-input);
            display: block;
        }
        .card-image-placeholder {
            width: 100%; height: 200px;
            background: linear-gradient(135deg, var(--bg-input) 0%, var(--bg-sidebar) 100%);
            display: flex; align-items: center; justify-content: center;
            font-size: 3rem;
            border-bottom: 1px solid var(--card-border);
        }

        /* Stock Badge (top-right corner) */
        .stock-badge {
            position: absolute; top: 12px; right: 12px;
            padding: 4px 10px; border-radius: 20px;
            font-size: 0.72rem; font-weight: 700; letter-spacing: 0.03em;
            backdrop-filter: blur(8px);
        }
        .badge-in    { background: rgba(34,197,94,0.2); color: var(--success); border: 1px solid rgba(34,197,94,0.3); }
        .badge-low   { background: rgba(245,158,11,0.2); color: var(--warning); border: 1px solid rgba(245,158,11,0.3); }
        .badge-out   { background: rgba(239,68,68,0.2); color: var(--danger); border: 1px solid rgba(239,68,68,0.3); }

        /* Card Body */
        .card-body {
            padding: 18px 20px; flex: 1;
            display: flex; flex-direction: column;
        }
        .card-category {
            font-size: 0.75rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.06em;
            color: var(--accent); margin-bottom: 6px;
        }
        .card-name {
            font-size: 1.1rem; font-weight: 700; margin: 0 0 8px;
            line-height: 1.3;
        }
        .card-name a {
            color: var(--text-main); text-decoration: none;
            transition: var(--transition);
        }
        .card-name a:hover { color: var(--accent-light); }

        .card-desc {
            font-size: 0.85rem; color: var(--text-muted);
            line-height: 1.5; margin: 0 0 auto;
            display: -webkit-box; -webkit-line-clamp: 2;
            -webkit-box-orient: vertical; overflow: hidden;
            padding-bottom: 15px;
        }

        /* Card Footer */
        .card-footer {
            display: flex; justify-content: space-between; align-items: center;
            padding: 15px 20px;
            border-top: 1px solid var(--card-border);
        }
        .card-price {
            font-size: 1.4rem; font-weight: 800;
            color: var(--text-main);
        }
        .card-price span {
            font-size: 0.85rem; font-weight: 400; color: var(--text-muted);
        }

        .btn-cart {
            background: var(--accent);
            color: #fff; border: none;
            padding: 10px 18px; border-radius: 8px;
            font-weight: 700; font-size: 0.85rem;
            cursor: pointer; transition: var(--transition);
            display: flex; align-items: center; gap: 6px;
        }
        .btn-cart:hover {
            background: var(--accent-hover);
            transform: scale(1.05);
            box-shadow: 0 8px 16px -4px rgba(59, 130, 246, 0.4);
        }
        .btn-cart:disabled {
            opacity: 0.35; cursor: not-allowed;
            transform: none; box-shadow: none;
        }
        .btn-cart svg { width: 16px; height: 16px; }

        /* Cart feedback animation */
        .btn-cart.added {
            background: var(--success);
        }

        /* Empty state */
        .empty-grid {
            grid-column: 1 / -1;
            text-align: center; padding: 60px 20px; color: var(--text-muted);
        }
        .empty-grid .icon { font-size: 3rem; margin-bottom: 12px; }

        /* ========== MOBILE ========== */
        .sidebar-toggle {
            display: none;
            background: var(--bg-sidebar); border: 1px solid var(--card-border);
            color: var(--text-main); padding: 12px 18px; border-radius: 8px;
            font-weight: 600; font-size: 0.9rem; cursor: pointer;
            width: 100%;
        }

        @media (max-width: 900px) {
            .page-layout { grid-template-columns: 1fr; }
            .sidebar {
                position: fixed; left: -300px; top: 60px;
                width: 280px; height: calc(100vh - 60px);
                z-index: 40; transition: left 0.3s ease;
                border-right: 1px solid var(--card-border);
            }
            .sidebar.open { left: 0; }
            .sidebar-overlay {
                display: none; position: fixed; inset: 0;
                background: rgba(0,0,0,0.5); z-index: 39;
            }
            .sidebar-overlay.show { display: block; }
            .sidebar-toggle { display: block; margin-bottom: 20px; }
            .product-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); }
        }
    </style>
</head>
<body>

    <?php require_once __DIR__ . '/../../includes/header.php'; ?>

    <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

    <div class="page-layout">

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <!-- Search -->
            <div class="search-box">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
                <input type="text" id="searchInput" placeholder="Search products..." oninput="filterProducts()">
            </div>

            <div class="sidebar-title">Categories</div>
            <ul class="filter-list" id="filterList">
                <li class="filter-item active" data-category="all" onclick="filterByCategory(this, 'all')">
                    <span class="dot"></span>
                    All Products
                    <span class="count"><?= count($products) ?></span>
                </li>
                <?php foreach ($categories as $cat):
                    $catCount = count(array_filter($products, fn($p) => ($p['category'] ?? 'Other') === $cat));
                ?>
                <li class="filter-item" data-category="<?= htmlspecialchars($cat) ?>" onclick="filterByCategory(this, '<?= htmlspecialchars(addslashes($cat)) ?>')">
                    <span class="dot"></span>
                    <?= htmlspecialchars($cat) ?>
                    <span class="count"><?= $catCount ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">

            <!-- Mobile Toggle -->
            <button class="sidebar-toggle" onclick="toggleSidebar()">☰ Filter by Category</button>

            <?php if ($flashSuccess): ?>
                <div class="flash flash-success">✓ <?= htmlspecialchars($flashSuccess) ?></div>
            <?php endif; ?>
            <?php if ($flashError): ?>
                <div class="flash flash-error">✗ <?= htmlspecialchars($flashError) ?></div>
            <?php endif; ?>

            <div class="content-header">
                <h1>Product Catalog</h1>
                <span class="result-count" id="resultCount"><?= count($products) ?> product(s)</span>
            </div>

            <div class="product-grid" id="productGrid">
                <?php if (empty($products)): ?>
                    <div class="empty-grid">
                        <div class="icon">📦</div>
                        <p>No products available at the moment.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($products as $p):
                        $stock = (int) $p['stock_quantity'];
                        if ($stock === 0) {
                            $badgeClass = 'badge-out'; $badgeText = 'OUT OF STOCK';
                        } elseif ($stock <= 5) {
                            $badgeClass = 'badge-low'; $badgeText = "ONLY $stock LEFT";
                        } else {
                            $badgeClass = 'badge-in'; $badgeText = 'IN STOCK';
                        }
                    ?>
                    <div class="product-card"
                         data-category="<?= htmlspecialchars($p['category'] ?? 'Other') ?>"
                         data-name="<?= htmlspecialchars(strtolower($p['name'])) ?>">

                        <!-- Stock Badge -->
                        <span class="stock-badge <?= $badgeClass ?>"><?= $badgeText ?></span>

                        <!-- Image -->
                        <?php if (!empty($p['image'])): ?>
                            <img class="card-image" src="/<?= htmlspecialchars($p['image']) ?>"
                                 alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="card-image-placeholder">🔧</div>
                        <?php endif; ?>

                        <div class="card-body">
                            <div class="card-category"><?= htmlspecialchars($p['category'] ?? 'Other') ?></div>
                            <h3 class="card-name">
                                <a href="product_detail.php?id=<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></a>
                            </h3>
                            <?php if (!empty($p['description'])): ?>
                                <p class="card-desc"><?= htmlspecialchars($p['description']) ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="card-footer">
                            <div class="card-price">
                                $<?= number_format($p['price'], 2) ?>
                                <span>USD</span>
                            </div>
                            <button class="btn-cart" id="cartBtn-<?= $p['id'] ?>"
                                    onclick="addToCart(<?= $p['id'] ?>, this)"
                                    <?= $stock === 0 ? 'disabled' : '' ?>>
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                                </svg>
                                <?= $stock === 0 ? 'Sold Out' : 'Add' ?>
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </main>
    </div>

    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>

    <script>
        // ============================================================
        // Category Filter
        // ============================================================
        let activeCategory = 'all';

        function filterByCategory(el, category) {
            activeCategory = category;

            // Update active class
            document.querySelectorAll('.filter-item').forEach(li => li.classList.remove('active'));
            el.classList.add('active');

            applyFilters();
            closeSidebar();
        }

        // ============================================================
        // Search Filter
        // ============================================================
        function filterProducts() {
            applyFilters();
        }

        function applyFilters() {
            const query = document.getElementById('searchInput').value.toLowerCase().trim();
            const cards = document.querySelectorAll('.product-card');
            let visible = 0;

            cards.forEach(card => {
                const cat  = card.dataset.category;
                const name = card.dataset.name.toLowerCase();

                const matchCat  = (activeCategory === 'all' || cat === activeCategory);
                const matchSearch = (!query || name.includes(query));

                if (matchCat && matchSearch) {
                    card.style.display = '';
                    visible++;
                } else {
                    card.style.display = 'none';
                }
            });

            document.getElementById('resultCount').textContent = visible + ' product(s)';
        }

        // ============================================================
        // Add to Cart (AJAX)
        // ============================================================
        function addToCart(productId, btn) {
            btn.disabled = true;
            const origHTML = btn.innerHTML;
            btn.innerHTML = '...';

            const body = new URLSearchParams();
            body.append('product_id', productId);
            body.append('quantity', 1);
            body.append('action', 'add');

            fetch('../handlers/add_to_cart.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: body.toString(),
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    btn.classList.add('added');
                    btn.innerHTML = '✓ Added';
                    updateCartBadge(data.total_items);
                    setTimeout(() => {
                        btn.classList.remove('added');
                        btn.innerHTML = origHTML;
                        btn.disabled = false;
                    }, 1500);
                } else {
                    btn.innerHTML = data.message || 'Error';
                    setTimeout(() => { btn.innerHTML = origHTML; btn.disabled = false; }, 2000);
                }
            })
            .catch(() => {
                btn.innerHTML = '✗ Error';
                setTimeout(() => { btn.innerHTML = origHTML; btn.disabled = false; }, 2000);
            });
        }

        function updateCartBadge(count) {
            let badge = document.querySelector('.cart-count');
            if (!badge) {
                const cartLink = document.querySelector('.nav-cart');
                badge = document.createElement('span');
                badge.className = 'cart-count';
                cartLink.appendChild(badge);
            }
            badge.textContent = count;
        }

        // ============================================================
        // Mobile Sidebar
        // ============================================================
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('show');
        }
        function closeSidebar() {
            document.getElementById('sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('show');
        }
    </script>
</body>
</html>
