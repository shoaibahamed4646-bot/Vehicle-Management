<?php
/**
 * Customer View: Checkout
 * Order summary, customer info (pre-filled if logged in), payment method, Place Order.
 */

require_once __DIR__ . '/../../includes/auth.php';

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    $_SESSION['error_msg'] = 'Your cart is empty.';
    header('Location: cart.php');
    exit;
}

// Calculate totals
$orderTotal = 0.0;
$itemCount  = 0;
foreach ($cart as $item) {
    $orderTotal += $item['price'] * $item['quantity'];
    $itemCount  += $item['quantity'];
}

// Pre-fill customer info if logged in
$user = isLoggedIn() ? getCurrentUser() : null;

$flashError = $_SESSION['error_msg'] ?? null;
unset($_SESSION['error_msg']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Vehicle Parts</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg:#0c0e1a;--bg-card:#141627;--bg-input:#0e1020;--bg-nav:#111325;
            --text:#e8ecf4;--muted:#7a84a0;
            --accent:#3b82f6;--accent-light:#60a5fa;--accent-hover:#2563eb;
            --glow:rgba(59,130,246,.15);--glow-s:rgba(59,130,246,.25);
            --danger:#ef4444;--success:#22c55e;
            --border:rgba(59,130,246,.08);--border-h:rgba(59,130,246,.25);
            --r:14px;--t:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        body{margin:0;background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased;min-height:100vh;}

        .nav{background:var(--bg-nav);border-bottom:1px solid var(--border);padding:16px 30px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:50;}
        .nav-brand{font-size:1.3rem;font-weight:800;color:var(--accent-light);}
        .nav a{color:var(--muted);text-decoration:none;font-weight:600;font-size:.9rem;transition:var(--t);}
        .nav a:hover{color:var(--text);}

        .container{max-width:1100px;margin:0 auto;padding:50px 24px;}
        .back{display:inline-flex;align-items:center;gap:6px;color:var(--accent);text-decoration:none;font-weight:600;font-size:.95rem;margin-bottom:30px;transition:var(--t);}
        .back:hover{color:var(--text);transform:translateX(-4px);}
        .back svg{width:18px;height:18px;}
        h1{font-size:2.2rem;font-weight:800;margin:0 0 8px;letter-spacing:-.03em;}
        .subtitle{color:var(--muted);margin:0 0 35px;font-size:1rem;}

        .flash{border-radius:10px;padding:14px 18px;margin-bottom:20px;font-size:.9rem;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);color:var(--danger);}

        /* 60/40 Layout */
        .checkout-grid{display:grid;grid-template-columns:1fr 400px;gap:40px;align-items:start;}

        /* === LEFT: Form === */
        .form-section{display:flex;flex-direction:column;gap:30px;}
        .section-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--r);padding:30px;}
        .section-title{font-size:1.1rem;font-weight:700;margin:0 0 22px;display:flex;align-items:center;gap:10px;}
        .section-title .num{width:28px;height:28px;border-radius:50%;background:var(--glow);color:var(--accent-light);font-size:.8rem;font-weight:700;display:flex;align-items:center;justify-content:center;border:1px solid var(--border-h);}

        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px;}
        .form-row.full{grid-template-columns:1fr;}
        .form-group{display:flex;flex-direction:column;gap:7px;}
        .form-group label{font-size:.85rem;font-weight:600;color:#c8cedc;}
        .form-control{
            background:var(--bg-input);border:1px solid var(--border);color:var(--text);
            padding:13px 16px;border-radius:8px;font-size:.95rem;font-family:inherit;transition:var(--t);
        }
        .form-control:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--glow);}
        .form-control::placeholder{color:var(--muted);}
        textarea.form-control{resize:vertical;min-height:80px;}

        /* Payment Methods */
        .pay-options{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
        .pay-option{
            position:relative;display:flex;align-items:center;gap:12px;
            background:var(--bg-input);border:2px solid var(--border);border-radius:10px;
            padding:16px 18px;cursor:pointer;transition:var(--t);
        }
        .pay-option:hover{border-color:var(--border-h);}
        .pay-option input{position:absolute;opacity:0;cursor:pointer;}
        .pay-option.selected{border-color:var(--accent);background:var(--glow);}
        .pay-dot{width:18px;height:18px;border-radius:50%;border:2px solid var(--muted);display:flex;align-items:center;justify-content:center;transition:var(--t);flex-shrink:0;}
        .pay-dot::after{content:'';width:8px;height:8px;border-radius:50%;background:var(--accent);opacity:0;transition:var(--t);}
        .pay-option.selected .pay-dot{border-color:var(--accent);}
        .pay-option.selected .pay-dot::after{opacity:1;}
        .pay-label{font-weight:600;font-size:.92rem;}
        .pay-icon{font-size:1.2rem;}

        /* === RIGHT: Sticky Summary === */
        .summary-card{
            background:var(--bg-card);border:1px solid var(--border);border-radius:var(--r);
            padding:30px;position:sticky;top:80px;
            box-shadow:0 20px 40px -10px rgba(0,0,0,.5);
        }
        .summary-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--accent),transparent);}
        .summary-title{font-size:1.1rem;font-weight:700;margin:0 0 20px;}

        .summary-items{max-height:280px;overflow-y:auto;margin-bottom:20px;padding-right:6px;}
        .summary-items::-webkit-scrollbar{width:4px;}
        .summary-items::-webkit-scrollbar-thumb{background:var(--border-h);border-radius:2px;}

        .sum-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);}
        .sum-row:last-child{border-bottom:none;}
        .sum-name{font-size:.9rem;display:flex;align-items:center;gap:8px;min-width:0;}
        .sum-name span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .sum-qty{font-size:.75rem;color:var(--muted);white-space:nowrap;}
        .sum-price{font-weight:600;white-space:nowrap;margin-left:10px;}

        .totals{border-top:1px solid var(--border);padding-top:16px;}
        .total-line{display:flex;justify-content:space-between;padding:6px 0;font-size:.92rem;color:var(--muted);}
        .total-line.grand{padding-top:12px;margin-top:8px;border-top:1px solid var(--border);color:var(--text);font-weight:800;font-size:1.4rem;}

        .btn-place{
            width:100%;margin-top:25px;padding:18px;border:none;border-radius:10px;
            background:var(--accent);color:#fff;font-size:1.1rem;font-weight:700;
            cursor:pointer;transition:var(--t);display:flex;align-items:center;justify-content:center;gap:10px;
        }
        .btn-place:hover{background:var(--accent-hover);transform:scale(1.02);box-shadow:0 12px 24px -6px rgba(59,130,246,.4);}
        .btn-place svg{width:20px;height:20px;}

        .secure-note{margin-top:14px;text-align:center;font-size:.8rem;color:var(--muted);display:flex;align-items:center;justify-content:center;gap:6px;}
        .secure-note svg{width:14px;height:14px;}

        @media(max-width:900px){
            .checkout-grid{grid-template-columns:1fr;}
            .summary-card{position:relative;top:0;order:-1;}
            .form-row{grid-template-columns:1fr;}
            .pay-options{grid-template-columns:1fr;}
        }
    </style>
</head>
<body>

<nav class="nav">
    <div class="nav-brand">Vehicle Parts</div>
    <a href="cart.php">← Back to Cart</a>
</nav>

<div class="container">
    <a href="cart.php" class="back">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Back to Cart
    </a>

    <?php if ($flashError): ?>
        <div class="flash">✗ <?= htmlspecialchars($flashError) ?></div>
    <?php endif; ?>

    <h1>Checkout</h1>
    <p class="subtitle"><?= $itemCount ?> item(s) in your order</p>

    <form action="../handlers/process_order.php" method="POST" id="checkoutForm">
        <div class="checkout-grid">

            <!-- LEFT: Customer & Payment Forms -->
            <div class="form-section">

                <!-- Step 1: Customer Info -->
                <div class="section-card">
                    <h2 class="section-title"><span class="num">1</span> Customer Information</h2>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" id="full_name" name="full_name" class="form-control"
                                   value="<?= htmlspecialchars($user['username'] ?? '') ?>"
                                   placeholder="John Doe" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" class="form-control"
                                   value="<?= htmlspecialchars($user['email'] ?? '') ?>"
                                   placeholder="john@example.com" required>
                        </div>
                    </div>
                    <div class="form-row full">
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control"
                                   placeholder="+1 (555) 000-0000">
                        </div>
                    </div>
                </div>

                <!-- Step 2: Payment Method -->
                <div class="section-card">
                    <h2 class="section-title"><span class="num">2</span> Payment Method</h2>
                    <div class="pay-options" id="payOptions">

                        <label class="pay-option selected" onclick="selectPay(this)">
                            <input type="radio" name="payment_method" value="credit_card" checked>
                            <span class="pay-dot"></span>
                            <span class="pay-icon">💳</span>
                            <span class="pay-label">Credit Card</span>
                        </label>

                        <label class="pay-option" onclick="selectPay(this)">
                            <input type="radio" name="payment_method" value="cash">
                            <span class="pay-dot"></span>
                            <span class="pay-icon">💵</span>
                            <span class="pay-label">Cash on Pickup</span>
                        </label>

                        <label class="pay-option" onclick="selectPay(this)">
                            <input type="radio" name="payment_method" value="bank_transfer">
                            <span class="pay-dot"></span>
                            <span class="pay-icon">🏦</span>
                            <span class="pay-label">Bank Transfer</span>
                        </label>

                        <label class="pay-option" onclick="selectPay(this)">
                            <input type="radio" name="payment_method" value="paypal">
                            <span class="pay-dot"></span>
                            <span class="pay-icon">🅿️</span>
                            <span class="pay-label">PayPal</span>
                        </label>

                    </div>
                </div>

                <!-- Step 3: Notes -->
                <div class="section-card">
                    <h2 class="section-title"><span class="num">3</span> Order Notes <span style="font-weight:400;color:var(--muted);font-size:.8rem;">(optional)</span></h2>
                    <div class="form-row full">
                        <div class="form-group">
                            <textarea name="notes" class="form-control" placeholder="Special instructions, delivery preferences..."></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT: Order Summary -->
            <div class="summary-card">
                <h3 class="summary-title">Order Summary</h3>

                <div class="summary-items">
                    <?php foreach ($cart as $item): ?>
                    <div class="sum-row">
                        <div class="sum-name">
                            <span><?= htmlspecialchars($item['name']) ?></span>
                            <span class="sum-qty">×<?= $item['quantity'] ?></span>
                        </div>
                        <span class="sum-price">$<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="totals">
                    <div class="total-line">
                        <span>Subtotal</span>
                        <span>$<?= number_format($orderTotal, 2) ?></span>
                    </div>
                    <div class="total-line">
                        <span>Tax</span>
                        <span>$0.00</span>
                    </div>
                    <div class="total-line grand">
                        <span>Total</span>
                        <span>$<?= number_format($orderTotal, 2) ?></span>
                    </div>
                </div>

                <button type="submit" class="btn-place" id="placeBtn">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    Place Order
                </button>

                <div class="secure-note">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                    Secure checkout — your data is protected
                </div>
            </div>

        </div>
    </form>
</div>

<script>
    function selectPay(el) {
        document.querySelectorAll('.pay-option').forEach(o => o.classList.remove('selected'));
        el.classList.add('selected');
        el.querySelector('input').checked = true;
    }

    // Prevent double-submit
    document.getElementById('checkoutForm').addEventListener('submit', function() {
        const btn = document.getElementById('placeBtn');
        btn.disabled = true;
        btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin .8s linear infinite"><path d="M12 2v4m0 12v4m-7-7H2m20 0h-4m-1.5-8.5L14 8m-4 8l-2.5 2.5m11-3L16 14M8 10l-2.5-2.5"/></svg> Processing...';
    });
</script>
<style>@keyframes spin{to{transform:rotate(360deg);}}</style>
</body>
</html>
