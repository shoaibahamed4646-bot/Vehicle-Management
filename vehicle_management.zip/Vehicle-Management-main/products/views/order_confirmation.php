<?php
/**
 * Order Confirmation View
 * Displays success message and details after a checkout.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/auth.php';

requireLogin();

$orderId = filter_input(INPUT_GET, 'order_id', FILTER_VALIDATE_INT);
if (!$orderId) {
    header('Location: product_list.php');
    exit;
}

try {
    $pdo = Database::getInstance()->getConnection();
    
    // Fetch invoice details (which acts as the order in this schema)
    $stmt = $pdo->prepare("SELECT invoice_id AS id, total_amount, payment_status FROM invoices WHERE invoice_id = ?");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    
    if (!$order) {
        die("Order not found.");
    }
    
    $invoiceId = $order['id'];

} catch (\Exception $e) {
    die("Error retrieving order details.");
}

$currentPage = 'products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation | VehicleMS</title>
    <style>
        :root {
            --bg-main: #0c0e1a;
            --bg-card: #141627;
            --text-main: #e8ecf4;
            --text-muted: #7a84a0;
            --accent: #3b82f6;
            --success: #22c55e;
        }
        body { margin: 0; padding: 0; background: var(--bg-main); color: var(--text-main); font-family: 'Inter', sans-serif; }
        .container { max-width: 600px; margin: 100px auto; text-align: center; background: var(--bg-card); padding: 50px; border-radius: 16px; border: 1px solid rgba(59,130,246,0.1); }
        .icon { font-size: 60px; margin-bottom: 20px; color: var(--success); }
        h1 { margin-top: 0; font-size: 2.5rem; }
        p { color: var(--text-muted); font-size: 1.1rem; line-height: 1.6; }
        .order-number { font-size: 1.5rem; font-weight: bold; margin: 20px 0; color: #fff; }
        .actions { display: flex; gap: 15px; justify-content: center; margin-top: 40px; }
        .btn { padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: 0.2s; }
        .btn-primary { background: var(--accent); color: white; }
        .btn-secondary { background: rgba(255,255,255,0.1); color: white; }
        .btn:hover { filter: brightness(1.1); }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../includes/header.php'; ?>

    <div class="container">
        <div class="icon">✅</div>
        <h1>Order Confirmed!</h1>
        <p>Thank you for your purchase. Your order has been received and is currently being processed.</p>
        
        <div class="order-number">
            Order #<?= htmlspecialchars(str_pad($order['id'], 6, '0', STR_PAD_LEFT)) ?>
        </div>
        
        <p>Total Amount: $<?= number_format($order['total_amount'], 2) ?></p>

        <div class="actions">
            <a href="product_list.php" class="btn btn-secondary">Continue Shopping</a>
            <a href="../../payments/views/invoice.php?invoice_id=<?= $invoiceId ?>" class="btn btn-primary">View Invoice</a>
        </div>
    </div>

    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
