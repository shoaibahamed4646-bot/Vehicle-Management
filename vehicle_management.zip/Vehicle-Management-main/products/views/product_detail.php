<?php
/**
 * Customer View: Single Product Detail
 * Large image, full description, quantity selector, AJAX add-to-cart.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$productId) { header('Location: product_list.php'); exit; }

$pdo  = Database::getInstance()->getConnection();
$stmt = $pdo->prepare(
    "SELECT product_id AS id, product_name AS name, category, description, unit_price AS price, stock_quantity, NULL AS image
     FROM products WHERE product_id = :id LIMIT 1"
);
$stmt->execute([':id' => $productId]);
$product = $stmt->fetch();

if (!$product) {
    die("<div style='color:#fff;background:#0c0e1a;padding:60px;text-align:center;font-family:sans-serif;'>
         <h2>Product not found.</h2><a href='product_list.php' style='color:#3b82f6;'>Back to catalog</a></div>");
}

$stock = (int) $product['stock_quantity'];
if ($stock === 0)      { $badgeCls = 'badge-out'; $badgeTxt = 'OUT OF STOCK'; }
elseif ($stock <= 5)   { $badgeCls = 'badge-low'; $badgeTxt = "ONLY $stock LEFT"; }
else                   { $badgeCls = 'badge-in';  $badgeTxt = 'IN STOCK'; }

$cartCount = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) { $cartCount += $item['quantity']; }
}
$currentPage = 'products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> | Vehicle Parts</title>
    <meta name="description" content="<?= htmlspecialchars(mb_substr($product['description'] ?? $product['name'], 0, 155)) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#0c0e1a;--bg-card:#141627;--bg-input:#0e1020;--bg-sidebar:#111325;
            --text:#e8ecf4;--muted:#7a84a0;
            --accent:#3b82f6;--accent-light:#60a5fa;--accent-hover:#2563eb;
            --glow:rgba(59,130,246,.15);
            --danger:#ef4444;--success:#22c55e;--warning:#f59e0b;
            --border:rgba(59,130,246,.08);--border-h:rgba(59,130,246,.25);
            --r:14px;--t:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        body{margin:0;background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased;min-height:100vh;}

        /* Nav */
        .nav{background:var(--bg-sidebar);border-bottom:1px solid var(--border);padding:16px 30px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:50;backdrop-filter:blur(12px);}
        .nav-brand{font-size:1.3rem;font-weight:800;color:var(--accent-light);letter-spacing:-.02em;}
        .nav-links{display:flex;gap:20px;align-items:center;}
        .nav-links a{color:var(--muted);text-decoration:none;font-weight:600;font-size:.9rem;transition:var(--t);}
        .nav-links a:hover{color:var(--text);}
        .cart-link{position:relative;display:flex;align-items:center;gap:6px;}
        .cart-link svg{width:20px;height:20px;}
        .cart-badge{position:absolute;top:-8px;right:-12px;background:var(--accent);color:#fff;font-size:.65rem;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

        /* Layout */
        .container{max-width:1200px;margin:0 auto;padding:50px 24px;}
        .back{display:inline-flex;align-items:center;gap:6px;color:var(--accent);text-decoration:none;font-weight:600;font-size:.95rem;margin-bottom:30px;transition:var(--t);}
        .back:hover{color:var(--text);transform:translateX(-4px);}
        .back svg{width:18px;height:18px;}

        .detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:50px;align-items:start;}

        /* Image */
        .image-pane{position:relative;border-radius:var(--r);overflow:hidden;border:1px solid var(--border);background:var(--bg-card);}
        .image-pane img{width:100%;display:block;aspect-ratio:1/1;object-fit:cover;}
        .image-placeholder{width:100%;aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;font-size:5rem;background:linear-gradient(135deg,var(--bg-input),var(--bg-sidebar));}

        /* Info */
        .info-pane{display:flex;flex-direction:column;gap:0;}
        .badge-row{display:flex;gap:10px;margin-bottom:16px;}
        .stock-badge{padding:5px 14px;border-radius:20px;font-size:.75rem;font-weight:700;letter-spacing:.03em;}
        .badge-in{background:rgba(34,197,94,.15);color:var(--success);border:1px solid rgba(34,197,94,.25);}
        .badge-low{background:rgba(245,158,11,.15);color:var(--warning);border:1px solid rgba(245,158,11,.25);}
        .badge-out{background:rgba(239,68,68,.15);color:var(--danger);border:1px solid rgba(239,68,68,.25);}
        .cat-badge{padding:5px 14px;border-radius:20px;font-size:.75rem;font-weight:600;background:var(--glow);color:var(--accent-light);border:1px solid var(--border-h);}

        .product-name{font-size:2.5rem;font-weight:800;margin:0 0 16px;line-height:1.15;letter-spacing:-.03em;}
        .product-desc{color:var(--muted);font-size:1.05rem;line-height:1.7;margin:0 0 30px;}

        .price-block{margin-bottom:30px;padding:20px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);}
        .price-value{font-size:3rem;font-weight:800;margin:0;}
        .price-value span{font-size:1.1rem;font-weight:400;color:var(--muted);margin-left:8px;}

        /* Quantity Selector */
        .qty-row{display:flex;align-items:center;gap:20px;margin-bottom:25px;}
        .qty-label{font-weight:600;color:#c8cedc;font-size:.95rem;}
        .qty-control{display:flex;align-items:center;border:1px solid var(--border);border-radius:8px;overflow:hidden;}
        .qty-btn{background:var(--bg-card);border:none;color:var(--text);width:44px;height:44px;font-size:1.3rem;cursor:pointer;transition:var(--t);display:flex;align-items:center;justify-content:center;}
        .qty-btn:hover{background:var(--glow);color:var(--accent-light);}
        .qty-btn:disabled{opacity:.3;cursor:not-allowed;}
        .qty-input{width:60px;text-align:center;background:var(--bg-input);border:none;border-left:1px solid var(--border);border-right:1px solid var(--border);color:var(--text);font-size:1.1rem;font-weight:700;font-family:inherit;padding:10px 0;}
        .qty-input:focus{outline:none;}
        .stock-hint{font-size:.85rem;color:var(--muted);}

        /* CTA Button */
        .btn-add{width:100%;padding:18px;border:none;border-radius:10px;background:var(--accent);color:#fff;font-size:1.15rem;font-weight:700;cursor:pointer;transition:var(--t);display:flex;align-items:center;justify-content:center;gap:10px;}
        .btn-add:hover{background:var(--accent-hover);transform:scale(1.02);box-shadow:0 12px 24px -6px rgba(59,130,246,.4);}
        .btn-add:disabled{opacity:.35;cursor:not-allowed;transform:none;box-shadow:none;}
        .btn-add svg{width:20px;height:20px;}
        .btn-add.success{background:var(--success);}

        .feedback{margin-top:12px;text-align:center;font-size:.9rem;font-weight:600;min-height:24px;transition:var(--t);}
        .fb-ok{color:var(--success);} .fb-err{color:var(--danger);}

        @media(max-width:800px){
            .detail-grid{grid-template-columns:1fr;gap:30px;}
            .product-name{font-size:2rem;}
            .price-value{font-size:2.2rem;}
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../includes/header.php'; ?>


<div class="container">
    <a href="product_list.php" class="back">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Back to Catalog
    </a>

    <div class="detail-grid">
        <!-- Left: Image -->
        <div class="image-pane">
            <?php if (!empty($product['image'])): ?>
                <img src="/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
            <?php else: ?>
                <div class="image-placeholder">🔧</div>
            <?php endif; ?>
        </div>

        <!-- Right: Info -->
        <div class="info-pane">
            <div class="badge-row">
                <span class="stock-badge <?= $badgeCls ?>"><?= $badgeTxt ?></span>
                <?php if (!empty($product['category'])): ?>
                    <span class="cat-badge"><?= htmlspecialchars($product['category']) ?></span>
                <?php endif; ?>
            </div>

            <h1 class="product-name"><?= htmlspecialchars($product['name']) ?></h1>

            <?php if (!empty($product['description'])): ?>
                <p class="product-desc"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
            <?php endif; ?>

            <div class="price-block">
                <div class="price-value">$<?= number_format($product['price'], 2) ?> <span>USD</span></div>
            </div>

            <!-- Quantity Selector -->
            <div class="qty-row">
                <span class="qty-label">Quantity</span>
                <div class="qty-control">
                    <button type="button" class="qty-btn" id="qtyMinus" onclick="changeQty(-1)" <?= $stock === 0 ? 'disabled' : '' ?>>−</button>
                    <input type="number" class="qty-input" id="qtyInput" value="1" min="1" max="<?= $stock ?>" <?= $stock === 0 ? 'disabled' : '' ?> onchange="clampQty()">
                    <button type="button" class="qty-btn" id="qtyPlus" onclick="changeQty(1)" <?= $stock === 0 ? 'disabled' : '' ?>>+</button>
                </div>
                <span class="stock-hint"><?= $stock ?> available</span>
            </div>

            <!-- Add to Cart -->
            <button class="btn-add" id="addBtn" onclick="addToCart()" <?= $stock === 0 ? 'disabled' : '' ?>>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"/></svg>
                <?= $stock === 0 ? 'Sold Out' : 'Add to Cart' ?>
            </button>
            <div class="feedback" id="feedback"></div>
        </div>
    </div>
</div>

<script>
    const maxStock = <?= $stock ?>;
    const productId = <?= $productId ?>;
    const qtyInput = document.getElementById('qtyInput');

    function changeQty(delta) {
        let v = parseInt(qtyInput.value, 10) + delta;
        if (v < 1) v = 1;
        if (v > maxStock) v = maxStock;
        qtyInput.value = v;
        updateBtns();
    }

    function clampQty() {
        let v = parseInt(qtyInput.value, 10);
        if (isNaN(v) || v < 1) v = 1;
        if (v > maxStock) v = maxStock;
        qtyInput.value = v;
        updateBtns();
    }

    function updateBtns() {
        const v = parseInt(qtyInput.value, 10);
        document.getElementById('qtyMinus').disabled = (v <= 1);
        document.getElementById('qtyPlus').disabled  = (v >= maxStock);
    }

    function addToCart() {
        const btn = document.getElementById('addBtn');
        const fb  = document.getElementById('feedback');
        const qty = parseInt(qtyInput.value, 10);
        btn.disabled = true;
        fb.textContent = '';

        const body = new URLSearchParams();
        body.append('product_id', productId);
        body.append('quantity', qty);
        body.append('action', 'add');

        fetch('../handlers/add_to_cart.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                btn.classList.add('success');
                btn.innerHTML = '✓ Added to Cart';
                fb.className = 'feedback fb-ok';
                fb.textContent = data.message;
                updateCartBadge(data.total_items);
                setTimeout(() => {
                    btn.classList.remove('success');
                    btn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"/></svg> Add to Cart';
                    btn.disabled = false;
                }, 2000);
            } else {
                fb.className = 'feedback fb-err';
                fb.textContent = data.message;
                btn.disabled = false;
            }
        })
        .catch(() => {
            fb.className = 'feedback fb-err';
            fb.textContent = 'Network error. Try again.';
            btn.disabled = false;
        });
    }

    function updateCartBadge(count) {
        let badge = document.querySelector('.cart-count');
        if (!badge) {
            const cartLink = document.querySelector('.nav-cart');
            badge = document.createElement('span');
            badge.className = 'cart-count';
            cartLink.appendChild(badge);
        }
        badge.textContent = count;
    }

    updateBtns();
</script>
    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
