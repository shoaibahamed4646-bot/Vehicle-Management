<?php
/**
 * Admin Handler: Add Product
 *
 * Dual-purpose endpoint:
 *   GET  → renders the admin form (HTML)
 *   POST → validates inputs, handles image upload, inserts product into DB
 *
 * Required fields (POST, multipart/form-data):
 *   name           — string
 *   category       — string
 *   price          — float  (≥ 0)
 *   stock_quantity — int    (≥ 0)
 *   image          — file   (optional, jpeg/png/webp, max 2 MB)
 *   description    — string (optional)
 */

require_once __DIR__ . '/../../includes/auth.php';

// ---------------------------------------------------------------------------
// Authorization — admin only
// ---------------------------------------------------------------------------
requireRole(ROLE_ADMIN);

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
$uploadDir      = __DIR__ . '/../../uploads/products/';
$maxFileSize    = 2 * 1024 * 1024; // 2 MB
$allowedMimes   = ['image/jpeg', 'image/png', 'image/webp'];
$allowedExts    = ['jpg', 'jpeg', 'png', 'webp'];

// Ensure the upload directory exists
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// ---------------------------------------------------------------------------
// GET → Render add-product form
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch categories for the dropdown (if a categories table exists)
    $categories = [];
    try {
        $pdo = Database::getInstance()->getConnection();
        $catStmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category ASC");
        $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (\Exception $e) {
        // Silently fail — user can still type a category manually
    }

    // Pull flash data for re-display after validation failure
    $errors  = $_SESSION['form_errors'] ?? [];
    $old     = $_SESSION['form_old'] ?? [];
    unset($_SESSION['form_errors'], $_SESSION['form_old']);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Add Product | Admin Panel</title>
        <style>
            :root {
                --bg-main: #13141f;
                --bg-card: #1f2133;
                --bg-input: #151623;
                --text-main: #ffffff;
                --text-muted: #8b95a5;
                --accent: #3b82f6;
                --accent-hover: #2563eb;
                --danger: #ef4444;
                --success: #22c55e;
                --card-border: rgba(255,255,255,0.08);
                --transition: all 0.3s cubic-bezier(0.25,0.8,0.25,1);
            }
            body {
                margin: 0; padding: 0;
                background: var(--bg-main);
                color: var(--text-main);
                font-family: -apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, sans-serif;
                -webkit-font-smoothing: antialiased;
                min-height: 100vh;
                display: flex; justify-content: center; align-items: flex-start;
                padding: 60px 20px;
            }
            .form-card {
                background: var(--bg-card);
                border: 1px solid var(--card-border);
                border-radius: 16px;
                padding: 40px;
                width: 100%; max-width: 640px;
                box-shadow: 0 20px 40px -10px rgba(0,0,0,0.5);
            }
            .form-card h1 {
                margin: 0 0 30px; font-size: 2rem; font-weight: 800; letter-spacing: -0.02em;
            }
            .error-box {
                background: rgba(239,68,68,0.1);
                border: 1px solid var(--danger);
                border-radius: 8px;
                padding: 15px 20px;
                margin-bottom: 25px;
                font-size: 0.95rem;
            }
            .error-box ul { margin: 5px 0 0 20px; padding: 0; }
            .error-box li { margin-bottom: 4px; }
            .form-group { margin-bottom: 25px; }
            .form-group label {
                display: block; font-weight: 600; margin-bottom: 8px; color: #e2e8f0;
            }
            .form-control {
                width: 100%;
                background: var(--bg-input);
                border: 1px solid var(--card-border);
                color: var(--text-main);
                padding: 14px 16px;
                border-radius: 8px;
                font-size: 1rem;
                box-sizing: border-box;
                font-family: inherit;
                transition: var(--transition);
            }
            .form-control:focus {
                outline: none;
                border-color: var(--accent);
                box-shadow: 0 0 0 3px rgba(59,130,246,0.2);
            }
            textarea.form-control { resize: vertical; min-height: 100px; }
            .row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }

            /* File Upload Zone */
            .upload-zone {
                border: 2px dashed var(--card-border);
                border-radius: 12px;
                padding: 30px;
                text-align: center;
                cursor: pointer;
                transition: var(--transition);
                position: relative;
            }
            .upload-zone:hover, .upload-zone.dragover {
                border-color: var(--accent);
                background: rgba(59,130,246,0.05);
            }
            .upload-zone input[type="file"] {
                position: absolute; inset: 0; opacity: 0; cursor: pointer;
            }
            .upload-zone .icon { font-size: 2rem; margin-bottom: 8px; }
            .upload-zone .hint { color: var(--text-muted); font-size: 0.9rem; }
            .upload-zone .filename {
                margin-top: 10px; color: var(--accent); font-weight: 600; display: none;
            }

            .btn-submit {
                width: 100%;
                background: var(--accent);
                color: white;
                border: none;
                padding: 16px;
                font-size: 1.1rem;
                font-weight: 700;
                border-radius: 8px;
                cursor: pointer;
                transition: var(--transition);
                margin-top: 10px;
            }
            .btn-submit:hover {
                background: var(--accent-hover);
                transform: scale(1.02);
                box-shadow: 0 10px 20px -5px rgba(59,130,246,0.4);
            }
            @media (max-width: 600px) { .row-2 { grid-template-columns: 1fr; } }
        </style>
    </head>
    <body>
        <div class="form-card">
            <h1>Add New Product</h1>

            <?php if (!empty($errors)): ?>
                <div class="error-box">
                    <strong>Please fix the following:</strong>
                    <ul>
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="add_product.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Product Name *</label>
                    <input type="text" id="name" name="name" class="form-control"
                           value="<?= htmlspecialchars($old['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label for="category">Category *</label>
                    <input type="text" id="category" name="category" class="form-control"
                           list="category-list"
                           placeholder="e.g. Engine Parts, Tires, Accessories"
                           value="<?= htmlspecialchars($old['category'] ?? '') ?>" required>
                    <datalist id="category-list">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>

                <div class="row-2">
                    <div class="form-group">
                        <label for="price">Price (USD) *</label>
                        <input type="number" id="price" name="price" class="form-control"
                               step="0.01" min="0"
                               value="<?= htmlspecialchars($old['price'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="stock_quantity">Stock Quantity *</label>
                        <input type="number" id="stock_quantity" name="stock_quantity" class="form-control"
                               step="1" min="0"
                               value="<?= htmlspecialchars($old['stock_quantity'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control"
                              placeholder="Brief product description..."><?= htmlspecialchars($old['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Product Image</label>
                    <div class="upload-zone" id="uploadZone">
                        <input type="file" name="image" id="imageInput" accept=".jpg,.jpeg,.png,.webp">
                        <div class="icon">📷</div>
                        <div>Drop image here or <strong style="color:var(--accent)">browse</strong></div>
                        <div class="hint">JPG, PNG, or WebP — max 2 MB</div>
                        <div class="filename" id="fileName"></div>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Add Product</button>
            </form>
        </div>

        <script>
            const zone = document.getElementById('uploadZone');
            const input = document.getElementById('imageInput');
            const label = document.getElementById('fileName');

            input.addEventListener('change', () => {
                if (input.files.length) {
                    label.textContent = input.files[0].name;
                    label.style.display = 'block';
                }
            });
            zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
            zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
            zone.addEventListener('drop', e => {
                e.preventDefault();
                zone.classList.remove('dragover');
                input.files = e.dataTransfer.files;
                input.dispatchEvent(new Event('change'));
            });
        </script>
    </body>
    </html>
    <?php
    exit;
}

// ===========================================================================
// POST → Process the form
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// ---------------------------------------------------------------------------
// Input validation
// ---------------------------------------------------------------------------
$name          = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$category      = trim(filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$description   = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$price         = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
$stockQuantity = filter_input(INPUT_POST, 'stock_quantity', FILTER_VALIDATE_INT);

$errors = [];

if ($name === '') {
    $errors[] = 'Product name is required.';
}
if ($category === '') {
    $errors[] = 'Category is required.';
}
if ($price === false || $price < 0) {
    $errors[] = 'A valid non-negative price is required.';
}
if ($stockQuantity === false || $stockQuantity < 0) {
    $errors[] = 'Stock quantity must be zero or a positive integer.';
}

// ---------------------------------------------------------------------------
// Image upload validation
// ---------------------------------------------------------------------------
$imagePath = null;

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Image upload failed (error code: ' . $file['error'] . ').';
    } else {
        // Size check
        if ($file['size'] > $maxFileSize) {
            $errors[] = 'Image exceeds the 2 MB size limit.';
        }

        // MIME check (using finfo for reliability, not the user-supplied type)
        $finfo    = new finfo(FILEINFO_MIME_TYPE);
        $realMime = $finfo->file($file['tmp_name']);

        if (!in_array($realMime, $allowedMimes, true)) {
            $errors[] = 'Invalid image type. Allowed: JPG, PNG, WebP.';
        }

        // Extension check
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExts, true)) {
            $errors[] = 'Invalid file extension.';
        }
    }
}

// ---------------------------------------------------------------------------
// Redirect back with errors if any
// ---------------------------------------------------------------------------
if (!empty($errors)) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_old'] = [
        'name'           => $name,
        'category'       => $category,
        'description'    => $description,
        'price'          => $_POST['price'] ?? '',
        'stock_quantity' => $_POST['stock_quantity'] ?? '',
    ];
    header('Location: add_product.php');
    exit;
}

// ---------------------------------------------------------------------------
// Move uploaded file (if provided)
// ---------------------------------------------------------------------------
if (isset($file) && $file['error'] === UPLOAD_ERR_OK) {
    $ext          = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $safeName     = bin2hex(random_bytes(16)) . '.' . $ext; // collision-proof filename
    $destination  = $uploadDir . $safeName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        $_SESSION['form_errors'] = ['Failed to save the uploaded image. Check folder permissions.'];
        $_SESSION['form_old'] = [
            'name'           => $name,
            'category'       => $category,
            'description'    => $description,
            'price'          => $price,
            'stock_quantity' => $stockQuantity,
        ];
        header('Location: add_product.php');
        exit;
    }

    // Store the relative path (DB-friendly)
    $imagePath = 'uploads/products/' . $safeName;
}

// ---------------------------------------------------------------------------
// Insert into database
// ---------------------------------------------------------------------------
try {
    $pdo = Database::getInstance()->getConnection();

    $stmt = $pdo->prepare("
        INSERT INTO products (name, category, description, price, stock_quantity, image, created_at)
        VALUES (:name, :category, :description, :price, :stock, :image, NOW())
    ");

    $stmt->execute([
        ':name'        => $name,
        ':category'    => $category,
        ':description' => $description,
        ':price'       => $price,
        ':stock'       => $stockQuantity,
        ':image'       => $imagePath,
    ]);

    $productId = $pdo->lastInsertId();

    $_SESSION['success_msg'] = "Product \"$name\" added successfully (ID: $productId).";
    header('Location: add_product.php');
    exit;

} catch (\PDOException $e) {
    error_log("Add Product Error: " . $e->getMessage());

    // Clean up the uploaded file if DB insert failed
    if ($imagePath && file_exists(__DIR__ . '/../../' . $imagePath)) {
        unlink(__DIR__ . '/../../' . $imagePath);
    }

    $_SESSION['form_errors'] = ['A database error occurred. Please try again.'];
    $_SESSION['form_old'] = [
        'name'           => $name,
        'category'       => $category,
        'description'    => $description,
        'price'          => $price,
        'stock_quantity' => $stockQuantity,
    ];
    header('Location: add_product.php');
    exit;
}
