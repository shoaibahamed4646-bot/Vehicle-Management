<?php
/**
 * Admin Handler: Delete Product
 *
 * Dual-purpose endpoint:
 *   GET  ?id=N → fetches product, shows confirmation page with stock warning
 *   POST       → validates confirmation, deletes product, removes image file
 *
 * Behaviour:
 *   - If stock_quantity > 0, a prominent warning is shown but deletion is
 *     still allowed after explicit confirmation.
 *   - Checks for existing order_items referencing the product. If found,
 *     falls back to soft-delete (sets is_active = 0) to preserve order history.
 *   - If no order history exists, performs a hard delete and removes the
 *     associated image file from disk.
 */

require_once __DIR__ . '/../../includes/auth.php';

// ---------------------------------------------------------------------------
// Authorization — admin only
// ---------------------------------------------------------------------------
requireRole(ROLE_ADMIN);

// ---------------------------------------------------------------------------
// Resolve product ID
// ---------------------------------------------------------------------------
$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT)
          ?? filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

if (!$productId || $productId < 1) {
    $_SESSION['error_msg'] = 'Invalid product ID.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ---------------------------------------------------------------------------
// Fetch product
// ---------------------------------------------------------------------------
$pdo = Database::getInstance()->getConnection();

$fetchStmt = $pdo->prepare("SELECT id, name, price, stock_quantity, image, category FROM products WHERE id = :id LIMIT 1");
$fetchStmt->execute([':id' => $productId]);
$product = $fetchStmt->fetch();

if (!$product) {
    $_SESSION['error_msg'] = 'Product not found.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ---------------------------------------------------------------------------
// Check if product has existing order history
// ---------------------------------------------------------------------------
$historyStmt = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = :pid");
$historyStmt->execute([':pid' => $productId]);
$orderCount = (int) $historyStmt->fetchColumn();

$hasOrderHistory = $orderCount > 0;
$hasStock        = ((int) $product['stock_quantity']) > 0;

// ===========================================================================
// POST → Process the deletion
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $confirm = filter_input(INPUT_POST, 'confirm', FILTER_SANITIZE_SPECIAL_CHARS);

    if ($confirm !== 'yes') {
        header('Location: /products/views/product_list.php');
        exit;
    }

    try {
        $pdo->beginTransaction();

        if ($hasOrderHistory) {
            // Soft-delete: preserve the row for order history integrity
            $delStmt = $pdo->prepare("UPDATE products SET is_active = 0 WHERE id = :id");
            $delStmt->execute([':id' => $productId]);
            $actionTaken = 'deactivated';
        } else {
            // Hard delete: no order references, safe to remove entirely
            $delStmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
            $delStmt->execute([':id' => $productId]);
            $actionTaken = 'deleted';

            // Remove associated image file
            if (!empty($product['image'])) {
                $imagePath = __DIR__ . '/../../' . $product['image'];
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }
        }

        $pdo->commit();

        $_SESSION['success_msg'] = "Product \"{$product['name']}\" has been $actionTaken.";
        header('Location: /products/views/product_list.php');
        exit;

    } catch (\PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Delete Product Error (ID $productId): " . $e->getMessage());

        $dbError = 'A database error occurred while deleting the product.';
        // Fall through to render the page with the error
    }
}

// ===========================================================================
// GET (or POST error fallback) → Render confirmation page
// ===========================================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product | Admin Panel</title>
    <style>
        :root {
            --bg-main:#13141f;--bg-card:#1f2133;--bg-input:#151623;
            --text-main:#fff;--text-muted:#8b95a5;
            --accent:#3b82f6;--accent-hover:#2563eb;
            --danger:#ef4444;--danger-hover:#dc2626;
            --warning:#f59e0b;--success:#22c55e;
            --card-border:rgba(255,255,255,0.08);
            --transition:all .3s cubic-bezier(.25,.8,.25,1);
        }
        body {
            margin:0;padding:0;background:var(--bg-main);color:var(--text-main);
            font-family:-apple-system,BlinkMacSystemFont,"Inter","Segoe UI",Roboto,sans-serif;
            -webkit-font-smoothing:antialiased;min-height:100vh;
            display:flex;justify-content:center;align-items:center;padding:40px 20px;
        }
        .confirm-card {
            background:var(--bg-card);border:1px solid var(--card-border);border-radius:16px;
            padding:40px;width:100%;max-width:520px;text-align:center;
            box-shadow:0 20px 40px -10px rgba(0,0,0,.5);position:relative;overflow:hidden;
        }
        /* Top danger stripe */
        .confirm-card::before {
            content:'';position:absolute;top:0;left:0;right:0;height:3px;
            background:linear-gradient(90deg,transparent,var(--danger),transparent);
        }

        .icon-danger {
            width:64px;height:64px;margin:0 auto 20px;
            background:rgba(239,68,68,.1);border-radius:50%;
            display:flex;align-items:center;justify-content:center;
        }
        .icon-danger svg { width:32px;height:32px;color:var(--danger); }

        h1 { font-size:1.8rem;font-weight:800;margin:0 0 10px;letter-spacing:-.02em; }
        .subtitle { color:var(--text-muted);margin:0 0 30px;line-height:1.5; }

        /* Product Info Card */
        .product-info {
            background:var(--bg-input);border:1px solid var(--card-border);border-radius:12px;
            padding:20px;margin-bottom:25px;text-align:left;
        }
        .product-info .p-name {
            font-size:1.3rem;font-weight:700;margin:0 0 12px;
        }
        .meta-row {
            display:flex;justify-content:space-between;align-items:center;
            padding:8px 0;border-top:1px solid var(--card-border);
        }
        .meta-row:first-of-type { border-top:none; }
        .meta-label { color:var(--text-muted);font-size:.9rem; }
        .meta-value { font-weight:600;font-size:.95rem; }

        /* Warnings */
        .alert {
            border-radius:10px;padding:15px 18px;margin-bottom:20px;
            text-align:left;font-size:.92rem;line-height:1.5;
            display:flex;align-items:flex-start;gap:12px;
        }
        .alert svg { width:20px;height:20px;flex-shrink:0;margin-top:2px; }
        .alert-warning {
            background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.3);color:var(--warning);
        }
        .alert-info {
            background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.3);color:var(--accent);
        }
        .alert-error {
            background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);color:var(--danger);
        }

        /* Buttons */
        .btn-row { display:flex;gap:15px;margin-top:10px; }
        .btn-cancel {
            flex:1;padding:15px;border-radius:8px;border:1px solid var(--card-border);
            background:transparent;color:var(--text-muted);font-size:1rem;font-weight:600;
            cursor:pointer;transition:var(--transition);text-decoration:none;text-align:center;
        }
        .btn-cancel:hover { border-color:var(--text-muted);color:var(--text-main); }
        .btn-delete {
            flex:1;background:var(--danger);color:#fff;border:none;padding:15px;
            font-size:1rem;font-weight:700;border-radius:8px;cursor:pointer;
            transition:var(--transition);
        }
        .btn-delete:hover { background:var(--danger-hover);transform:scale(1.02);box-shadow:0 10px 20px -5px rgba(239,68,68,.4); }
        @media(max-width:500px){ .btn-row{flex-direction:column;} }
    </style>
</head>
<body>
    <div class="confirm-card">

        <div class="icon-danger">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6M1 7h22M8 7V4a1 1 0 011-1h6a1 1 0 011 1v3"/>
            </svg>
        </div>

        <h1>Delete Product</h1>
        <p class="subtitle">This action requires confirmation. Please review the details below.</p>

        <?php if (!empty($dbError)): ?>
            <div class="alert alert-error">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span><?= htmlspecialchars($dbError) ?></span>
            </div>
        <?php endif; ?>

        <!-- Product Summary -->
        <div class="product-info">
            <div class="p-name"><?= htmlspecialchars($product['name']) ?></div>
            <div class="meta-row">
                <span class="meta-label">Category</span>
                <span class="meta-value"><?= htmlspecialchars($product['category'] ?? '—') ?></span>
            </div>
            <div class="meta-row">
                <span class="meta-label">Price</span>
                <span class="meta-value">$<?= number_format($product['price'], 2) ?></span>
            </div>
            <div class="meta-row">
                <span class="meta-label">Stock</span>
                <span class="meta-value" style="<?= $hasStock ? 'color:var(--warning)' : '' ?>">
                    <?= (int) $product['stock_quantity'] ?> units
                </span>
            </div>
            <?php if ($hasOrderHistory): ?>
            <div class="meta-row">
                <span class="meta-label">Order History</span>
                <span class="meta-value"><?= $orderCount ?> order(s)</span>
            </div>
            <?php endif; ?>
        </div>

        <!-- Conditional Warnings -->
        <?php if ($hasStock): ?>
            <div class="alert alert-warning">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
                <span>
                    <strong>Stock Warning:</strong> This product still has
                    <strong><?= (int) $product['stock_quantity'] ?></strong> unit(s) in stock.
                    Consider adjusting inventory before deleting.
                </span>
            </div>
        <?php endif; ?>

        <?php if ($hasOrderHistory): ?>
            <div class="alert alert-info">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span>
                    This product appears in <strong><?= $orderCount ?></strong> existing order(s).
                    It will be <strong>deactivated</strong> instead of permanently deleted to preserve order history.
                </span>
            </div>
        <?php else: ?>
            <div class="alert alert-error">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
                <span>
                    <strong>Permanent deletion.</strong> This product has no order history and will be
                    removed from the database entirely. This cannot be undone.
                </span>
            </div>
        <?php endif; ?>

        <!-- Confirmation Form -->
        <form method="POST" action="delete_product.php?id=<?= $productId ?>">
            <input type="hidden" name="product_id" value="<?= $productId ?>">
            <div class="btn-row">
                <a href="/products/views/product_list.php" class="btn-cancel">Cancel</a>
                <button type="submit" name="confirm" value="yes" class="btn-delete">
                    <?= $hasOrderHistory ? 'Yes, Deactivate It' : 'Yes, Delete Permanently' ?>
                </button>
            </div>
        </form>

    </div>
</body>
</html>
