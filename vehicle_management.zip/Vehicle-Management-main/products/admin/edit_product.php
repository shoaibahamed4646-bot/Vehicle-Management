<?php
/**
 * Admin Handler: Edit Product
 *
 * Dual-purpose endpoint:
 *   GET  ?id=N → fetches product from DB and renders a pre-filled edit form
 *   POST       → validates inputs, optionally replaces image, updates the DB row
 *
 * Mirrors the add_product.php conventions (upload config, styling, flash messages).
 */

require_once __DIR__ . '/../../includes/auth.php';

// ---------------------------------------------------------------------------
// Authorization — admin only
// ---------------------------------------------------------------------------
requireRole(ROLE_ADMIN);

// ---------------------------------------------------------------------------
// Configuration (identical to add_product.php)
// ---------------------------------------------------------------------------
$uploadDir    = __DIR__ . '/../../uploads/products/';
$maxFileSize  = 2 * 1024 * 1024; // 2 MB
$allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
$allowedExts  = ['jpg', 'jpeg', 'png', 'webp'];

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// ---------------------------------------------------------------------------
// Resolve product ID (GET or POST)
// ---------------------------------------------------------------------------
$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT)
          ?? filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

if (!$productId || $productId < 1) {
    $_SESSION['error_msg'] = 'Invalid product ID.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ---------------------------------------------------------------------------
// Fetch product from DB
// ---------------------------------------------------------------------------
$pdo = Database::getInstance()->getConnection();

$fetchStmt = $pdo->prepare("SELECT * FROM products WHERE id = :id LIMIT 1");
$fetchStmt->execute([':id' => $productId]);
$product = $fetchStmt->fetch();

if (!$product) {
    $_SESSION['error_msg'] = 'Product not found.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ===========================================================================
// GET → Render pre-filled edit form
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch existing categories for datalist
    $categories = [];
    try {
        $catStmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category ASC");
        $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (\Exception $e) { /* non-critical */ }

    // Flash data takes priority over DB values (so validation errors re-show user input)
    $errors = $_SESSION['form_errors'] ?? [];
    $old    = $_SESSION['form_old'] ?? $product;
    unset($_SESSION['form_errors'], $_SESSION['form_old']);

    $successMsg = $_SESSION['success_msg'] ?? null;
    unset($_SESSION['success_msg']);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Product #<?= $productId ?> | Admin Panel</title>
        <style>
            :root {
                --bg-main:#13141f;--bg-card:#1f2133;--bg-input:#151623;
                --text-main:#fff;--text-muted:#8b95a5;
                --accent:#3b82f6;--accent-hover:#2563eb;
                --danger:#ef4444;--success:#22c55e;
                --card-border:rgba(255,255,255,0.08);
                --transition:all .3s cubic-bezier(.25,.8,.25,1);
            }
            body {
                margin:0;padding:0;background:var(--bg-main);color:var(--text-main);
                font-family:-apple-system,BlinkMacSystemFont,"Inter","Segoe UI",Roboto,sans-serif;
                -webkit-font-smoothing:antialiased;min-height:100vh;
                display:flex;justify-content:center;align-items:flex-start;padding:60px 20px;
            }
            .form-card {
                background:var(--bg-card);border:1px solid var(--card-border);border-radius:16px;
                padding:40px;width:100%;max-width:640px;box-shadow:0 20px 40px -10px rgba(0,0,0,.5);
            }
            .form-card h1 { margin:0 0 30px;font-size:2rem;font-weight:800;letter-spacing:-.02em; }
            .badge-id { font-size:.85rem;color:var(--text-muted);font-weight:400;margin-left:10px; }

            /* Alerts */
            .alert { border-radius:8px;padding:15px 20px;margin-bottom:25px;font-size:.95rem; }
            .alert-error { background:rgba(239,68,68,.1);border:1px solid var(--danger); }
            .alert-success { background:rgba(34,197,94,.1);border:1px solid var(--success);color:var(--success); }
            .alert ul { margin:5px 0 0 20px;padding:0; }
            .alert li { margin-bottom:4px; }

            .form-group { margin-bottom:25px; }
            .form-group label { display:block;font-weight:600;margin-bottom:8px;color:#e2e8f0; }
            .form-control {
                width:100%;background:var(--bg-input);border:1px solid var(--card-border);
                color:var(--text-main);padding:14px 16px;border-radius:8px;font-size:1rem;
                box-sizing:border-box;font-family:inherit;transition:var(--transition);
            }
            .form-control:focus { outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(59,130,246,.2); }
            textarea.form-control { resize:vertical;min-height:100px; }
            .row-2 { display:grid;grid-template-columns:1fr 1fr;gap:20px; }

            /* Current Image Preview */
            .current-image { margin-bottom:15px; }
            .current-image img {
                max-width:200px;border-radius:8px;border:1px solid var(--card-border);
                display:block;margin-bottom:8px;
            }
            .current-image .caption { font-size:.85rem;color:var(--text-muted); }

            /* Upload Zone */
            .upload-zone {
                border:2px dashed var(--card-border);border-radius:12px;padding:25px;
                text-align:center;cursor:pointer;transition:var(--transition);position:relative;
            }
            .upload-zone:hover,.upload-zone.dragover { border-color:var(--accent);background:rgba(59,130,246,.05); }
            .upload-zone input[type="file"] { position:absolute;inset:0;opacity:0;cursor:pointer; }
            .upload-zone .icon { font-size:1.5rem;margin-bottom:6px; }
            .upload-zone .hint { color:var(--text-muted);font-size:.85rem; }
            .upload-zone .filename { margin-top:8px;color:var(--accent);font-weight:600;display:none; }

            .btn-row { display:flex;gap:15px;margin-top:10px; }
            .btn-submit {
                flex:1;background:var(--accent);color:#fff;border:none;padding:16px;
                font-size:1.1rem;font-weight:700;border-radius:8px;cursor:pointer;transition:var(--transition);
            }
            .btn-submit:hover { background:var(--accent-hover);transform:scale(1.02);box-shadow:0 10px 20px -5px rgba(59,130,246,.4); }
            .btn-back {
                padding:16px 25px;border-radius:8px;border:1px solid var(--card-border);
                background:transparent;color:var(--text-muted);font-size:1rem;font-weight:600;
                cursor:pointer;transition:var(--transition);text-decoration:none;text-align:center;
            }
            .btn-back:hover { border-color:var(--text-muted);color:var(--text-main); }
            @media(max-width:600px){ .row-2{grid-template-columns:1fr;} .btn-row{flex-direction:column;} }
        </style>
    </head>
    <body>
        <div class="form-card">
            <h1>Edit Product <span class="badge-id">#<?= $productId ?></span></h1>

            <?php if ($successMsg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMsg) ?></div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <strong>Please fix the following:</strong>
                    <ul>
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="edit_product.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="product_id" value="<?= $productId ?>">

                <div class="form-group">
                    <label for="name">Product Name *</label>
                    <input type="text" id="name" name="name" class="form-control"
                           value="<?= htmlspecialchars($old['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label for="category">Category *</label>
                    <input type="text" id="category" name="category" class="form-control"
                           list="category-list"
                           placeholder="e.g. Engine Parts, Tires, Accessories"
                           value="<?= htmlspecialchars($old['category'] ?? '') ?>" required>
                    <datalist id="category-list">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>

                <div class="row-2">
                    <div class="form-group">
                        <label for="price">Price (USD) *</label>
                        <input type="number" id="price" name="price" class="form-control"
                               step="0.01" min="0"
                               value="<?= htmlspecialchars($old['price'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="stock_quantity">Stock Quantity *</label>
                        <input type="number" id="stock_quantity" name="stock_quantity" class="form-control"
                               step="1" min="0"
                               value="<?= htmlspecialchars($old['stock_quantity'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control"
                              placeholder="Brief product description..."><?= htmlspecialchars($old['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Product Image</label>

                    <?php if (!empty($product['image'])): ?>
                        <div class="current-image">
                            <img src="/<?= htmlspecialchars($product['image']) ?>" alt="Current product image">
                            <span class="caption">Current image — upload a new one below to replace it</span>
                        </div>
                    <?php endif; ?>

                    <div class="upload-zone" id="uploadZone">
                        <input type="file" name="image" id="imageInput" accept=".jpg,.jpeg,.png,.webp">
                        <div class="icon">📷</div>
                        <div>Drop new image or <strong style="color:var(--accent)">browse</strong></div>
                        <div class="hint">JPG, PNG, or WebP — max 2 MB (leave empty to keep current)</div>
                        <div class="filename" id="fileName"></div>
                    </div>
                </div>

                <div class="btn-row">
                    <a href="/products/views/product_list.php" class="btn-back">Cancel</a>
                    <button type="submit" class="btn-submit">Save Changes</button>
                </div>
            </form>
        </div>

        <script>
            const zone  = document.getElementById('uploadZone');
            const input = document.getElementById('imageInput');
            const label = document.getElementById('fileName');

            input.addEventListener('change', () => {
                if (input.files.length) { label.textContent = input.files[0].name; label.style.display = 'block'; }
            });
            zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('dragover'); });
            zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
            zone.addEventListener('drop', e => {
                e.preventDefault(); zone.classList.remove('dragover');
                input.files = e.dataTransfer.files;
                input.dispatchEvent(new Event('change'));
            });
        </script>
    </body>
    </html>
    <?php
    exit;
}

// ===========================================================================
// POST → Process the update
// ===========================================================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// ---------------------------------------------------------------------------
// Input validation
// ---------------------------------------------------------------------------
$name          = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$category      = trim(filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$description   = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');
$price         = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
$stockQuantity = filter_input(INPUT_POST, 'stock_quantity', FILTER_VALIDATE_INT);

$errors = [];

if ($name === '')                             { $errors[] = 'Product name is required.'; }
if ($category === '')                         { $errors[] = 'Category is required.'; }
if ($price === false || $price < 0)           { $errors[] = 'A valid non-negative price is required.'; }
if ($stockQuantity === false || $stockQuantity < 0) { $errors[] = 'Stock quantity must be zero or a positive integer.'; }

// ---------------------------------------------------------------------------
// Image upload validation (only if a new file was provided)
// ---------------------------------------------------------------------------
$newImagePath = null;
$deleteOldImage = false;

if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Image upload failed (error code: ' . $file['error'] . ').';
    } else {
        if ($file['size'] > $maxFileSize) {
            $errors[] = 'Image exceeds the 2 MB size limit.';
        }

        $finfo    = new finfo(FILEINFO_MIME_TYPE);
        $realMime = $finfo->file($file['tmp_name']);
        if (!in_array($realMime, $allowedMimes, true)) {
            $errors[] = 'Invalid image type. Allowed: JPG, PNG, WebP.';
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExts, true)) {
            $errors[] = 'Invalid file extension.';
        }
    }
}

// ---------------------------------------------------------------------------
// Redirect back with errors
// ---------------------------------------------------------------------------
if (!empty($errors)) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_old'] = [
        'name'           => $name,
        'category'       => $category,
        'description'    => $description,
        'price'          => $_POST['price'] ?? '',
        'stock_quantity' => $_POST['stock_quantity'] ?? '',
    ];
    header("Location: edit_product.php?id=$productId");
    exit;
}

// ---------------------------------------------------------------------------
// Move new image (if provided)
// ---------------------------------------------------------------------------
if (isset($file) && $file['error'] === UPLOAD_ERR_OK) {
    $ext         = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $safeName    = bin2hex(random_bytes(16)) . '.' . $ext;
    $destination = $uploadDir . $safeName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        $_SESSION['form_errors'] = ['Failed to save the uploaded image. Check folder permissions.'];
        $_SESSION['form_old'] = [
            'name' => $name, 'category' => $category, 'description' => $description,
            'price' => $price, 'stock_quantity' => $stockQuantity,
        ];
        header("Location: edit_product.php?id=$productId");
        exit;
    }

    $newImagePath   = 'uploads/products/' . $safeName;
    $deleteOldImage = true;
}

// ---------------------------------------------------------------------------
// Update the database
// ---------------------------------------------------------------------------
try {
    // Build UPDATE dynamically so we only touch the image column when needed
    if ($newImagePath !== null) {
        $sql = "UPDATE products
                SET name = :name, category = :category, description = :desc,
                    price = :price, stock_quantity = :stock, image = :image
                WHERE id = :id";
        $params = [
            ':name'  => $name,
            ':category' => $category,
            ':desc'  => $description,
            ':price' => $price,
            ':stock' => $stockQuantity,
            ':image' => $newImagePath,
            ':id'    => $productId,
        ];
    } else {
        $sql = "UPDATE products
                SET name = :name, category = :category, description = :desc,
                    price = :price, stock_quantity = :stock
                WHERE id = :id";
        $params = [
            ':name'  => $name,
            ':category' => $category,
            ':desc'  => $description,
            ':price' => $price,
            ':stock' => $stockQuantity,
            ':id'    => $productId,
        ];
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // Delete old image file from disk after successful DB update
    if ($deleteOldImage && !empty($product['image'])) {
        $oldFilePath = __DIR__ . '/../../' . $product['image'];
        if (file_exists($oldFilePath)) {
            unlink($oldFilePath);
        }
    }

    $_SESSION['success_msg'] = "Product \"$name\" updated successfully.";
    header("Location: edit_product.php?id=$productId");
    exit;

} catch (\PDOException $e) {
    error_log("Edit Product Error (ID $productId): " . $e->getMessage());

    // Clean up new image if DB update failed
    if ($newImagePath && file_exists(__DIR__ . '/../../' . $newImagePath)) {
        unlink(__DIR__ . '/../../' . $newImagePath);
    }

    $_SESSION['form_errors'] = ['A database error occurred. Please try again.'];
    $_SESSION['form_old'] = [
        'name' => $name, 'category' => $category, 'description' => $description,
        'price' => $price, 'stock_quantity' => $stockQuantity,
    ];
    header("Location: edit_product.php?id=$productId");
    exit;
}
