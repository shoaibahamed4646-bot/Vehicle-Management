<?php
/**
 * Root Database Connection Bridge
 * Bridges to the singleton database class or config connection.
 */
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/db_connect.php'; // Also include user's manual connection just in case

$pdo = Database::getInstance()->getConnection();
?>
