<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

if (isset($_GET['id'])) {
    $notif_id = (int)$_GET['id'];
    $ref = $_GET['ref'] ?? 'admin';
    
    // Safety check: get current user ID based on role
    if ($ref === 'admin' && isset($_SESSION['admin_id'])) {
        $user_id = $_SESSION['admin_id'];
        $user_type = 'admin';
    } elseif ($ref === 'employee' && isset($_SESSION['employee_id'])) {
        $user_id = $_SESSION['employee_id'];
        $user_type = 'employee';
    } elseif ($ref === 'customer' && isset($_SESSION['customer_id'])) {
        $user_id = $_SESSION['customer_id'];
        $user_type = 'customer';
    } else {
        // Not logged in or invalid ref
        header("Location: index.php");
        exit();
    }
    
    // Update the notification as read ONLY if it belongs to this user
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ? AND user_type = ?");
    $stmt->bind_param("iis", $notif_id, $user_id, $user_type);
    $stmt->execute();
    $stmt->close();
}

// Redirect back to the correct dashboard
if (isset($_GET['ref']) && $_GET['ref'] === 'employee') {
    header("Location: employee_dashboard.php");
} elseif (isset($_GET['ref']) && $_GET['ref'] === 'customer') {
    header("Location: customer_dashboard.php");
} else {
    header("Location: admin.php");
}
exit();
?>
