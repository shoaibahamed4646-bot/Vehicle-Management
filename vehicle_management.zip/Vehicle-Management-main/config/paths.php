<?php
/**
 * Project Paths Configuration
 */

// Since the project is in a subfolder "Vehicle Management", we need a constant 
// to prepend to absolute paths when using them in HTML.
define('BASE_URL', '/myProject/Vehicle-Management-main');
?>
