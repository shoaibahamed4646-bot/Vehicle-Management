<?php

/**
 * Session Configuration & Management
 * Implements secure session initialization, session fixation protection,
 * timeout handling, and defines role-based access constants.
 */

// 1. Role-based Access Constants
define('ROLE_ADMIN', 'admin');
define('ROLE_EMPLOYEE', 'employee');
define('ROLE_CUSTOMER', 'customer');

// 2. Secure Session Initialization
function init_secure_session() {
    // Check if session is already active
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    // Set secure session parameters before starting
    ini_set('session.use_only_cookies', 1);
    ini_set('session.use_strict_mode', 1);

    $cookieParams = [
        'lifetime' => 0, // Session cookie (deleted when browser closes)
        'path'     => '/',
        'domain'   => '', // Use current domain
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on', // True if HTTPS
        'httponly' => true, // Prevent JavaScript access to session cookie
        'samesite' => 'Strict' // Prevent CSRF attacks
    ];

    session_set_cookie_params($cookieParams);
    session_start();
}

// 3. Session Fixation & Timeout Handling
function validate_session() {
    // Configuration Settings
    $timeout_duration = 1800; // 30 minutes in seconds for idle timeout
    $regeneration_interval = 300; // 5 minutes in seconds for ID regeneration

    // A. Timeout Handling (Idle Timeout)
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
        // Session has expired due to inactivity
        session_unset();
        session_destroy();
        session_start(); // Start a fresh, unauthenticated session
    }
    
    // Update last activity timestamp on every request
    $_SESSION['last_activity'] = time();

    // B. Session Fixation Protection (Periodic ID Regeneration)
    if (!isset($_SESSION['last_regeneration'])) {
        // First time initialization
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    } else {
        // Regenerate ID periodically to mitigate fixation/hijacking
        if (time() - $_SESSION['last_regeneration'] > $regeneration_interval) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}


// Initialize and validate the session immediately when this file is included
init_secure_session();
validate_session();

// 4. CSRF Token Management

/**
 * Generate (or retrieve existing) CSRF token for the current session.
 * Uses 32 bytes of cryptographically secure randomness → 64-char hex string.
 *
 * @return string The CSRF token to embed in forms.
 */
function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify a submitted CSRF token against the stored session token.
 * Uses hash_equals() to prevent timing side-channel attacks.
 *
 * @param string $token The token value from the submitted form/request.
 * @return bool True if valid, false otherwise.
 */
function verifyCsrfToken(string $token): bool
{
    return !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}
