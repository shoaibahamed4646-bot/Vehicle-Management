<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

// 🔥 Prevent auto-login issue
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
}

// ✅ Only redirect if session is valid
if (isset($_SESSION['employee_id']) && ($_SESSION['role'] ?? '') === 'employee') {
    header("Location: employee_dashboard.php");
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $login = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, name, password FROM employees WHERE email = ? OR phone = ?");
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $employee = $result->fetch_assoc();

        if (password_verify($password, $employee['password'])) {
            session_regenerate_id(true); // 🔥 prevent session hijacking

            $_SESSION['employee_id']   = $employee['id'];
            $_SESSION['employee_name'] = $employee['name'];
            $_SESSION['role']          = 'employee';
            $_SESSION['user_id']       = $employee['id'];   // 🔥 needed for header
            $_SESSION['user_name']     = $employee['name'];
            header("Location: employee_dashboard.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Employee not found.";
    }

    $stmt->close();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Login - Vehicle Management</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        #register-form { display: none; }
        .message { padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; }
        .message.error { background: rgba(239, 68, 68, 0.2); border: 1px solid var(--danger); color: #fca5a5; }
        .message.success { background: rgba(16, 185, 129, 0.2); border: 1px solid var(--success); color: #a7f3d0; }
        .back-btn { position: absolute; top: 30px; left: 30px; color: var(--text-main); text-decoration: none; display: flex; align-items: center; gap: 8px; font-weight: 500; transition: color 0.3s; }
        .back-btn:hover { color: var(--primary); }
    </style>
</head>
<body>

<a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>

<div class="auth-container">
    <div class="auth-card" id="auth-card">
        <h2>Employee Login</h2>
        
        <?php if($error) echo "<div class='message error'>$error</div>"; ?>

        <!-- Login Form -->
        <form id="login-form" method="POST" action="employee_login.php">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label>Email or Phone</label>
                <input type="text" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn">Login</button>
            <div class="auth-links">
                <!-- removed register option -->
            </div>
        </form>

    </div>
</div>



</body>
</html>
