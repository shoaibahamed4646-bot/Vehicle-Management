<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

if (!isset($_SESSION['customer_id'])) {
    header("Location: customer_login.php");
    exit();
}

$customerId = (int) $_SESSION['customer_id'];
$customerName = htmlspecialchars($_SESSION['customer_name'] ?? 'Customer');

$requests = $conn->query("
    SELECT sr.*, v.model, v.registration_no 
    FROM service_requests sr 
    JOIN vehicles v ON sr.vehicle_id = v.registration_no 
    WHERE v.customer_id = $customerId
    ORDER BY sr.id DESC
");

// 🔔 FETCH UNREAD NOTIFICATIONS
$unread_notifs = $conn->query("SELECT * FROM notifications WHERE user_id = $customerId AND user_type = 'customer' AND is_read = 0 ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Vehicle Management</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .section-title {
            margin: 20px 0 15px 0;
            padding-bottom: 5px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            font-size: 1.1rem;
            color: var(--primary);
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1.4fr;
            gap: 24px;
        }
        .card-body {
            padding: 24px;
        }
        .btn-primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 20px;
            background: #4f46e5;
            color: #fff;
            border-radius: 10px;
            text-decoration: none;
            margin-top: 16px;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-user"></i> Customer Portal</h2>
        </div>
        <ul class="nav-links">
            <li><a href="customer_dashboard.php" class="active">
                <i class="fas fa-home" style="margin-right:10px;"></i> Dashboard
                <?php if ($unread_notifs->num_rows > 0): ?>
                    <span style="background: #ef4444; color: white; font-size: 0.7rem; padding: 2px 6px; border-radius: 10px; margin-left: 5px;">
                        <?= $unread_notifs->num_rows ?>
                    </span>
                <?php endif; ?>
            </a></li>
            <li><a href="register_vehicle.php"><i class="fas fa-car" style="margin-right:10px;"></i> Register Vehicle</a></li>
            <li><a href="service-packages/views/select_service.php"><i class="fas fa-tools" style="margin-right:10px;"></i> Book Service</a></li>
            <li style="margin-top: auto;"><a href="customer_logout.php"><i class="fas fa-sign-out-alt" style="margin-right:10px;"></i> Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h1>Welcome, <?php echo $customerName; ?>!</h1>
            <div class="user-profile">
                <!-- 🔔 Notification Bell -->
                <div style="position: relative; margin-right: 20px; cursor: pointer;">
                    <i class="fas fa-bell" style="font-size: 1.4rem; color: #8b95a5;"></i>
                    <?php if ($unread_notifs->num_rows > 0): ?>
                        <span style="position: absolute; top: -5px; right: -5px; background: #ef4444; color: white; font-size: 0.7rem; padding: 2px 5px; border-radius: 50%; min-width: 15px; text-align: center; border: 2px solid #13141f;">
                            <?= $unread_notifs->num_rows ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div style="background: rgba(255,255,255,0.1); padding: 8px 16px; border-radius: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-circle" style="font-size: 1.5rem;"></i>
                    <span><?= $customerName ?></span>
                </div>
            </div>
        </div>

        <!-- ✅ NOTIFICATIONS -->
        <?php if ($unread_notifs->num_rows > 0): ?>
            <div style="margin-bottom: 24px;">
                <?php while($n = $unread_notifs->fetch_assoc()): ?>
                    <div class="alert info" style="background: rgba(59, 130, 246, 0.1); border: 1px solid #3b82f6; color: #3b82f6; padding: 15px; border-radius: 12px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; animation: slideIn 0.3s ease-out;">
                        <span><i class="fas fa-bell" style="margin-right: 10px;"></i> <?= htmlspecialchars($n['message']) ?></span>
                        <a href="mark_read.php?id=<?= $n['id'] ?>&ref=customer" style="color: inherit; text-decoration: none; font-weight: bold; font-size: 1.2rem;">&times;</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>

        <div class="dashboard-grid">
            <div class="data-card">
                <div class="data-card-header">
                    <h2><i class="fas fa-plus-circle"></i> New Service Request</h2>
                </div>
                <div class="card-body">
                    <p>Book a new service for your vehicle quickly. You can register a vehicle first if needed, then select a service package.</p>
                    <a href="service-packages/views/select_service.php" class="btn-primary">
                        <i class="fas fa-tools" style="margin-right: 8px;"></i>
                        Start New Service Request
                    </a>
                </div>
            </div>

            <div class="data-card">
                <div class="data-card-header">
                    <h2><i class="fas fa-history"></i> Your Service History</h2>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Vehicle</th>
                                <th>Service Type</th>
                                <th>Description</th>
                                <th>Priority</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($requests && $requests->num_rows > 0): ?>
                                <?php while($row = $requests->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $row['id']; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($row['model']); ?><br>
                                        <small style="color:var(--text-muted);"><?php echo htmlspecialchars($row['registration_no']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['service_type']); ?></td>
                                    <td><?php echo htmlspecialchars($row['complaint_text']); ?></td>
                                    <td><?php echo htmlspecialchars($row['priority']); ?></td>
                                    <td>
                                        <span class="badge <?php echo strtolower($row['status']); ?>">
                                            <?php echo htmlspecialchars($row['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 30px;">
                                        No service requests yet.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>