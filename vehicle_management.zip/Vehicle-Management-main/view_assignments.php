<?php
require_once 'includes/session.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// ✅ ORIGINAL check
if (!isset($_SESSION['employee_id'])) {
    header("Location: employee_login.php");
    exit();
}

// 🔥 BRIDGE
$_SESSION['user_id'] = $_SESSION['employee_id'];
$_SESSION['role'] = 'employee';
$_SESSION['user_name'] = $_SESSION['employee_name'];

// ✅ AUTH
requireRole('employee');

$currentPage = 'admin';
require_once 'includes/header.php';

$employeeId = (int) $_SESSION['employee_id'];

$sql = "
SELECT 
    ea.id,
    sr.id AS service_id,
    sr.complaint_text,
    sr.status,
    e.name AS employee_name
FROM employee_assignments ea
JOIN service_requests sr ON ea.service_request_id = sr.id
JOIN employees e ON ea.employee_id = e.id
WHERE ea.employee_id = $employeeId
ORDER BY sr.id DESC
";

$result = $conn->query($sql);
?>




<div class="main-content">

    <div class="topbar">
        <h1>My Assignments</h1>
    </div>

    <div class="data-card">
        <div class="data-card-header">
            <h3>Assigned Services</h3>
        </div>

        <div class="dashboard-grid">

        <?php if ($result->num_rows == 0) { ?>
            <p>No assignments found.</p>
        <?php } else { ?>

            <?php while ($row = $result->fetch_assoc()) { ?>

                <div class="widget">
                    <h3>Service #<?= $row['service_id'] ?></h3>

                    <p>
                        <?= strlen($row['complaint_text']) > 60 
                            ? substr($row['complaint_text'], 0, 60) . '...' 
                            : $row['complaint_text'] ?>
                    </p>

                    <p><strong>Employee:</strong> <?= $row['employee_name'] ?></p>

                    <span class="badge 
                    <?= 
                    $row['status']=='Pending' ? 'pending' :
                    ($row['status']=='Completed' ? 'completed' : 'active')
                    ?>">
                        <?= $row['status'] ?>
                    </span>

                    <br><br>

                    <?php if ($row['status'] == 'Pending') { ?>
                        <a href="complete_service.php?id=<?= $row['service_id'] ?>" class="btn-sm edit">
                            Complete
                        </a>
                    <?php } else { ?>
                        <span style="color:#94a3b8;">Done</span>
                    <?php } ?>

                </div>

            <?php } ?>

        <?php } ?>

        </div>

    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
