<?php
require_once __DIR__ . '/config/session.php';

// If already logged in as customer, redirect to customer dashboard
if (isset($_SESSION['customer_id'])) {
    header("Location: customer_dashboard.php");
    exit();
}

// If already logged in as admin, redirect to admin dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Vehicle Management System</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .portal-grid {
            display: grid;
            /* Changed from 1fr 1fr to auto-fit to comfortably hold the new cards */
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            max-width: 1100px; /* Widened slightly for the extra cards */
            width: 100%;
            margin: 0 auto;
        }
        
        .portal-card {
            background: var(--bg-card, #141627);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border, rgba(59, 130, 246, 0.1));
            border-radius: 16px;
            padding: 50px 30px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
            text-decoration: none;
            color: var(--text-main, #e8ecf4);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .portal-card:hover {
            transform: translateY(-10px);
            border-color: var(--primary, #3b82f6);
            box-shadow: 0 20px 40px rgba(59, 130, 246, 0.2);
        }

        .portal-card i {
            font-size: 4rem;
            color: var(--primary, #3b82f6);
            margin-bottom: 20px;
        }

        .portal-card h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .portal-card p {
            color: var(--text-muted, #7a84a0);
            font-size: 1rem;
            line-height: 1.5;
        }

        @media (max-width: 768px) {
            .portal-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body style="background: var(--bg-main, #0c0e1a); color: var(--text-main, #e8ecf4); font-family: sans-serif; min-height: 100vh; margin: 0; display: flex; flex-direction: column;">

<?php require_once __DIR__ . '/includes/header.php'; ?>

<main style="flex: 1; display: flex; justify-content: center; padding: 40px 20px;">
    <div class="auth-container" style="display: flex; flex-direction: column; width: 100%; max-width: 1200px;">
        <div style="text-align: center; margin-bottom: 50px; animation: slideUp 0.5s ease-out;">
            <i class="fas fa-car-side" style="font-size: 3rem; color: var(--primary, #3b82f6); margin-bottom: 15px;"></i>
            <h1 style="font-size: 2.5rem; font-weight: 700; margin-top: 0;">Vehicle Management System</h1>
            <p style="color: var(--text-muted, #7a84a0); margin-top: 10px; font-size: 1.2rem;">Choose your portal to continue</p>
        </div>

        <div class="portal-grid" style="animation: slideUp 0.6s ease-out;">
            <!-- Group's Existing Portals -->
            <a href="customer_login.php" class="portal-card">
                <i class="fas fa-user"></i>
                <h2>Customer Portal</h2>
                <p>View your vehicles, track service requests, and submit new complaints.</p>
            </a>

            <a href="admin_login.php" class="portal-card">
                <i class="fas fa-user-shield"></i>
                <h2>Admin Portal</h2>
                <p>Manage customers, employees, vehicles, and process service requests.</p>
            </a>
            <a href="employee_login.php" class="portal-card">
                <i class="fas fa-user-tie"></i>
                <h2>Employee Portal</h2>
                <p>Access your dashboard, view assigned tasks, and update service request statuses.</p>
            </a>

            <!-- Newly Added Modules -->
            <a href="products/views/product_list.php" class="portal-card">
                <i class="fas fa-shopping-cart"></i>
                <h2>Auto Parts Store</h2>
                <p>Browse and purchase premium quality vehicle parts and accessories.</p>
            </a>

            <a href="service-packages/views/package_list.php" class="portal-card">
                <i class="fas fa-tools"></i>
                <h2>Service Packages</h2>
                <p>Book professional auto care packages tailored for optimal performance.</p>
            </a>
            
            <a href="service-packages/views/select_service.php" class="portal-card">
                <i class="fas fa-cogs"></i>
                <h2>Custom Services</h2>
                <p>Build your own customized repair and maintenance service bundle.</p>
            </a>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

</body>
</html>
