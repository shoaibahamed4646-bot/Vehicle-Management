<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

if (!isset($_SESSION['employee_id'])) {
    header("Location: employee_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $stmt = $conn->prepare("UPDATE service_requests SET status='Completed' WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: view_assignments.php");
        exit();
    } else {
        echo "Error updating status";
    }
}
?>