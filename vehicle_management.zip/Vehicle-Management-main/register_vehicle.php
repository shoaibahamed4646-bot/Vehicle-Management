<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

if (!isset($_SESSION['customer_id'])) {
    // If it's a guest registering, we can still allow it or redirect to login.
    // Let's assume for now it matches the Customer Portal style.
}

$customerName = htmlspecialchars($_SESSION['customer_name'] ?? 'Guest');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Vehicle - Vehicle Management</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .form-section {
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid var(--border);
        }
        .form-section h3 {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
        }
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        @media (max-width: 600px) {
            .grid-2 { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <!-- SIDEBAR (Matches Customer Portal) -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-user"></i> Customer Portal</h2>
        </div>
        <ul class="nav-links">
            <li><a href="customer_dashboard.php"><i class="fas fa-home" style="margin-right:10px;"></i> Dashboard</a></li>
            <li><a href="register_vehicle.php" class="active"><i class="fas fa-car" style="margin-right:10px;"></i> Register Vehicle</a></li>
            <li><a href="service-packages/views/select_service.php"><i class="fas fa-tools" style="margin-right:10px;"></i> Book Service</a></li>
            <li style="margin-top: auto;"><a href="customer_logout.php"><i class="fas fa-sign-out-alt" style="margin-right:10px;"></i> Logout</a></li>
        </ul>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="topbar">
            <h1>Register New Vehicle</h1>
            <div class="user-profile">
                <div style="background: rgba(255,255,255,0.1); padding: 8px 16px; border-radius: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-circle" style="font-size: 1.5rem;"></i>
                    <span><?php echo $customerName; ?></span>
                </div>
            </div>
        </div>

        <div style="max-width: 900px; margin: 0 auto; padding: 20px;">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success" style="background: rgba(16, 185, 129, 0.1); border: 1px solid #10b981; color: #10b981; padding: 15px; border-radius: 8px; margin-bottom: 25px;">
                    <i class="fas fa-check-circle" style="margin-right: 10px;"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error" style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444; color: #ef4444; padding: 15px; border-radius: 8px; margin-bottom: 25px;">
                    <i class="fas fa-exclamation-circle" style="margin-right: 10px;"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <div class="data-card" style="padding: 30px;">
                <form action="includes/register_vehicle.php" method="POST">
                    
                    <div class="form-section">
                        <h3><i class="fas fa-user"></i> Customer Details</h3>
                        <div class="grid-2">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($_SESSION['customer_name'] ?? '') ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($_SESSION['customer_email'] ?? '') ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3><i class="fas fa-car"></i> Vehicle Details</h3>
                        <div class="grid-2">
                            <div class="form-group">
                                <label>Brand</label>
                                <input type="text" name="brand" class="form-control" placeholder="e.g. Toyota" required>
                            </div>
                            <div class="form-group">
                                <label>Model</label>
                                <input type="text" name="model" class="form-control" placeholder="e.g. Corolla" required>
                            </div>
                        </div>
                        <div class="grid-2" style="margin-top: 15px;">
                            <div class="form-group">
                                <label>Registration No</label>
                                <input type="text" name="registration_no" class="form-control" placeholder="ABC-123" required>
                            </div>
                            <div class="form-group">
                                <label>Registration Date</label>
                                <input type="date" name="registration_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="grid-2" style="margin-top: 15px;">
                            <div class="form-group">
                                <label>Current Mileage (km)</label>
                                <input type="number" name="mileage" class="form-control" placeholder="0" required>
                            </div>
                            <div class="form-group">
                                <label>Service Priority</label>
                                <select name="priority" class="form-control">
                                    <option value="Low">Low</option>
                                    <option value="Medium">Medium</option>
                                    <option value="High">High</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn" style="width: 100%; padding: 15px; font-weight: bold;">
                        <i class="fas fa-paper-plane" style="margin-right: 10px;"></i> Register & Submit Request
                    </button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
