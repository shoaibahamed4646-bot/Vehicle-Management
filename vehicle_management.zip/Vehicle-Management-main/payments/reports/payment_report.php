<?php

/**
 * Payment Report Controller & View
 * Fetches paginated payment history from the database, filtered by 
 * date range and invoice status, and returns data for view rendering.
 */

require_once __DIR__ . '/../../includes/auth.php';

// Security check: Only admins or employees can view financial reports
// requireRole(['admin', 'employee']); // MOCKED: Bypassing auth for UI testing

// 1. Pagination Setup
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT) ?: 1;
if ($page < 1) $page = 1;

$limit = 20; // Number of records per page
$offset = ($page - 1) * $limit;

// 2. Filter Inputs & Validation
// Helper to validate YYYY-MM-DD dates
function isValidDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

$rawStartDate = $_GET['start_date'] ?? date('Y-m-01'); // Default: 1st of current month
$rawEndDate   = $_GET['end_date'] ?? date('Y-m-t');    // Default: Last day of current month
$statusFilter = $_GET['status'] ?? '';                 // E.g., 'paid', 'pending'

$startDate = isValidDate($rawStartDate) ? $rawStartDate : date('Y-m-01');
$endDate   = isValidDate($rawEndDate) ? $rawEndDate : date('Y-m-t');

try {
    $db = Database::getInstance()->getConnection();
    
    // Base query
    $sql = "SELECT p.payment_id, p.amount_paid as amount, p.payment_method, p.payment_date, 
                   i.invoice_id, i.payment_status as invoice_status, u.username as customer_name
            FROM payments p
            JOIN invoices i ON p.invoice_id = i.invoice_id
            JOIN users u ON i.customer_id = u.id
            WHERE DATE(p.payment_date) BETWEEN ? AND ?";
    
    $params = [$startDate, $endDate];
    
    if (!empty($statusFilter)) {
        $sql .= " AND i.payment_status = ?";
        $params[] = $statusFilter;
    }
    
    // Count query
    $countSql = "SELECT COUNT(*) FROM (" . $sql . ") as total_results";
    $countStmt = $db->prepare($countSql);
    $countStmt->execute($params);
    $totalRecords = $countStmt->fetchColumn();
    $totalPages = max(1, ceil($totalRecords / $limit));
    
    // Add pagination
    $sql .= " ORDER BY p.created_at DESC LIMIT $limit OFFSET $offset";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $payments = $stmt->fetchAll();

} catch (\Exception $e) {
    error_log("Payment Report Error: " . $e->getMessage());
    $errorMsg = "An error occurred while fetching report data. Please contact technical support.";
    $payments = [];
    $totalRecords = 0;
    $totalPages = 0;
}

// Render the separate view file for testing
define('PAYMENT_REPORT_READY', true);
require __DIR__ . '/../views/payment_history.php';
