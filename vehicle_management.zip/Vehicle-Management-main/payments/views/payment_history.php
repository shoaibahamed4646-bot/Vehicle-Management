<?php
// Ensure this view is not accessed directly
if (!defined('PAYMENT_REPORT_READY')) {
    exit('Direct access not permitted.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History | Data Grid</title>
    <style>
        :root {
            /* Team UI Theme matching the landing page */
            --bg-base: #141423;
            --card-bg: #1e1f35;
            --card-border: rgba(255, 255, 255, 0.05);
            --text-primary: #ffffff;
            --text-secondary: #9496b8;
            --accent-primary: #5c62fa;
            --accent-hover: #4b51df;
            --input-bg: rgba(0, 0, 0, 0.2);
            --input-border: rgba(255, 255, 255, 0.1);
            --error-color: #ef4444;
            --border-radius-lg: 16px;
            --border-radius-md: 8px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-primary);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            padding: 2rem;
            line-height: 1.5;
        }

        .data-container {
            background-color: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-lg);
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        /* --- Header & Summary --- */
        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            padding: 2rem 3rem;
            border-bottom: 1px solid var(--card-border);
            background-color: rgba(0, 0, 0, 0.1);
        }

        .header-section h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }
        
        .header-section p {
            font-weight: 500;
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .record-count {
            font-weight: 600;
            font-size: 1rem;
            color: #ffffff;
            background-color: var(--accent-primary);
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius-md);
        }

        /* --- Error Banner --- */
        .error-banner {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
            padding: 1rem 3rem;
            border-bottom: 1px solid rgba(239, 68, 68, 0.2);
            font-size: 0.9rem;
            text-align: center;
        }

        /* --- Filter Control Bar --- */
        .filter-bar {
            padding: 2rem 3rem;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            gap: 2rem;
            align-items: flex-end;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .filter-group input, 
        .filter-group select {
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--text-primary);
            font-size: 1rem;
            padding: 0.875rem 1rem;
            border-radius: var(--border-radius-md);
            transition: all 0.2s ease;
            font-family: inherit;
            min-width: 200px;
        }

        .filter-group input:focus, 
        .filter-group select:focus {
            outline: none;
            border-color: var(--accent-primary);
            background-color: rgba(0, 0, 0, 0.3);
        }

        .filter-group select option {
            background-color: var(--card-bg);
            color: var(--text-primary);
        }

        .btn-apply {
            background-color: var(--accent-primary);
            color: #ffffff;
            border: none;
            padding: 0.875rem 2rem;
            font-size: 1rem;
            font-weight: 600;
            border-radius: var(--border-radius-md);
            cursor: pointer;
            transition: background-color 0.2s ease, transform 0.1s ease;
        }

        .btn-apply:hover {
            background-color: var(--accent-hover);
        }
        
        .btn-apply:active {
            transform: scale(0.98);
        }

        /* --- Data Table --- */
        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .data-grid {
            width: 100%;
            border-collapse: collapse;
        }

        .data-grid th, 
        .data-grid td {
            padding: 1.25rem 1.5rem;
            text-align: left;
            border-bottom: 1px solid var(--card-border);
        }

        .data-grid th {
            background-color: rgba(0, 0, 0, 0.2);
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .data-grid td {
            font-size: 1rem;
            color: var(--text-primary);
        }

        .data-grid tr:hover td {
            background-color: rgba(255, 255, 255, 0.02);
        }

        .data-grid tr:last-child td {
            border-bottom: none;
        }

        /* --- Typography & Badges --- */
        .id-cell {
            font-family: monospace;
            color: var(--text-secondary);
        }

        .amount-cell {
            text-align: right;
            font-weight: 600 !important;
        }
        
        th.col-amount {
            text-align: right;
        }

        .status-pill {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            border-radius: 9999px;
        }

        .status-pill.paid {
            background-color: rgba(92, 98, 250, 0.2);
            color: #8c91ff;
            border: 1px solid rgba(92, 98, 250, 0.3);
        }

        .status-pill.pending {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border: 1px solid var(--card-border);
        }

        .method-label {
            font-size: 0.85rem;
            color: var(--text-secondary);
        }

        .invoice-link {
            color: var(--accent-primary);
            text-decoration: none;
            font-weight: 500;
        }

        .invoice-link:hover {
            color: var(--accent-hover);
            text-decoration: underline;
        }

        /* --- Pagination --- */
        .pagination-bar {
            padding: 1.5rem 3rem;
            border-top: 1px solid var(--card-border);
            background-color: rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            gap: 0.5rem;
        }

        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: var(--border-radius-md);
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.875rem;
            transition: all 0.2s;
        }

        .page-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            border-color: var(--card-border);
        }

        .page-link.active {
            background-color: var(--accent-primary);
            border-color: var(--accent-primary);
            color: #ffffff;
            pointer-events: none;
        }

        /* --- Empty State --- */
        .empty-state {
            padding: 4rem 3rem;
            text-align: center;
            font-weight: 500;
            font-size: 1rem;
            color: var(--text-secondary);
        }

    </style>
</head>
<body>

<div class="data-container">
    <div class="header-section">
        <div>
            <h1>Payment Matrix</h1>
            <p>Financial Operations Ledger</p>
        </div>
        <div class="record-count">
            <?= number_format($totalRecords ?? 0) ?> Records
        </div>
    </div>

    <?php if (!empty($errorMsg)): ?>
        <div class="error-banner">
            <?= htmlspecialchars($errorMsg) ?>
        </div>
    <?php endif; ?>

    <form class="filter-bar" method="GET" action="">
        <div class="filter-group">
            <label for="start_date">Start Boundary</label>
            <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($startDate ?? '') ?>">
        </div>
        
        <div class="filter-group">
            <label for="end_date">End Boundary</label>
            <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($endDate ?? '') ?>">
        </div>
        
        <div class="filter-group">
            <label for="status">Condition</label>
            <select id="status" name="status">
                <option value="">ALL STATES</option>
                <option value="paid" <?= ($statusFilter ?? '') === 'paid' ? 'selected' : '' ?>>PAID</option>
                <option value="pending" <?= ($statusFilter ?? '') === 'pending' ? 'selected' : '' ?>>PENDING</option>
            </select>
        </div>
        
        <div class="filter-group">
            <button type="submit" class="btn-apply">Execute Filter</button>
        </div>
    </form>

    <div class="table-wrapper">
        <table class="data-grid">
            <thead>
                <tr>
                    <th>Ref ID</th>
                    <th>Timestamp</th>
                    <th>Entity / Customer</th>
                    <th>Invoice Link</th>
                    <th>Method</th>
                    <th class="col-amount">Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($payments)): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">No telemetry matching current parameters.</div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td class="id-cell">#<?= htmlspecialchars($payment['payment_id'] ?? '') ?></td>
                            <td><?= htmlspecialchars(isset($payment['payment_date']) ? date('y.m.d H:i', strtotime($payment['payment_date'])) : '') ?></td>
                            <td><?= htmlspecialchars($payment['customer_name'] ?? 'UNKNOWN') ?></td>
                            <td>
                                <?php if (!empty($payment['invoice_id'])): ?>
                                    <a class="invoice-link" href="/payments/handlers/generate_invoice.php?invoice_id=<?= urlencode($payment['invoice_id']) ?>">
                                        INV-<?= htmlspecialchars($payment['invoice_id']) ?>
                                    </a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td><span class="method-label"><?= htmlspecialchars(str_replace('_', ' ', $payment['payment_method'] ?? '')) ?></span></td>
                            <td class="amount-cell">$<?= number_format($payment['amount'] ?? 0, 2) ?></td>
                            <td>
                                <?php 
                                    $status = strtolower($payment['invoice_status'] ?? 'pending');
                                    $statusClass = $status === 'paid' ? 'paid' : 'pending';
                                ?>
                                <span class="status-pill <?= $statusClass ?>"><?= htmlspecialchars($status) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (($totalPages ?? 0) > 1): ?>
    <div class="pagination-bar">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php 
                $queryParams = $_GET;
                $queryParams['page'] = $i;
                $queryString = http_build_query($queryParams);
                $isActive = ($page ?? 1) == $i;
            ?>
            <a href="?<?= htmlspecialchars($queryString) ?>" class="page-link <?= $isActive ? 'active' : '' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>

</div>

</body>
</html>
