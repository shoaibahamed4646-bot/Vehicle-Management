<?php
/**
 * Payment Form View
 * Posts to payments/handlers/process_payment.php with CSRF protection.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

$currentPage = '';
require_once __DIR__ . '/../../includes/header.php';

// Read invoice_id from query string
$invoiceId = filter_input(INPUT_GET, 'invoice_id', FILTER_VALIDATE_INT) ?? 0;

// Pre-fill customer name from session if logged in
$customerName = '';
if (!empty($_SESSION['user_id'])) {
    $user = getCurrentUser();
    $customerName = $user['username'] ?? '';
}

// Default amount (could be fetched from DB invoice row in production)
$amount = filter_input(INPUT_GET, 'amount', FILTER_VALIDATE_FLOAT) ?? 0.00;

// Flash messages
$successMsg = $_SESSION['success_msg'] ?? null;
$errorMsg   = $_SESSION['error_msg'] ?? null;
unset($_SESSION['success_msg'], $_SESSION['error_msg']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Payment | VehicleMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#0c0e1a;--bg-card:#141627;--bg-input:#0e1020;
            --text:#e8ecf4;--muted:#7a84a0;
            --accent:#3b82f6;--accent-light:#60a5fa;--accent-hover:#2563eb;
            --glow:rgba(59,130,246,.15);--glow-s:rgba(59,130,246,.25);
            --danger:#ef4444;--success:#22c55e;
            --border:rgba(59,130,246,.08);--border-h:rgba(59,130,246,.25);
            --r:14px;--t:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        body{margin:0;background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased;min-height:100vh;}

        .page-wrap{max-width:600px;margin:0 auto;padding:50px 24px 80px;}

        .back-link{display:inline-flex;align-items:center;gap:6px;color:var(--accent);text-decoration:none;font-weight:600;font-size:.9rem;margin-bottom:28px;transition:var(--t);}
        .back-link:hover{color:var(--text);transform:translateX(-4px);}
        .back-link svg{width:16px;height:16px;}

        h1{font-size:2rem;font-weight:800;margin:0 0 6px;letter-spacing:-.03em;}
        .subtitle{color:var(--muted);margin:0 0 30px;font-size:.95rem;}

        /* Flash */
        .flash{border-radius:10px;padding:14px 18px;margin-bottom:22px;font-size:.9rem;display:flex;align-items:center;gap:8px;}
        .flash-ok{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);color:var(--success);}
        .flash-err{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);color:var(--danger);}

        /* Card */
        .form-card{
            background:var(--bg-card);border:1px solid var(--border);border-radius:var(--r);
            padding:35px 30px;position:relative;overflow:hidden;
        }
        .form-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--accent),transparent);}

        /* Fields */
        .field{margin-bottom:22px;}
        .field label{display:block;font-size:.85rem;font-weight:600;color:#c8cedc;margin-bottom:7px;}
        .field-input{
            width:100%;background:var(--bg-input);border:1px solid var(--border);
            color:var(--text);padding:13px 16px;border-radius:8px;
            font-size:.95rem;font-family:inherit;transition:var(--t);
        }
        .field-input:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--glow);}
        .field-input::placeholder{color:var(--muted);}
        .field-input[readonly]{opacity:.6;cursor:not-allowed;}
        textarea.field-input{resize:vertical;min-height:80px;}

        .field-hint{font-size:.78rem;color:var(--muted);margin-top:5px;}

        /* Radio group */
        .radio-group{display:flex;flex-direction:column;gap:10px;}
        .radio-option{
            display:flex;align-items:center;gap:12px;
            background:var(--bg-input);border:2px solid var(--border);
            border-radius:10px;padding:14px 16px;cursor:pointer;transition:var(--t);
        }
        .radio-option:hover{border-color:var(--border-h);}
        .radio-option input[type="radio"]{display:none;}
        .radio-option.selected{border-color:var(--accent);background:var(--glow);}

        .radio-dot{
            width:18px;height:18px;border-radius:50%;border:2px solid var(--muted);
            display:flex;align-items:center;justify-content:center;
            flex-shrink:0;transition:var(--t);
        }
        .radio-dot::after{content:'';width:8px;height:8px;border-radius:50%;background:var(--accent);opacity:0;transition:var(--t);}
        .radio-option.selected .radio-dot{border-color:var(--accent);}
        .radio-option.selected .radio-dot::after{opacity:1;}

        .radio-icon{font-size:1.1rem;}
        .radio-text{font-weight:600;font-size:.92rem;}

        /* Submit */
        .btn-pay{
            width:100%;margin-top:28px;padding:16px;border:none;border-radius:10px;
            background:var(--accent);color:#fff;font-size:1.1rem;font-weight:700;
            cursor:pointer;transition:var(--t);
            display:flex;align-items:center;justify-content:center;gap:10px;
        }
        .btn-pay:hover{background:var(--accent-hover);transform:scale(1.02);box-shadow:0 12px 24px -6px rgba(59,130,246,.4);}
        .btn-pay:disabled{opacity:.4;cursor:not-allowed;transform:none;box-shadow:none;}
        .btn-pay svg{width:20px;height:20px;}

        .secure-note{margin-top:14px;text-align:center;font-size:.78rem;color:var(--muted);display:flex;align-items:center;justify-content:center;gap:5px;}
        .secure-note svg{width:13px;height:13px;}
    </style>
</head>
<body>

<div class="page-wrap">

    <a href="/payments/index.php" class="back-link">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Back
    </a>

    <?php if ($successMsg): ?>
        <div class="flash flash-ok">✓ <?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
        <div class="flash flash-err">✗ <?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <h1>Make Payment</h1>
    <p class="subtitle">Complete the details below to process your payment.</p>

    <div class="form-card">
        <form action="/payments/handlers/process_payment.php" method="POST" id="payForm">

            <!-- CSRF Token -->
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(generateCsrfToken()) ?>">

            <!-- Invoice ID (hidden) -->
            <input type="hidden" name="invoice_id" value="<?= (int) $invoiceId ?>">

            <!-- Customer Name -->
            <div class="field">
                <label for="customer_name">Customer Name</label>
                <input type="text" id="customer_name" class="field-input"
                       value="<?= htmlspecialchars($customerName) ?>" readonly>
                <div class="field-hint">Auto-filled from your account.</div>
            </div>

            <!-- Amount -->
            <div class="field">
                <label for="amount">Amount (USD)</label>
                <input type="text" id="amount" name="amount" class="field-input"
                       value="<?= number_format($amount, 2) ?>" readonly>
            </div>

            <!-- Payment Method -->
            <div class="field">
                <label>Payment Method</label>
                <div class="radio-group" id="payMethods">
                    <label class="radio-option selected" onclick="selectMethod(this)">
                        <input type="radio" name="payment_method" value="cash" checked>
                        <span class="radio-dot"></span>
                        <span class="radio-icon">💵</span>
                        <span class="radio-text">Cash</span>
                    </label>
                </div>
            </div>

            <!-- Notes -->
            <div class="field">
                <label for="notes">Notes <span style="font-weight:400;color:var(--muted);">(optional)</span></label>
                <textarea id="notes" name="notes" class="field-input" placeholder="Any special instructions..."></textarea>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn-pay" id="payBtn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                Confirm Payment
            </button>

            <div class="secure-note">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                Secured with CSRF token verification
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<script>
function selectMethod(el) {
    document.querySelectorAll('.radio-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    el.querySelector('input').checked = true;
}

// Prevent double-submit
document.getElementById('payForm').addEventListener('submit', function() {
    const btn = document.getElementById('payBtn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin .7s linear infinite"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg> Processing...';
});
</script>
<style>@keyframes spin{to{transform:rotate(360deg);}}</style>
</body>
</html>
