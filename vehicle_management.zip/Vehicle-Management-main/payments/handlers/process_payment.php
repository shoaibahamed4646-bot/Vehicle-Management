<?php

/**
 * Payment Processing Handler
 * Validates the payment form POST request, securely logs the payment,
 * and updates the corresponding invoice status atomically.
 */

require_once __DIR__ . '/../../includes/auth.php';

// Ensure the user is authenticated
requireLogin();

// 1. Enforce POST Method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_msg'] = "Invalid request method.";
    header("Location: /payments/index.php");
    exit();
}

// 1b. CSRF Token Verification
$csrfToken = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($csrfToken)) {
    $_SESSION['error_msg'] = 'Invalid security token. Please refresh and try again.';
    header('Location: /payments/index.php');
    exit();
}

// 2. Retrieve and Validate Inputs
$invoiceId = filter_input(INPUT_POST, 'invoice_id', FILTER_VALIDATE_INT);
$amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
$paymentMethod = $_POST['payment_method'] ?? '';

// Check required fields
if (!$invoiceId || $invoiceId <= 0) {
    $_SESSION['error_msg'] = "Invalid invoice reference.";
    header("Location: /payments/index.php");
    exit();
}

if ($amount === false || $amount <= 0) {
    $_SESSION['error_msg'] = "Please provide a valid payment amount.";
    header("Location: /payments/checkout.php?invoice_id=" . $invoiceId);
    exit();
}

// Validate against an allowed list of payment methods
$allowedMethods = ['credit_card', 'cash', 'bank_transfer', 'paypal'];
if (!in_array($paymentMethod, $allowedMethods, true)) {
    $_SESSION['error_msg'] = "The selected payment method is invalid or not supported.";
    header("Location: /payments/checkout.php?invoice_id=" . $invoiceId);
    exit();
}

// 3. Process Database Operations
try {
    $db = Database::getInstance()->getConnection();
    
    // Check if invoice exists and is unpaid
    $stmt = $db->prepare("SELECT invoice_id, payment_status, total_amount FROM invoices WHERE invoice_id = ?");
    $stmt->execute([$invoiceId]);
    $invoice = $stmt->fetch();
    
    if (!$invoice) {
        $_SESSION['error_msg'] = "Invoice not found.";
        header("Location: /Vehicle Management/payments/index.php");
        exit();
    }
    
    if ($invoice['payment_status'] === 'paid') {
        $_SESSION['error_msg'] = "This invoice has already been paid.";
        header("Location: /Vehicle Management/payments/views/invoice.php?invoice_id=" . $invoiceId);
        exit();
    }
    
    $db->beginTransaction();
    
    // Insert payment record
    $stmt = $db->prepare("INSERT INTO payments (invoice_id, amount_paid, payment_method, payment_date) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$invoiceId, $amount, $paymentMethod]);
    
    // Update invoice status to paid
    $stmt = $db->prepare("UPDATE invoices SET payment_status = 'paid' WHERE invoice_id = ?");
    $stmt->execute([$invoiceId]);
    
    $db->commit();

    // 4. Redirect on Success
    $_SESSION['success_msg'] = "Payment of $" . number_format($amount, 2) . " was processed successfully.";
    header("Location: /Vehicle Management/payments/views/invoice.php?invoice_id=" . $invoiceId);
    exit();

} catch (\Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    error_log("Payment Processing Error: " . $e->getMessage());
    // 5. Handle Errors Gracefully
    $_SESSION['error_msg'] = "An error occurred while processing your payment. Please try again.";
    header("Location: /Vehicle Management/payments/views/payment_form.php?invoice_id=" . $invoiceId);
    exit();
}
