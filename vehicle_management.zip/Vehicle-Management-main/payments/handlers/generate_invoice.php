<?php

/**
 * Invoice Generator Handler
 * Fetches order/service data from the database, calculates totals dynamically,
 * and generates a secure HTML invoice with built-in print view support.
 */

require_once __DIR__ . '/../../includes/auth.php';

// Ensure the user is authenticated before accessing any invoices
requireLogin();

// 1. Validate Input
$invoiceId = filter_input(INPUT_GET, 'invoice_id', FILTER_VALIDATE_INT);
$isPrintView = filter_input(INPUT_GET, 'print', FILTER_VALIDATE_BOOLEAN);

if (!$invoiceId || $invoiceId <= 0) {
    die("Error: Invalid or missing invoice reference.");
}

try {
    $db = Database::getInstance()->getConnection();

    // 2. Fetch Invoice Metadata and Customer Details
    $stmt = $db->prepare("
        SELECT i.invoice_id, i.created_at, i.payment_status as status, i.total_amount, i.subtotal, i.discount,
               u.id as customer_id, u.username as customer_name, u.email as customer_email
        FROM invoices i
        JOIN users u ON i.customer_id = u.id
        WHERE i.invoice_id = ?
    ");
    $stmt->execute([$invoiceId]);
    $invoice = $stmt->fetch();

    if (!$invoice) {
        die("Error: Invoice not found.");
    }

    // Fetch items directly from invoice_items table
    $itemStmt = $db->prepare("
        SELECT item_name as description, quantity, unit_price, line_total 
        FROM invoice_items 
        WHERE invoice_id = ?
    ");
    $itemStmt->execute([$invoiceId]);
    $items = $itemStmt->fetchAll();

    $subtotal = (float)$invoice['subtotal'];
    $discount = (float)($invoice['discount'] ?? 0);
    $total = (float)$invoice['total_amount'];
    
    // If tax calculation is needed for display, you can calculate the difference.
    // The user's schema implies total_amount = subtotal - discount.
    $tax = 0;
    if ($total > ($subtotal - $discount)) {
        $tax = $total - ($subtotal - $discount);
    }

} catch (\Exception $e) {
    // Log exception safely and show generic error to user
    error_log("Invoice Generation Error [ID: $invoiceId]: " . $e->getMessage());
    die("An internal error occurred while generating the invoice. Please contact support.");
}

// 6. Render the HTML Invoice View
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= htmlspecialchars($invoice['invoice_id']) ?></title>
    <style>
        :root {
            /* Team UI Theme matching the landing page */
            --bg-base: #141423;
            --card-bg: #1e1f35;
            --card-border: rgba(255, 255, 255, 0.05);
            --text-primary: #ffffff;
            --text-secondary: #9496b8;
            --accent-primary: #5c62fa;
            --accent-hover: #4b51df;
            --input-bg: rgba(0, 0, 0, 0.2);
            --input-border: rgba(255, 255, 255, 0.1);
            --error-color: #ef4444;
            --border-radius-lg: 16px;
            --border-radius-md: 8px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-base);
            color: var(--text-primary);
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            line-height: 1.5;
            padding: 2rem;
            display: flex;
            justify-content: center;
        }

        .document-wrapper {
            background-color: var(--card-bg);
            width: 100%;
            max-width: 850px;
            min-height: 1100px;
            padding: 4rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-lg);
            position: relative;
        }

        /* --- Header --- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 1px solid var(--card-border);
            padding-bottom: 2rem;
            margin-bottom: 3rem;
        }

        .brand-section h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .brand-section p {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .invoice-title {
            text-align: right;
        }

        .invoice-title h2 {
            font-size: 3rem;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
        }

        /* --- Metadata Row --- */
        .meta-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .meta-box {
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-md);
            padding: 1.5rem;
            background-color: rgba(0,0,0,0.2);
        }

        .meta-box h3 {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
            border-bottom: 1px solid var(--card-border);
            padding-bottom: 0.5rem;
            text-transform: uppercase;
        }

        .meta-box p {
            margin-bottom: 0.25rem;
            font-weight: 500;
            color: var(--text-primary);
        }

        /* --- Status Badge --- */
        .status-badge {
            display: inline-block;
            margin-top: 1rem;
            padding: 0.25rem 0.75rem;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            border-radius: 9999px;
        }

        .status-badge.paid {
            background-color: rgba(92, 98, 250, 0.2);
            color: #8c91ff;
            border: 1px solid rgba(92, 98, 250, 0.3);
        }
        
        .status-badge.pending, .status-badge.unpaid {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border: 1px solid var(--card-border);
        }

        /* --- Line Items Table --- */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 3rem;
            border-top: 1px solid var(--card-border);
            border-bottom: 1px solid var(--card-border);
        }

        .items-table th {
            text-align: left;
            padding: 1rem;
            font-size: 0.85rem;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--card-border);
            background-color: rgba(0, 0, 0, 0.2);
            text-transform: uppercase;
        }

        .items-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--card-border);
            font-size: 1rem;
            color: var(--text-primary);
        }

        .items-table tr:last-child td {
            border-bottom: none;
        }

        .col-qty, .col-price, .col-total {
            text-align: right;
            width: 15%;
        }

        .col-desc {
            font-weight: 500;
        }

        /* --- Totals Section --- */
        .totals-section {
            display: flex;
            justify-content: flex-end;
        }

        .totals-box {
            width: 50%;
            border: 1px solid var(--card-border);
            border-radius: var(--border-radius-md);
            background-color: rgba(0, 0, 0, 0.2);
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--card-border);
        }

        .total-row:last-child {
            border-bottom: none;
            background-color: var(--accent-primary);
            color: #ffffff;
            font-weight: 700;
            font-size: 1.25rem;
            border-radius: 0 0 var(--border-radius-md) var(--border-radius-md);
        }

        .total-row span:first-child {
            color: var(--text-secondary);
        }
        
        .total-row:last-child span:first-child {
            color: #ffffff;
        }

        /* --- Screen Actions (Hidden on Print) --- */
        .screen-actions {
            margin-top: 4rem;
            display: flex;
            gap: 1rem;
            justify-content: center;
        }

        .btn {
            padding: 0.875rem 2rem;
            font-size: 1rem;
            font-weight: 600;
            border-radius: var(--border-radius-md);
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--text-primary);
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .btn:hover {
            background-color: rgba(255, 255, 255, 0.1);
            border-color: var(--card-border);
        }

        .btn-pay {
            background-color: var(--accent-primary);
            color: #ffffff;
            border: none;
        }

        .btn-pay:hover {
            background-color: var(--accent-hover);
        }

        /* --- Print Media Query --- */
        @media print {
            @page {
                margin: 0;
                size: A4 portrait;
            }

            body {
                background-color: #ffffff;
                color: #000000;
                padding: 0;
                display: block;
            }

            .document-wrapper {
                background-color: #ffffff;
                color: #000000;
                box-shadow: none;
                border: none;
                width: 100%;
                max-width: 100%;
                padding: 15mm 20mm;
                min-height: auto;
            }

            .screen-actions {
                display: none !important;
            }
            
            .brand-section h1,
            .brand-section p,
            .invoice-title h2,
            .meta-box h3,
            .meta-box p,
            .items-table th,
            .items-table td,
            .total-row span,
            .total-row:last-child span {
                color: #000000;
            }
            
            .meta-box,
            .items-table th,
            .totals-box {
                background-color: transparent;
                border-color: #000000;
            }
            
            .header,
            .meta-box h3,
            .items-table th,
            .items-table td,
            .items-table,
            .total-row {
                border-color: #000000;
            }

            .items-table {
                page-break-inside: auto;
            }

            .items-table tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
    </style>
</head>
<body>

<div class="document-wrapper">
    <div class="header">
        <div class="brand-section">
            <h1>Vehicle Service Center</h1>
            <p>123 Auto Avenue, Engine City, NY 10001</p>
            <p>support@vehicleservice.com | (555) 123-4567</p>
        </div>
        <div class="invoice-title">
            <h2>INVOICE</h2>
            <p><strong>#<?= htmlspecialchars(str_pad($invoice['invoice_id'], 6, '0', STR_PAD_LEFT)) ?></strong></p>
        </div>
    </div>

    <div class="meta-row">
        <div class="meta-box">
            <h3>Billed To</h3>
            <p><?= htmlspecialchars($invoice['customer_name']) ?></p>
            <p style="color: var(--text-secondary); font-weight: normal;"><?= htmlspecialchars($invoice['customer_email']) ?></p>
        </div>
        <div class="meta-box">
            <h3>Invoice Details</h3>
            <p>Date Issued: <?= htmlspecialchars(date('M j, Y', strtotime($invoice['created_at']))) ?></p>
            <p>Status: <span class="status-badge <?= $invoice['status'] === 'paid' ? 'paid' : 'pending' ?>"><?= htmlspecialchars($invoice['status']) ?></span></p>
        </div>
    </div>

    <table class="items-table">
        <thead>
            <tr>
                <th>Item / Description</th>
                <th class="col-qty">Qty</th>
                <th class="col-price">Unit Price</th>
                <th class="col-total">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($items)): ?>
            <tr>
                <td colspan="4" style="text-align: center; color: var(--text-secondary);">No items found for this invoice.</td>
            </tr>
            <?php else: ?>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td class="col-desc"><?= htmlspecialchars($item['description']) ?></td>
                    <td class="col-qty"><?= htmlspecialchars($item['quantity']) ?></td>
                    <td class="col-price">$<?= number_format($item['unit_price'], 2) ?></td>
                    <td class="col-total"><strong>$<?= number_format($item['line_total'], 2) ?></strong></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="totals-section">
        <div class="totals-box">
            <div class="total-row">
                <span>Subtotal</span>
                <span>$<?= number_format($subtotal, 2) ?></span>
            </div>
            <div class="total-row">
                <span>Tax (10%)</span>
                <span>$<?= number_format($tax, 2) ?></span>
            </div>
            <div class="total-row grand-total">
                <span>Total Due</span>
                <span>$<?= number_format($total, 2) ?></span>
            </div>
        </div>
    </div>

    <div class="screen-actions">
        <button class="btn" onclick="window.print()">Print / Save as PDF</button>
        <?php if ($invoice['status'] !== 'paid'): ?>
            <a href="/payments/checkout.php?invoice_id=<?= $invoice['invoice_id'] ?>" class="btn btn-pay">Proceed to Payment</a>
        <?php endif; ?>
    </div>
</div>

<!-- Auto-trigger print dialog if requested via URL -->
<?php if ($isPrintView): ?>
<script>
    window.addEventListener('load', function() {
        window.print();
    });
</script>
<?php endif; ?>

</body>
</html>
