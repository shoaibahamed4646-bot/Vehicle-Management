<?php
require_once 'includes/session.php'; // ✅ ensures session is started

// 🔥 Remove all session variables
$_SESSION = [];

// 🔥 Destroy session
session_destroy();

// 🔥 Optional but important (remove cookie)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Redirect to homepage
header("Location: customer_login.php");
exit();
?>