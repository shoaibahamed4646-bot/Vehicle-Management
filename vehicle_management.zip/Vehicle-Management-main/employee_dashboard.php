<?php
require_once 'includes/session.php';
require_once 'includes/db.php';

if (!isset($_SESSION['employee_id'])) {
    header("Location: employee_login.php");
    exit();
}

$employee_id   = $_SESSION['employee_id'];
$employee_name = $_SESSION['employee_name'];

// ✅ HANDLE STATUS UPDATES
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $request_id = (int)$_POST['request_id'];
    $new_status = $_POST['status'];

    // Security check: ensure this task is assigned to this employee
    $check = $conn->prepare("SELECT id FROM employee_assignments WHERE service_request_id = ? AND employee_id = ?");
    $check->bind_param("ii", $request_id, $employee_id);
    $check->execute();
    
    if ($check->get_result()->num_rows > 0) {
        $update = $conn->prepare("UPDATE service_requests SET status = ? WHERE id = ?");
        $update->bind_param("si", $new_status, $request_id);
        
        if ($update->execute()) {
            // 🔍 Fetch Customer and Vehicle info for notification
            $cust_q = $conn->prepare("SELECT v.customer_id, v.registration_no FROM vehicles v JOIN service_requests sr ON v.registration_no = sr.vehicle_id WHERE sr.id = ?");
            $cust_q->bind_param("i", $request_id);
            $cust_q->execute();
            $cust_data = $cust_q->get_result()->fetch_assoc();
            
            if ($cust_data) {
                $cust_id = $cust_data['customer_id'];
                $reg_no = $cust_data['registration_no'];
                
                if ($new_status === 'In Progress') {
                    $c_msg = "Work has started on your vehicle ($reg_no). Status: In Progress.";
                    $n_cust = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'customer', ?)");
                    $n_cust->bind_param("is", $cust_id, $c_msg);
                    $n_cust->execute();
                } elseif ($new_status === 'Completed') {
                    $c_msg = "Great news! The service for your vehicle ($reg_no) is now complete.";
                    $n_cust = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'customer', ?)");
                    $n_cust->bind_param("is", $cust_id, $c_msg);
                    $n_cust->execute();

                    // 🔔 Also notify Admin
                    $admin_res = $conn->query("SELECT id FROM admins LIMIT 1");
                    if ($admin_res->num_rows > 0) {
                        $admin_data = $admin_res->fetch_assoc();
                        $target_admin_id = $admin_data['id'];
                        $a_msg = "Task #$request_id completed by $employee_name";
                        $n_admin = $conn->prepare("INSERT INTO notifications (user_id, user_type, message) VALUES (?, 'admin', ?)");
                        $n_admin->bind_param("is", $target_admin_id, $a_msg);
                        $n_admin->execute();
                    }
                }
            }
        }
    }
    header("Location: employee_dashboard.php");
    exit();
}

// ✅ FETCH UNREAD NOTIFICATIONS
$unread_notifs = $conn->query("SELECT * FROM notifications WHERE user_id = $employee_id AND user_type = 'employee' AND is_read = 0 ORDER BY created_at DESC");

// ✅ ORIGINAL QUERY (UNCHANGED)
$result = $conn->query("
    SELECT sr.*, v.model, v.registration_no 
    FROM service_requests sr
    JOIN employee_assignments ea 
        ON sr.id = ea.service_request_id
    JOIN vehicles v 
        ON sr.vehicle_id = v.registration_no
    WHERE ea.employee_id = $employee_id
    ORDER BY sr.id DESC
");

// ✅ PROCESS DATA (SAFE)
$pending = 0;
$completed = 0;
$inProgress = 0;
$allRows = [];

while ($row = $result->fetch_assoc()) {
    $allRows[] = $row;

    if ($row['status'] == 'Pending') $pending++;
    elseif ($row['status'] == 'Completed') $completed++;
    elseif ($row['status'] == 'In Progress') $inProgress++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard</title>

    <!-- SAME STYLE AS ADMIN -->
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>

<!-- ✅ SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-user-cog"></i> Employee</h2>
    </div>

    <ul class="nav-links">
        <li>
            <a href="employee_dashboard.php" class="active">
                <i class="fas fa-home" style="margin-right:10px;"></i> Dashboard
            </a>
        </li>

        <li style="margin-top:auto;">
            <a href="employee_logout.php">
                <i class="fas fa-sign-out-alt" style="margin-right:10px;"></i> Logout
            </a>
        </li>
    </ul>
</div>

<!-- ✅ MAIN CONTENT -->
<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">
        <h1>Dashboard Overview</h1>

        <div class="user-profile">
            <div style="position: relative; margin-right: 15px; cursor: pointer;">
                <i class="fas fa-bell" style="font-size: 1.2rem; color: var(--text-muted);"></i>
                <?php if ($unread_notifs->num_rows > 0): ?>
                    <span style="position: absolute; top: -5px; right: -5px; background: #ef4444; color: white; font-size: 0.7rem; padding: 2px 5px; border-radius: 50%; min-width: 15px; text-align: center; border: 2px solid var(--bg-main);">
                        <?= $unread_notifs->num_rows ?>
                    </span>
                <?php endif; ?>
            </div>
            <div style="background: rgba(255,255,255,0.1); padding: 8px 16px; border-radius: 20px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-user-circle" style="font-size: 1.5rem;"></i>
                <span><?= htmlspecialchars($employee_name) ?></span>
            </div>
        </div>
    </div>

    <!-- ✅ NOTIFICATIONS -->
    <?php if ($unread_notifs->num_rows > 0): ?>
        <div style="margin-bottom: 20px;">
            <?php while($n = $unread_notifs->fetch_assoc()): ?>
                <div class="alert info" style="background: rgba(56, 189, 248, 0.1); border: 1px solid #38bdf8; color: #38bdf8; padding: 12px; border-radius: 8px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
                    <span><i class="fas fa-bell" style="margin-right: 8px;"></i> <?= htmlspecialchars($n['message']) ?></span>
                    <a href="mark_read.php?id=<?= $n['id'] ?>&ref=employee" style="color: inherit; text-decoration: none; font-weight: bold; cursor: pointer;">&times;</a>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>

    <!-- ✅ STATS -->
    <div class="dashboard-grid">

        <div class="widget">
            <h3>Total Tasks</h3>
            <div class="value"><?= count($allRows) ?></div>
        </div>

        <div class="widget">
            <h3>Pending</h3>
            <div class="value" style="color:#facc15"><?= $pending ?></div>
        </div>

        <div class="widget">
            <h3>In Progress</h3>
            <div class="value" style="color:#38bdf8"><?= $inProgress ?></div>
        </div>

        <div class="widget">
            <h3>Completed</h3>
            <div class="value" style="color:#4ade80"><?= $completed ?></div>
        </div>

    </div>

    <!-- ✅ FILTER BUTTONS -->
    <div style="margin-bottom:15px; display:flex; gap:10px;">
        <button onclick="filterStatus('all')" class="btn-sm">All</button>
        <button onclick="filterStatus('Pending')" class="btn-sm">Pending</button>
        <button onclick="filterStatus('In Progress')" class="btn-sm">In Progress</button>
        <button onclick="filterStatus('Completed')" class="btn-sm">Completed</button>
    </div>

    <!-- ✅ TABLE -->
    <div class="data-card">

        <div class="data-card-header">
            <h2>My Assigned Work</h2>
        </div>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vehicle</th>
                        <th>Service</th>
                        <th>Description</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Update</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($allRows) > 0): ?>
                        <?php foreach($allRows as $row): ?>
                        <tr data-status="<?= $row['status']; ?>">

                            <td>#<?= $row['id']; ?></td>

                            <td>
                                <?= htmlspecialchars($row['model']); ?><br>
                                <small><?= htmlspecialchars($row['registration_no']); ?></small>
                            </td>

                            <td><?= htmlspecialchars($row['service_type']); ?></td>

                            <td><?= htmlspecialchars($row['complaint_text']); ?></td>

                            <!-- ✅ PRIORITY COLOR -->
                            <td>
                                <?php
                                    $p = strtolower($row['priority']);
                                    $color = ($p == 'high') ? '#ef4444' :
                                             ($p == 'medium' ? '#facc15' : '#22c55e');
                                ?>
                                <span style="color:<?= $color ?>; font-weight:600;">
                                    <?= $row['priority']; ?>
                                </span>
                            </td>

                            <td>
                                <span class="badge <?= strtolower($row['status']); ?>">
                                    <?= $row['status']; ?>
                                </span>
                            </td>

                            <td>
                                <form method="POST">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="request_id" value="<?= $row['id']; ?>">

                                    <select name="status">
                                        <option <?= $row['status']=='Pending'?'selected':'' ?>>Pending</option>
                                        <option <?= $row['status']=='In Progress'?'selected':'' ?>>In Progress</option>
                                        <option <?= $row['status']=='Completed'?'selected':'' ?>>Completed</option>
                                    </select>

                                    <button type="submit" class="btn-sm edit">Save</button>
                                </form>
                            </td>

                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">No work assigned</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>

</div>

<!-- ✅ FILTER SCRIPT -->
<script>
function filterStatus(status) {
    let rows = document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        if (status === 'all') {
            row.style.display = '';
        } else {
            row.style.display =
                row.getAttribute("data-status") === status ? '' : 'none';
        }
    });
}
</script>

</body>
</html>