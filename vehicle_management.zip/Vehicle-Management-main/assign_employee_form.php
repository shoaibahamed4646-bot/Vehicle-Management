<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Available service requests (NOT completed & NOT assigned)
$services = $conn->query("
    SELECT sr.id, sr.complaint_text, v.model, v.registration_no 
    FROM service_requests sr
    LEFT JOIN employee_assignments ea ON sr.id = ea.service_request_id
    LEFT JOIN vehicles v ON sr.vehicle_id = v.registration_no
    WHERE sr.status != 'Completed' AND ea.service_request_id IS NULL
");

// Active employees only
$employees = $conn->query("SELECT id, name, position, email FROM employees WHERE status = 'Active' ORDER BY name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Employee - Vehicle Management</title>
    <link rel="stylesheet" href="css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .assignment-container {
            max-width: 600px;
            margin: 40px auto;
        }
        .form-group label {
            font-weight: 600;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
        }
        .form-group label i {
            color: var(--accent);
        }
        .btn-submit {
            width: 100%;
            padding: 14px;
            font-size: 1.05rem;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--text-muted);
            text-decoration: none;
            margin-bottom: 20px;
            font-size: 0.95rem;
            transition: color 0.3s;
        }
        .back-link:hover {
            color: var(--text-main);
        }
    </style>
</head>
<body>

    <!-- ADMIN SIDEBAR -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-car-side"></i> VMS Admin</h2>
        </div>
        <ul class="nav-links">
            <li><a href="admin.php"><i class="fas fa-home" style="margin-right:10px;"></i> Dashboard</a></li>
            <li><a href="admin_customers.php"><i class="fas fa-users" style="margin-right:10px;"></i> Customers</a></li>
            <li><a href="admin_vehicles.php"><i class="fas fa-car" style="margin-right:10px;"></i> Vehicles</a></li>
            <li><a href="admin_employees.php"><i class="fas fa-user-tie" style="margin-right:10px;"></i> Employees</a></li>
            <li><a href="admin_requests.php" class="active"><i class="fas fa-tools" style="margin-right:10px;"></i> Service Requests</a></li>
            <li><a href="admin_reports.php"><i class="fas fa-chart-bar" style="margin-right:10px;"></i> Reports</a></li>
            <li style="margin-top: auto;"><a href="admin_logout.php"><i class="fas fa-sign-out-alt" style="margin-right:10px;"></i> Logout</a></li>
        </ul>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="topbar">
            <h1>Assign Employee</h1>
            <div class="user-profile">
                <div style="background: rgba(255,255,255,0.1); padding: 8px 16px; border-radius: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-circle" style="font-size: 1.5rem;"></i>
                    <span><?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></span>
                </div>
            </div>
        </div>

        <div class="assignment-container">
            <a href="admin_requests.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Service Requests</a>
            
            <div class="data-card">
                <div class="data-card-header" style="border-bottom: 1px solid var(--border); margin-bottom: 20px; padding-bottom: 15px;">
                    <h2 style="font-size: 1.4rem;"><i class="fas fa-user-plus" style="color: var(--accent); margin-right: 10px;"></i>Assign Employee to Service</h2>
                </div>

                <?php if (!empty($_SESSION['success'])): ?>
                    <div class="alert success" style="background: rgba(16, 185, 129, 0.1); border: 1px solid #10b981; color: #10b981; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle" style="margin-right: 8px;"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($_SESSION['error'])): ?>
                    <div class="alert error" style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444; color: #ef4444; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-circle" style="margin-right: 8px;"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>

                <form action="includes/assign_employee.php" method="POST">

                    <!-- SERVICE -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label><i class="fas fa-clipboard-list"></i> Select Service Request</label>
                        <select name="service_request_id" class="form-control" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.8); border: 1px solid var(--border); color: white; border-radius: 8px; font-size: 1rem;" required>
                            <option value="">-- Choose a pending request --</option>
                            <?php if ($services->num_rows == 0): ?>
                                <option disabled>No available service requests</option>
                            <?php else: ?>
                                <?php while ($row = $services->fetch_assoc()): ?>
                                    <option value="<?= $row['id'] ?>">
                                        #<?= $row['id'] ?> - <?= htmlspecialchars($row['model'] ?? 'Vehicle') ?> (<?= htmlspecialchars($row['registration_no'] ?? '') ?>) 
                                        - <?= strlen($row['complaint_text']) > 30 ? substr(htmlspecialchars($row['complaint_text']), 0, 30) . '...' : htmlspecialchars($row['complaint_text']) ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <!-- EMPLOYEE -->
                    <div class="form-group" style="margin-bottom: 25px;">
                        <label><i class="fas fa-user-tie"></i> Select Employee</label>
                        <select name="employee_id" class="form-control" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.8); border: 1px solid var(--border); color: white; border-radius: 8px; font-size: 1rem;" required>
                            <option value="">-- Choose an active employee --</option>
                            <?php while ($emp = $employees->fetch_assoc()): ?>
                                <option value="<?= $emp['id'] ?>">
                                    <?= htmlspecialchars($emp['name']) ?> (<?= htmlspecialchars($emp['position']) ?><?= $emp['email'] ? ' - ' . htmlspecialchars($emp['email']) : '' ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- BUTTON -->
                    <button type="submit" class="btn btn-submit" style="background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer; transition: transform 0.2s, background 0.2s;">
                        <i class="fas fa-paper-plane"></i> Confirm Assignment
                    </button>

                </form>

            </div>
        </div>
    </div>

</body>
</html>