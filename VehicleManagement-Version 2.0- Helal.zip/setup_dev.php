<?php
/**
 * DEV SETUP SCRIPT
 * Run once via browser: http://localhost/vehicle/setup_dev.php
 * Creates database, tables, and seeds mock data for UI testing.
 *
 * Safe to re-run — uses IF NOT EXISTS and REPLACE.
 */

$host = '127.0.0.1';
$user = 'root';
$pass = 'user';
$dbName = 'vehiclemanagement';
$charset = 'utf8mb4';

// ─── Step 1: Connect WITHOUT database (to create it) ───────────────────
try {
    $pdo = new PDO("mysql:host=$host;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die("<h2 style='color:red'>❌ Cannot connect to MySQL.</h2><p>Make sure MySQL is running in XAMPP Control Panel.</p><pre>{$e->getMessage()}</pre>");
}

echo "<pre style='font-family:Consolas;font-size:14px;background:#0c0e1a;color:#60a5fa;padding:30px;border-radius:12px;max-width:800px;margin:40px auto;line-height:1.8;'>";

// ─── Step 2: Create Database ────────────────────────────────────────────
$pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$pdo->exec("USE `$dbName`");
echo "✅ Database '$dbName' ready.\n";

// ─── Step 3: Create Tables ──────────────────────────────────────────────
$tables = <<<SQL

-- Users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','employee','customer') NOT NULL DEFAULT 'customer',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Products
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100) DEFAULT 'General',
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock_quantity INT NOT NULL DEFAULT 0,
    image VARCHAR(500) DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method VARCHAR(50) DEFAULT 'cash',
    notes TEXT,
    status ENUM('pending','processing','completed','cancelled') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Order Items
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    line_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Services
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) DEFAULT 0.00,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- Packages
CREATE TABLE IF NOT EXISTS packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Package ↔ Service junction
CREATE TABLE IF NOT EXISTS package_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    package_id INT NOT NULL,
    service_id INT NOT NULL,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    UNIQUE KEY (package_id, service_id)
) ENGINE=InnoDB;

-- Bookings
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    package_id INT DEFAULT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    status ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Booking ↔ Service junction (for custom bookings)
CREATE TABLE IF NOT EXISTS booking_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    service_id INT NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Invoices
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT DEFAULT NULL,
    booking_id INT DEFAULT NULL,
    customer_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','paid','cancelled') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Payments
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status ENUM('pending','completed','failed') DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

SQL;

// Execute each statement separately
foreach (explode(';', $tables) as $stmt) {
    $stmt = trim($stmt);
    if (!empty($stmt)) {
        $pdo->exec($stmt);
    }
}
echo "✅ All tables created.\n";

// ─── Step 4: Seed Mock Data ─────────────────────────────────────────────

// Users (password = 'password123' hashed with bcrypt)
$hash = password_hash('password123', PASSWORD_BCRYPT);

$pdo->exec("REPLACE INTO users (id, username, email, password, role) VALUES
    (1, 'Admin User',    'admin@vehiclems.com',    '$hash', 'admin'),
    (2, 'John Customer', 'john@example.com',       '$hash', 'customer'),
    (3, 'Sarah Tech',    'sarah@vehiclems.com',    '$hash', 'employee')
");
echo "✅ 3 users seeded (password: password123).\n";

// Products
$pdo->exec("REPLACE INTO products (id, name, description, category, price, stock_quantity, image) VALUES
    (1, 'Synthetic Engine Oil 5W-30',  'Full synthetic motor oil for modern engines. 4L bottle.',       'Oils & Fluids',  45.99,  120, NULL),
    (2, 'Premium Brake Pad Set',       'Ceramic front brake pads with low dust and noise.',             'Brakes',         89.50,   35, NULL),
    (3, 'LED Headlight Bulb H7',       'Ultra-bright 6000K white LED headlight replacement pair.',      'Lighting',       34.00,   60, NULL),
    (4, 'Cabin Air Filter',            'Activated carbon cabin filter for improved air quality.',        'Filters',        18.75,    3, NULL),
    (5, 'Spark Plug Iridium',          'Long-life iridium spark plug for fuel efficiency.',             'Engine Parts',   12.99,  200, NULL),
    (6, 'Wiper Blade Set 22\"',        'All-weather silicone wiper blades, driver + passenger.',        'Accessories',    27.50,   45, NULL),
    (7, 'Car Battery 12V 60Ah',        'Maintenance-free lead-acid battery with 3-year warranty.',      'Electrical',    135.00,   15, NULL),
    (8, 'Transmission Fluid ATF',      'Automatic transmission fluid, 1-quart bottle.',                'Oils & Fluids',  14.25,    0, NULL),
    (9, 'Alloy Wheel 17\" Silver',     'Lightweight alloy wheel, universal 5-bolt pattern.',            'Wheels & Tires', 210.00,    8, NULL),
   (10, 'Emergency Roadside Kit',      'Triangle, flashlight, jumper cables, first aid in carry case.', 'Accessories',    56.00,   22, NULL)
");
echo "✅ 10 products seeded (1 out-of-stock, 1 low-stock).\n";

// Services
$pdo->exec("REPLACE INTO services (id, name, description, price) VALUES
    (1, 'Oil Change',             'Full synthetic oil change with filter replacement.',       49.99),
    (2, 'Brake Inspection',       'Complete brake system inspection and diagnostics.',        29.99),
    (3, 'Tire Rotation',          'Four-wheel tire rotation and pressure check.',             24.99),
    (4, 'Engine Diagnostics',     'OBD-II scan and computer diagnostics.',                   59.99),
    (5, 'A/C System Recharge',    'Refrigerant refill and leak check.',                      89.99),
    (6, 'Battery Test & Replace', 'Load test with optional replacement.',                    19.99),
    (7, 'Wheel Alignment',        'Four-wheel computerised alignment.',                      74.99),
    (8, 'Transmission Service',   'Fluid drain, filter change, and inspection.',            129.99)
");
echo "✅ 8 services seeded.\n";

// Packages
$pdo->exec("REPLACE INTO packages (id, name, description, price) VALUES
    (1, 'Basic Care',     'Essential maintenance for everyday driving. Includes oil change, tire rotation, and battery check.',  89.99),
    (2, 'Full Service',   'Comprehensive service covering engine, brakes, A/C, and alignment.',                                249.99),
    (3, 'Premium Detail', 'Our best package — full mechanical service plus diagnostics and transmission care.',                399.99)
");

// Package ↔ Service links
$pdo->exec("REPLACE INTO package_services (package_id, service_id) VALUES
    (1,1),(1,3),(1,6),
    (2,1),(2,2),(2,3),(2,5),(2,7),
    (3,1),(3,2),(3,3),(3,4),(3,5),(3,6),(3,7),(3,8)
");
echo "✅ 3 service packages seeded.\n";

// ─── Step 5: Quick Login Session ────────────────────────────────────────
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['role'] = 'admin';
$_SESSION['username'] = 'Admin User';
echo "✅ Auto-logged in as Admin (user_id=1).\n";

echo "\n────────────────────────────────────────────\n";
echo "🎉 <b>ALL DONE!</b> Visit the links below to test:\n";
echo "────────────────────────────────────────────\n\n";

$base = '/vehicle';
$links = [
    'PRODUCTS MODULE' => [
        'Product Catalog' => "$base/products/views/product_list.php",
        'Product Detail (#1)' => "$base/products/views/product_detail.php?id=1",
        'Shopping Cart' => "$base/products/views/cart.php",
        'Checkout' => "$base/products/views/checkout.php",
    ],
    'SERVICE PACKAGES MODULE' => [
        'Package List' => "$base/service-packages/views/package_list.php",
        'Select Service' => "$base/service-packages/views/select_service.php",
    ],
    'PAYMENTS MODULE' => [
        'Payment Form' => "$base/payments/views/payment_form.php?invoice_id=1&amount=89.99",
        'Invoice (#1)' => "$base/payments/handlers/generate_invoice.php?invoice_id=1",
        'Payment History' => "$base/payments/views/payment_history.php",
    ],
    'INVENTORY (Admin)' => [
        'Stock Management' => "$base/products/inventory/stock_management.php",
        'Low Stock Alerts' => "$base/products/inventory/low_stock_alert.php",
    ],
    'ADMIN' => [
        'Add Product' => "$base/products/admin/add_product.php",
        'Add Package' => "$base/service-packages/admin/add_package.php",
    ],
];

foreach ($links as $section => $pages) {
    echo "── $section ──\n";
    foreach ($pages as $label => $url) {
        echo "  <a href='$url' style='color:#60a5fa'>$label</a>\n";
    }
    echo "\n";
}

echo "</pre>";
