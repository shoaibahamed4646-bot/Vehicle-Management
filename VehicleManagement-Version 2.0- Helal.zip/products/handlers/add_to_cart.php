<?php
/**
 * Cart Handler: Add / Update / Remove products in a session-based cart.
 *
 * Accepted via POST:
 *   action      — 'add' | 'update' | 'remove'  (default: 'add')
 *   product_id  — int, required
 *   quantity    — int, required for 'add'/'update' (ignored for 'remove')
 *
 * Accepted via GET:
 *   action=clear — empties the entire cart
 *
 * Cart structure in $_SESSION['cart']:
 *   [
 *     product_id => [
 *       'product_id' => int,
 *       'name'       => string,
 *       'price'      => float,
 *       'quantity'   => int,
 *       'image'      => string|null,
 *     ],
 *     ...
 *   ]
 *
 * Returns JSON for AJAX callers (detected via X-Requested-With header)
 * or redirects back for standard form submissions.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Send a JSON response and terminate.
 */
function jsonResponse(int $httpCode, bool $success, string $message, array $extra = []): void
{
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message,
    ], $extra));
    exit;
}

/**
 * Redirect back to the referring page with a flash message.
 */
function redirectBack(string $message, string $type = 'success'): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
    $referer = $_SERVER['HTTP_REFERER'] ?? '/products/views/product_list.php';
    header("Location: $referer");
    exit;
}

/**
 * Decide whether the caller expects JSON.
 */
function isAjax(): bool
{
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Build a lightweight cart summary for JSON responses.
 */
function cartSummary(): array
{
    $cart = $_SESSION['cart'] ?? [];
    $totalItems = 0;
    $totalPrice = 0.0;

    foreach ($cart as $item) {
        $totalItems += $item['quantity'];
        $totalPrice += $item['price'] * $item['quantity'];
    }

    return [
        'cart_count'  => count($cart),
        'total_items' => $totalItems,
        'total_price' => round($totalPrice, 2),
    ];
}

/**
 * Fetch a product row from the database. Returns null if not found.
 */
function fetchProduct(int $productId): ?array
{
    $pdo  = Database::getInstance()->getConnection();
    $stmt = $pdo->prepare("SELECT product_id AS id, product_name AS name, unit_price AS price, stock_quantity, NULL AS image FROM products WHERE product_id = :id LIMIT 1");
    $stmt->execute([':id' => $productId]);
    $product = $stmt->fetch();

    return $product ?: null;
}

// ---------------------------------------------------------------------------
// Initialise cart if it doesn't exist yet
// ---------------------------------------------------------------------------
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ---------------------------------------------------------------------------
// Route: GET ?action=clear  →  empty the whole cart
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $getAction = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_SPECIAL_CHARS);

    if ($getAction === 'clear') {
        $_SESSION['cart'] = [];

        if (isAjax()) {
            jsonResponse(200, true, 'Cart cleared.', cartSummary());
        }
        redirectBack('Your cart has been cleared.');
    }

    // Any other GET request is invalid
    if (isAjax()) {
        jsonResponse(405, false, 'Method not allowed. Use POST to modify the cart.');
    }
    redirectBack('Invalid request.', 'error');
}

// ---------------------------------------------------------------------------
// POST requests only beyond this point
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (isAjax()) {
        jsonResponse(405, false, 'Method not allowed.');
    }
    redirectBack('Invalid request method.', 'error');
}

$action    = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'add';
$productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$quantity  = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

// ---------------------------------------------------------------------------
// Validate product ID
// ---------------------------------------------------------------------------
if (!$productId || $productId < 1) {
    if (isAjax()) {
        jsonResponse(400, false, 'Invalid product ID.');
    }
    redirectBack('Invalid product ID.', 'error');
}

// ---------------------------------------------------------------------------
// ACTION: remove
// ---------------------------------------------------------------------------
if ($action === 'remove') {
    if (isset($_SESSION['cart'][$productId])) {
        $removedName = $_SESSION['cart'][$productId]['name'];
        unset($_SESSION['cart'][$productId]);

        if (isAjax()) {
            jsonResponse(200, true, "$removedName removed from cart.", cartSummary());
        }
        redirectBack("$removedName removed from cart.");
    }

    if (isAjax()) {
        jsonResponse(404, false, 'Product not in cart.');
    }
    redirectBack('Product was not in your cart.', 'error');
}

// ---------------------------------------------------------------------------
// Validate quantity for add / update
// ---------------------------------------------------------------------------
if (!$quantity || $quantity < 1) {
    if (isAjax()) {
        jsonResponse(400, false, 'Quantity must be at least 1.');
    }
    redirectBack('Quantity must be at least 1.', 'error');
}

// ---------------------------------------------------------------------------
// Fetch product from DB (needed to verify stock + grab current price)
// ---------------------------------------------------------------------------
try {
    $product = fetchProduct($productId);
} catch (\Exception $e) {
    error_log("Cart: DB error fetching product $productId – " . $e->getMessage());
    if (isAjax()) {
        jsonResponse(500, false, 'A server error occurred. Please try again.');
    }
    redirectBack('A server error occurred.', 'error');
}

if (!$product) {
    if (isAjax()) {
        jsonResponse(404, false, 'Product not found.');
    }
    redirectBack('Product not found.', 'error');
}

$availableStock = (int)$product['stock_quantity'];

// ---------------------------------------------------------------------------
// ACTION: add  (default)
// ---------------------------------------------------------------------------
if ($action === 'add') {
    $existingQty = isset($_SESSION['cart'][$productId])
        ? $_SESSION['cart'][$productId]['quantity']
        : 0;

    $newQty = $existingQty + $quantity;

    // Stock ceiling
    if ($newQty > $availableStock) {
        $msg = $existingQty > 0
            ? "You already have $existingQty in your cart. Only $availableStock available."
            : "Only $availableStock unit(s) in stock.";

        if (isAjax()) {
            jsonResponse(409, false, $msg, ['available_stock' => $availableStock]);
        }
        redirectBack($msg, 'error');
    }

    $_SESSION['cart'][$productId] = [
        'product_id' => $productId,
        'name'       => $product['name'],
        'price'      => (float)$product['price'],
        'quantity'   => $newQty,
        'image'      => $product['image'] ?? null,
    ];

    if (isAjax()) {
        jsonResponse(200, true, htmlspecialchars($product['name']) . ' added to cart.', cartSummary());
    }
    redirectBack(htmlspecialchars($product['name']) . ' added to cart.');
}

// ---------------------------------------------------------------------------
// ACTION: update  (set absolute quantity)
// ---------------------------------------------------------------------------
if ($action === 'update') {
    if (!isset($_SESSION['cart'][$productId])) {
        if (isAjax()) {
            jsonResponse(404, false, 'Product not in cart. Add it first.');
        }
        redirectBack('Product is not in your cart.', 'error');
    }

    // Stock ceiling
    if ($quantity > $availableStock) {
        $msg = "Cannot set quantity to $quantity. Only $availableStock in stock.";

        if (isAjax()) {
            jsonResponse(409, false, $msg, ['available_stock' => $availableStock]);
        }
        redirectBack($msg, 'error');
    }

    $_SESSION['cart'][$productId]['quantity'] = $quantity;
    // Refresh the price in case it changed since the item was first added
    $_SESSION['cart'][$productId]['price'] = (float)$product['price'];

    if (isAjax()) {
        jsonResponse(200, true, 'Cart updated.', cartSummary());
    }
    redirectBack('Cart updated.');
}

// ---------------------------------------------------------------------------
// Fallback: unknown action
// ---------------------------------------------------------------------------
if (isAjax()) {
    jsonResponse(400, false, "Unknown action: $action");
}
redirectBack('Unknown action.', 'error');
