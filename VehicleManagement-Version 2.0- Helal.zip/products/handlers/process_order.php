<?php
/**
 * Checkout Handler: Process Order
 *
 * Accepts a POST from the cart/checkout page.
 * Within a single DB transaction it:
 *   1. Re-validates every cart item against current stock.
 *   2. Creates an `orders` row.
 *   3. Creates `order_items` rows for each product.
 *   4. Decrements `stock_quantity` on each `products` row.
 *   5. Clears the session cart.
 *   6. Redirects to the invoice/confirmation page.
 *
 * POST fields (optional enrichment from checkout form):
 *   payment_method — string (default: 'cash')
 *   notes          — string
 *
 * Requires: authenticated user session with user_id.
 */

require_once __DIR__ . '/../../includes/auth.php';

// User must be logged in to place an order
requireLogin();

// ---------------------------------------------------------------------------
// 1. Enforce POST
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error_msg'] = 'Invalid request method.';
    header('Location: /products/views/cart.php');
    exit;
}

// ---------------------------------------------------------------------------
// 2. Validate cart is non-empty
// ---------------------------------------------------------------------------
if (empty($_SESSION['cart'])) {
    $_SESSION['error_msg'] = 'Your cart is empty. Add products before checking out.';
    header('Location: /products/views/product_list.php');
    exit;
}

// ---------------------------------------------------------------------------
// 3. Sanitise optional checkout inputs
// ---------------------------------------------------------------------------
$paymentMethod = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_SPECIAL_CHARS) ?? 'cash';
$notes         = trim(filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_SPECIAL_CHARS) ?? '');

$allowedMethods = ['cash', 'credit_card', 'bank_transfer', 'paypal'];
if (!in_array($paymentMethod, $allowedMethods, true)) {
    $paymentMethod = 'cash';
}

$customerId = (int) $_SESSION['user_id'];

// ---------------------------------------------------------------------------
// 4. Begin atomic transaction
// ---------------------------------------------------------------------------
$pdo = Database::getInstance()->getConnection();

try {
    $pdo->beginTransaction();

    // -----------------------------------------------------------------
    // 4a. Re-validate stock for every cart item using SELECT … FOR UPDATE
    //     to lock the rows and prevent race conditions.
    // -----------------------------------------------------------------
    $cart          = $_SESSION['cart'];
    $productIds    = array_keys($cart);
    $placeholders  = implode(',', array_fill(0, count($productIds), '?'));

    $lockStmt = $pdo->prepare(
        "SELECT product_id AS id, product_name AS name, unit_price AS price, stock_quantity FROM products WHERE product_id IN ($placeholders) FOR UPDATE"
    );
    $lockStmt->execute($productIds);
    $dbProducts = $lockStmt->fetchAll(PDO::FETCH_ASSOC);

    // Index by product id for quick lookup
    $dbIndex = [];
    foreach ($dbProducts as $row) {
        $dbIndex[(int) $row['id']] = $row;
    }

    // Validate each cart item against the locked DB state
    $orderTotal  = 0.0;
    $validItems  = [];

    foreach ($cart as $pid => $item) {
        $pid = (int) $pid;

        // Product disappeared from DB?
        if (!isset($dbIndex[$pid])) {
            $pdo->rollBack();
            $_SESSION['error_msg'] = "Product \"{$item['name']}\" is no longer available. Please update your cart.";
            header('Location: /products/views/cart.php');
            exit;
        }

        $dbRow    = $dbIndex[$pid];
        $qty      = (int) $item['quantity'];
        $dbStock  = (int) $dbRow['stock_quantity'];
        $dbPrice  = (float) $dbRow['price'];

        // Insufficient stock?
        if ($qty > $dbStock) {
            $pdo->rollBack();
            $_SESSION['error_msg'] = "Insufficient stock for \"{$dbRow['name']}\". Only $dbStock left.";
            header('Location: /products/views/cart.php');
            exit;
        }

        $lineTotal    = $dbPrice * $qty;
        $orderTotal  += $lineTotal;

        $validItems[] = [
            'product_id' => $pid,
            'name'       => $dbRow['name'],
            'price'      => $dbPrice,
            'quantity'   => $qty,
            'line_total' => $lineTotal,
        ];
    }

    // -----------------------------------------------------------------
    // 4b. Insert the invoice header
    // -----------------------------------------------------------------
    $orderStmt = $pdo->prepare(
        "INSERT INTO invoices (customer_id, invoice_type, subtotal, discount, total_amount, payment_status, notes, created_at)
         VALUES (:customer_id, 'product', :total, 0, :total, 'unpaid', :notes, NOW())"
    );
    $orderStmt->execute([
        ':customer_id' => $customerId,
        ':total'       => round($orderTotal, 2),
        ':notes'       => $notes,
    ]);

    $invoiceId = (int) $pdo->lastInsertId();

    // -----------------------------------------------------------------
    // 4c. Insert invoice items + decrement stock
    // -----------------------------------------------------------------
    $itemStmt = $pdo->prepare(
        "INSERT INTO invoice_items (invoice_id, item_type, product_id, item_name, unit_price, quantity, line_total)
         VALUES (:inv_id, 'product', :pid, :name, :price, :qty, :line)"
    );

    $stockStmt = $pdo->prepare(
        "UPDATE products SET stock_quantity = stock_quantity - :qty WHERE product_id = :pid"
    );

    foreach ($validItems as $vi) {
        $itemStmt->execute([
            ':inv_id' => $invoiceId,
            ':pid'   => $vi['product_id'],
            ':name'  => $vi['name'],
            ':price' => $vi['price'],
            ':qty'   => $vi['quantity'],
            ':line'  => $vi['line_total'],
        ]);

        $stockStmt->execute([
            ':qty' => $vi['quantity'],
            ':pid' => $vi['product_id'],
        ]);
    }

    // -----------------------------------------------------------------
    // 4d. Commit
    // -----------------------------------------------------------------
    $pdo->commit();

    // -----------------------------------------------------------------
    // 5. Clear cart and redirect to invoice
    // -----------------------------------------------------------------
    $_SESSION['cart'] = [];
    $_SESSION['success_msg'] = "Order #$invoiceId placed successfully! Total: $" . number_format($orderTotal, 2);

    // Redirect to invoice/confirmation view
    header("Location: /products/views/order_confirmation.php?invoice_id=$invoiceId");
    exit;

} catch (\PDOException $e) {
    // Attempt rollback (safe even if transaction already rolled back)
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("Order processing failed for customer $customerId: " . $e->getMessage());

    $_SESSION['error_msg'] = 'Something went wrong while placing your order. Please try again.';
    header('Location: /products/views/cart.php');
    exit;

} catch (\Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("Unexpected error during checkout: " . $e->getMessage());

    $_SESSION['error_msg'] = 'An unexpected error occurred. Please try again.';
    header('Location: /products/views/cart.php');
    exit;
}
