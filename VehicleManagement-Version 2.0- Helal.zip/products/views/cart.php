<?php
/**
 * Customer View: Shopping Cart
 * Displays cart items with editable quantities, per-row subtotals, and checkout CTA.
 */

require_once __DIR__ . '/../../config/session.php';

$cart      = $_SESSION['cart'] ?? [];
$itemCount = 0;
$orderTotal = 0.0;

foreach ($cart as $item) {
    $itemCount  += $item['quantity'];
    $orderTotal += $item['price'] * $item['quantity'];
}

$flashSuccess = $_SESSION['success_msg'] ?? null;
$flashError   = $_SESSION['error_msg'] ?? null;
$flashGeneric = $_SESSION['flash'] ?? null;
unset($_SESSION['success_msg'], $_SESSION['error_msg'], $_SESSION['flash']);
$currentPage = 'products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart | Vehicle Parts</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#0c0e1a;--bg-card:#141627;--bg-input:#0e1020;--bg-nav:#111325;
            --text:#e8ecf4;--muted:#7a84a0;
            --accent:#3b82f6;--accent-light:#60a5fa;--accent-hover:#2563eb;
            --glow:rgba(59,130,246,.15);
            --danger:#ef4444;--success:#22c55e;
            --border:rgba(59,130,246,.08);--border-h:rgba(59,130,246,.25);
            --r:14px;--t:all .3s cubic-bezier(.25,.8,.25,1);
        }
        *,*::before,*::after{box-sizing:border-box;}
        .container{max-width:1000px;margin:0 auto;padding:50px 24px;}
        .back{display:inline-flex;align-items:center;gap:6px;color:var(--accent);text-decoration:none;font-weight:600;font-size:.95rem;margin-bottom:30px;transition:var(--t);}
        .back:hover{color:var(--text);transform:translateX(-4px);}
        .back svg{width:18px;height:18px;}
        h1{font-size:2.2rem;font-weight:800;margin:0 0 30px;letter-spacing:-.03em;}

        /* Flash */
        .flash{border-radius:10px;padding:14px 18px;margin-bottom:20px;font-size:.9rem;display:flex;align-items:center;gap:8px;}
        .flash-ok{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);color:var(--success);}
        .flash-err{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);color:var(--danger);}

        /* Table Card */
        .cart-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--r);overflow:hidden;}
        table{width:100%;border-collapse:collapse;}
        thead th{text-align:left;padding:16px 20px;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);background:rgba(0,0,0,.2);border-bottom:1px solid var(--border);}
        tbody tr{border-bottom:1px solid var(--border);transition:background .2s;}
        tbody tr:last-child{border-bottom:none;}
        tbody tr:hover{background:rgba(59,130,246,.03);}
        tbody td{padding:16px 20px;vertical-align:middle;}

        /* Product cell */
        .prod-cell{display:flex;align-items:center;gap:14px;}
        .prod-cell img{width:50px;height:50px;border-radius:8px;object-fit:cover;border:1px solid var(--border);flex-shrink:0;}
        .prod-cell .ph{width:50px;height:50px;border-radius:8px;background:var(--bg-input);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
        .prod-name{font-weight:600;}

        .price-col{white-space:nowrap;}
        .subtotal-col{font-weight:700;white-space:nowrap;}

        /* Qty control */
        .qty-ctrl{display:flex;align-items:center;border:1px solid var(--border);border-radius:6px;overflow:hidden;width:fit-content;}
        .qty-btn{background:var(--bg-card);border:none;color:var(--text);width:34px;height:34px;font-size:1.1rem;cursor:pointer;transition:var(--t);display:flex;align-items:center;justify-content:center;}
        .qty-btn:hover{background:var(--glow);color:var(--accent-light);}
        .qty-val{width:44px;text-align:center;background:var(--bg-input);border:none;border-left:1px solid var(--border);border-right:1px solid var(--border);color:var(--text);font-size:.95rem;font-weight:700;font-family:inherit;padding:6px 0;}
        .qty-val:focus{outline:none;}

        /* Remove button */
        .btn-remove{background:transparent;border:1px solid rgba(239,68,68,.2);color:var(--danger);padding:6px 12px;border-radius:6px;font-size:.8rem;font-weight:600;cursor:pointer;transition:var(--t);white-space:nowrap;}
        .btn-remove:hover{background:rgba(239,68,68,.1);border-color:var(--danger);}

        /* Row feedback */
        .row-fb{font-size:.75rem;font-weight:600;margin-left:6px;opacity:0;transition:opacity .3s;}
        .row-fb.show{opacity:1;}
        .row-fb.ok{color:var(--success);} .row-fb.err{color:var(--danger);}

        /* Footer */
        .cart-footer{display:flex;justify-content:space-between;align-items:center;padding:20px;border-top:1px solid var(--border);flex-wrap:wrap;gap:15px;}
        .clear-link{color:var(--muted);font-size:.9rem;font-weight:600;text-decoration:none;transition:var(--t);}
        .clear-link:hover{color:var(--danger);}
        .total-block{text-align:right;}
        .total-label{font-size:.85rem;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;}
        .total-value{font-size:2.2rem;font-weight:800;margin-top:2px;}

        /* Checkout */
        .checkout-row{margin-top:25px;display:flex;justify-content:flex-end;gap:15px;flex-wrap:wrap;}
        .btn-continue{padding:16px 28px;border-radius:10px;border:1px solid var(--border);background:transparent;color:var(--muted);font-size:1rem;font-weight:600;cursor:pointer;transition:var(--t);text-decoration:none;text-align:center;}
        .btn-continue:hover{border-color:var(--muted);color:var(--text);}
        .btn-checkout{padding:16px 36px;border:none;border-radius:10px;background:var(--accent);color:#fff;font-size:1.05rem;font-weight:700;cursor:pointer;transition:var(--t);display:flex;align-items:center;gap:8px;}
        .btn-checkout:hover{background:var(--accent-hover);transform:scale(1.02);box-shadow:0 10px 24px -6px rgba(59,130,246,.4);}
        .btn-checkout svg{width:18px;height:18px;}

        /* Empty */
        .empty{text-align:center;padding:80px 20px;color:var(--muted);}
        .empty .icon{font-size:4rem;margin-bottom:15px;}
        .empty h2{color:var(--text);margin:0 0 8px;}
        .empty a{color:var(--accent);font-weight:600;text-decoration:none;}
        .empty a:hover{text-decoration:underline;}

        @media(max-width:700px){
            thead th:nth-child(2),tbody td:nth-child(2){display:none;} /* hide unit price col */
            .prod-cell img,.prod-cell .ph{width:40px;height:40px;}
            h1{font-size:1.8rem;}
            .total-value{font-size:1.8rem;}
        }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/../../includes/header.php'; ?>
<div class="container">

    <?php
    $msg = $flashSuccess ?? ($flashGeneric['message'] ?? null);
    $type = $flashSuccess ? 'ok' : (($flashGeneric['type'] ?? '') === 'success' ? 'ok' : 'err');
    if ($flashError) { $msg = $flashError; $type = 'err'; }
    if ($msg): ?>
        <div class="flash flash-<?= $type ?>">
            <?= $type === 'ok' ? '✓' : '✗' ?> <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>

    <h1>Your Cart</h1>

    <?php if (empty($cart)): ?>
        <div class="empty">
            <div class="icon">🛒</div>
            <h2>Your cart is empty</h2>
            <p>Looks like you haven't added any parts yet.</p>
            <a href="product_list.php">Browse Products →</a>
        </div>
    <?php else: ?>
        <div class="cart-card">
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Unit Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="cartBody">
                    <?php foreach ($cart as $pid => $item):
                        $sub = $item['price'] * $item['quantity'];
                    ?>
                    <tr id="row-<?= $pid ?>" data-pid="<?= $pid ?>" data-price="<?= $item['price'] ?>">
                        <td>
                            <div class="prod-cell">
                                <?php if (!empty($item['image'])): ?>
                                    <img src="/<?= htmlspecialchars($item['image']) ?>" alt="">
                                <?php else: ?>
                                    <div class="ph">📦</div>
                                <?php endif; ?>
                                <span class="prod-name"><?= htmlspecialchars($item['name']) ?></span>
                            </div>
                        </td>
                        <td class="price-col">$<?= number_format($item['price'], 2) ?></td>
                        <td>
                            <div class="qty-ctrl">
                                <button class="qty-btn" onclick="changeQty(<?= $pid ?>, -1)">−</button>
                                <input class="qty-val" id="qty-<?= $pid ?>" type="number"
                                       value="<?= $item['quantity'] ?>" min="1" onchange="setQty(<?= $pid ?>)">
                                <button class="qty-btn" onclick="changeQty(<?= $pid ?>, 1)">+</button>
                            </div>
                            <span class="row-fb" id="fb-<?= $pid ?>"></span>
                        </td>
                        <td class="subtotal-col" id="sub-<?= $pid ?>">$<?= number_format($sub, 2) ?></td>
                        <td>
                            <button class="btn-remove" onclick="removeItem(<?= $pid ?>, this)">Remove</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="cart-footer">
                <a href="../handlers/add_to_cart.php?action=clear" class="clear-link"
                   onclick="return confirm('Clear your entire cart?')">Clear Cart</a>
                <div class="total-block">
                    <div class="total-label">Order Total</div>
                    <div class="total-value" id="orderTotal">$<?= number_format($orderTotal, 2) ?></div>
                </div>
            </div>
        </div>

        <div class="checkout-row">
            <a href="product_list.php" class="btn-continue">Continue Shopping</a>
            <form action="../handlers/process_order.php" method="POST" style="margin:0;">
                <button type="submit" class="btn-checkout">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                    Proceed to Checkout
                </button>
            </form>
        </div>
    <?php endif; ?>

</div>

<script>
function changeQty(pid, delta) {
    const inp = document.getElementById('qty-' + pid);
    let v = parseInt(inp.value, 10) + delta;
    if (v < 1) v = 1;
    inp.value = v;
    syncQty(pid, v);
}

function setQty(pid) {
    const inp = document.getElementById('qty-' + pid);
    let v = parseInt(inp.value, 10);
    if (isNaN(v) || v < 1) { v = 1; inp.value = 1; }
    syncQty(pid, v);
}

function syncQty(pid, qty) {
    const fb = document.getElementById('fb-' + pid);
    fb.className = 'row-fb'; fb.textContent = '';

    const body = new URLSearchParams();
    body.append('product_id', pid);
    body.append('quantity', qty);
    body.append('action', 'update');

    fetch('../handlers/add_to_cart.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const price = parseFloat(document.getElementById('row-' + pid).dataset.price);
            document.getElementById('sub-' + pid).textContent = '$' + (price * qty).toFixed(2);
            document.getElementById('orderTotal').textContent = '$' + data.total_price.toFixed(2);
            fb.textContent = '✓'; fb.className = 'row-fb show ok';
        } else {
            fb.textContent = data.message; fb.className = 'row-fb show err';
        }
        setTimeout(() => { fb.className = 'row-fb'; }, 2000);
    })
    .catch(() => {
        fb.textContent = 'Error'; fb.className = 'row-fb show err';
        setTimeout(() => { fb.className = 'row-fb'; }, 2000);
    });
}

function removeItem(pid, btn) {
    btn.textContent = '...';
    const body = new URLSearchParams();
    body.append('product_id', pid);
    body.append('action', 'remove');

    fetch('../handlers/add_to_cart.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const row = document.getElementById('row-' + pid);
            row.style.opacity = '0'; row.style.transform = 'translateX(30px)';
            setTimeout(() => {
                row.remove();
                document.getElementById('orderTotal').textContent = '$' + data.total_price.toFixed(2);
                if (data.cart_count === 0) location.reload();
            }, 300);
        } else {
            btn.textContent = 'Remove';
        }
    })
    .catch(() => { btn.textContent = 'Remove'; });
}
</script>
    <?php require_once __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
