<?php
/**
 * Global Footer
 *
 * Usage:
 *   require_once __DIR__ . '/../includes/footer.php';
 */
require_once __DIR__ . '/../config/paths.php';
?>

<footer class="site-footer">
    <div class="footer-inner">
        <span class="footer-copy">&copy; 2024 VehicleMS. All rights reserved.</span>
        <nav class="footer-links">
            <a href="<?= BASE_URL ?>/service-packages/views/package_list.php">Services</a>
            <a href="<?= BASE_URL ?>/products/views/product_list.php">Products</a>
            <a href="mailto:support@vehiclems.com">Contact</a>
        </nav>
        <span class="footer-contact">support@vehiclems.com &middot; +1 (555) 123-4567</span>
    </div>
</footer>

<style>
.site-footer {
    background: #0a0c16;
    border-top: 1px solid rgba(59,130,246,.06);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    margin-top: 60px;
    padding: 28px 24px;
    color: #5d6580;
    font-size: .88rem;
}
.footer-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
}
.footer-copy { font-weight: 500; }
.footer-links {
    display: flex; gap: 20px;
}
.footer-links a {
    color: #5d6580;
    text-decoration: none;
    font-weight: 600;
    transition: color .2s;
}
.footer-links a:hover { color: #60a5fa; }
.footer-contact { color: #4a5068; }

@media (max-width: 600px) {
    .footer-inner { flex-direction: column; text-align: center; }
}
</style>
