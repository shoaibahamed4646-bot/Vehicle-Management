<?php
/**
 * Test Connection Utility
 * Verifies that the database is reachable and the required tables exist.
 */

require_once __DIR__ . '/config/db.php';

$message = '';
$status = 'unknown';

try {
    $db = Database::getInstance()->getConnection();
    $status = 'success';
    $message = 'Successfully connected to the database!';
    
    // Check some tables
    $stmt = $db->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Count records
    $userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $productCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $packageCount = $db->query("SELECT COUNT(*) FROM service_packages")->fetchColumn();
    
} catch (\Exception $e) {
    $status = 'error';
    $message = 'Database connection failed: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Test | Vehicle Management</title>
    <style>
        body { font-family: -apple-system, sans-serif; background: #0c0e1a; color: #fff; padding: 50px; text-align: center; }
        .card { background: #141627; border: 1px solid rgba(59,130,246,0.2); border-radius: 12px; padding: 40px; max-width: 600px; margin: 0 auto; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .success { color: #22c55e; }
        .error { color: #ef4444; }
        h1 { margin-top: 0; }
        .stats { display: flex; justify-content: center; gap: 20px; margin-top: 30px; }
        .stat-box { background: rgba(0,0,0,0.2); padding: 20px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05); }
        .stat-value { font-size: 24px; font-weight: bold; color: #3b82f6; }
        .btn { display: inline-block; margin-top: 30px; padding: 12px 24px; background: #3b82f6; color: white; text-decoration: none; border-radius: 6px; font-weight: bold; }
        .btn:hover { background: #2563eb; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Database Status</h1>
        
        <h2 class="<?= $status ?>">
            <?= $status === 'success' ? '✅ ' : '❌ ' ?> 
            <?= htmlspecialchars($message) ?>
        </h2>

        <?php if ($status === 'success'): ?>
            <p>Your XAMPP MySQL database is properly configured and reachable.</p>
            
            <div class="stats">
                <div class="stat-box">
                    <div class="stat-value"><?= $userCount ?></div>
                    <div>Users</div>
                </div>
                <div class="stat-box">
                    <div class="stat-value"><?= $productCount ?></div>
                    <div>Products</div>
                </div>
                <div class="stat-box">
                    <div class="stat-value"><?= $packageCount ?></div>
                    <div>Packages</div>
                </div>
            </div>
            
            <a href="index.php" class="btn">Go to Application</a>
        <?php endif; ?>
    </div>
</body>
</html>
