<?php
/**
 * Book Service Handler
 * Handles a customer POST request to book a package or individual services.
 */

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../config/db.php';

// 1. Authorization Check (Customer Only)
// Assumes a logged-in user is required
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'You must be logged in to book a service.']);
    exit;
}

// 2. Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// 3. Input Validation
$customerId = $_SESSION['user_id'];
$packageId = filter_input(INPUT_POST, 'package_id', FILTER_VALIDATE_INT);
$bookingDate = filter_input(INPUT_POST, 'booking_date', FILTER_SANITIZE_STRING); // Expected format: YYYY-MM-DD
$bookingTime = filter_input(INPUT_POST, 'booking_time', FILTER_SANITIZE_STRING); // Expected format: HH:MM

// Individual services (if package is not selected)
$serviceIds = isset($_POST['service_ids']) && is_array($_POST['service_ids']) 
    ? array_map('intval', $_POST['service_ids']) 
    : [];

$errors = [];

// Date/Time validation
if (empty($bookingDate) || empty($bookingTime)) {
    $errors[] = 'Booking date and time are required.';
} else {
    // Basic format check
    $datetime = DateTime::createFromFormat('Y-m-d H:i', "$bookingDate $bookingTime");
    if (!$datetime || $datetime->format('Y-m-d H:i') !== "$bookingDate $bookingTime") {
        $errors[] = 'Invalid date or time format.';
    } elseif ($datetime < new DateTime()) {
        $errors[] = 'Booking date/time cannot be in the past.';
    }
}

// Ensure either a package OR individual services are selected
if (empty($packageId) && empty($serviceIds)) {
    $errors[] = 'You must select a package or at least one individual service.';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// 4. Calculate Total & Prepare Items
try {
    $pdo = Database::getInstance()->getConnection();
    
    $totalAmount = 0;
    $itemsToInsert = [];

    if (!empty($packageId)) {
        $stmtPkg = $pdo->prepare("SELECT package_id, package_name, total_price FROM service_packages WHERE package_id = ?");
        $stmtPkg->execute([$packageId]);
        $pkg = $stmtPkg->fetch();
        if ($pkg) {
            $totalAmount += $pkg['total_price'];
            $itemsToInsert[] = [
                'type' => 'package',
                'id' => $pkg['package_id'],
                'name' => $pkg['package_name'],
                'price' => $pkg['total_price']
            ];
        } else {
            $errors[] = 'Selected package not found.';
        }
    } else if (!empty($serviceIds)) {
        $placeholders = implode(',', array_fill(0, count($serviceIds), '?'));
        $stmtSrv = $pdo->prepare("SELECT service_id, service_name, price FROM services WHERE service_id IN ($placeholders)");
        $stmtSrv->execute($serviceIds);
        $srvs = $stmtSrv->fetchAll();
        foreach ($srvs as $srv) {
            $totalAmount += $srv['price'];
            $itemsToInsert[] = [
                'type' => 'service',
                'id' => $srv['service_id'],
                'name' => $srv['service_name'],
                'price' => $srv['price']
            ];
        }
    }

    if (!empty($errors) || empty($itemsToInsert)) {
        $_SESSION['error_msg'] = implode(' ', $errors) ?: 'Invalid selection.';
        header('Location: ../views/select_service.php');
        exit;
    }

    // 5. Database Insertion with Transactions
    $pdo->beginTransaction();
    
    $notes = "Booking for: $bookingDate at $bookingTime";

    // Insert the main invoice record
    $stmtInvoice = $pdo->prepare("
        INSERT INTO invoices (customer_id, invoice_type, subtotal, discount, total_amount, payment_status, notes, created_at)
        VALUES (:customer_id, 'service', :total, 0, :total, 'unpaid', :notes, NOW())
    ");
    
    $stmtInvoice->execute([
        ':customer_id'  => $customerId,
        ':total'        => $totalAmount,
        ':notes'        => $notes
    ]);
    
    $invoiceId = $pdo->lastInsertId();
    
    // Insert invoice items
    $stmtItem = $pdo->prepare("
        INSERT INTO invoice_items (invoice_id, item_type, package_id, service_id, item_name, unit_price, quantity, line_total)
        VALUES (:inv_id, :type, :pkg_id, :srv_id, :name, :price, 1, :price)
    ");
    
    foreach ($itemsToInsert as $item) {
        $stmtItem->execute([
            ':inv_id' => $invoiceId,
            ':type'   => $item['type'],
            ':pkg_id' => $item['type'] === 'package' ? $item['id'] : null,
            ':srv_id' => $item['type'] === 'service' ? $item['id'] : null,
            ':name'   => $item['name'],
            ':price'  => $item['price']
        ]);
    }
    
    // Commit Transaction
    $pdo->commit();
    
    // Redirect to confirmation
    $_SESSION['success_msg'] = "Service booked successfully!";
    header("Location: /products/views/order_confirmation.php?invoice_id=$invoiceId");
    exit;
    
} catch (\PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Booking Error: " . $e->getMessage());
    $_SESSION['error_msg'] = 'An error occurred while processing your booking. Please try again.';
    header('Location: ../views/select_service.php');
    exit;
}
