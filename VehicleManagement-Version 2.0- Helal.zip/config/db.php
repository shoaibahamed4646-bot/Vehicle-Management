<?php

/**
 * Database Connection Configuration
 * Implements a Singleton pattern to ensure only one PDO instance is created.
 */
class Database {
    private static ?Database $instance = null;
    private ?PDO $connection = null;

    /**
     * Private constructor to prevent direct instantiation.
     */
    private function __construct() {
        // Environment-based configuration with sensible defaults
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $port = getenv('DB_PORT') ?: '3306';
        $db   = getenv('DB_NAME') ?: 'vehiclemanagement';
        $user = getenv('DB_USER') ?: 'root';
        $pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';
        $charset = 'utf8mb4';

        $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch associative arrays
            PDO::ATTR_EMULATE_PREPARES   => false,                  // Use native prepared statements for security
        ];

        try {
            $this->connection = new PDO($dsn, $user, $pass, $options);
        } catch (\PDOException $e) {
            // Log the internal error securely, avoiding exposure of sensitive connection details
            error_log("Database Connection Error: " . $e->getMessage());
            
            // Throw a generic exception to the application level
            throw new \Exception("Database connection failed. Please check the system logs.");
        }
    }

    /**
     * Prevent cloning of the singleton instance.
     */
    private function __clone() {}

    /**
     * Prevent unserialization of the singleton instance.
     */
    public function __wakeup() {
        throw new \Exception("Cannot unserialize a singleton.");
    }

    /**
     * Get the singleton instance of the Database class.
     *
     * @return Database
     */
    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * Get the PDO connection object.
     *
     * @return PDO
     */
    public function getConnection(): PDO {
        return $this->connection;
    }
}
